import { ReceiptData } from '../types';

// Declare global window interfaces for Android WebView Bridge and Cordova/Capacitor
declare global {
  interface Window {
    Android?: {
      printReceipt?: (base64Data: string, paperWidth: string) => boolean | string;
      print?: (data: string) => boolean | string;
      getPairedDevices?: () => string; // Returns JSON string of [{ name, address }]
      connectDevice?: (addressOrName: string) => boolean;
      isPrinterConnected?: () => boolean;
    };
    AndroidPrinter?: {
      print?: (base64Data: string) => boolean | string;
      printText?: (text: string) => boolean | string;
      getBondedDevices?: () => string;
    };
    AndroidBridge?: {
      print?: (data: string) => boolean | string;
    };
    bluetoothSerial?: {
      list: (success: (devices: Array<{ name: string; address: string; id?: string }>) => void, failure: (err: any) => void) => void;
      connect: (address: string, success: () => void, failure: (err: any) => void) => void;
      write: (data: any, success: () => void, failure: (err: any) => void) => void;
      isConnected: (success: () => void, failure: () => void) => void;
      disconnect: (success?: () => void, failure?: () => void) => void;
    };
  }
}

// Common Bluetooth Low Energy Service UUIDs used by 58mm & 80mm Thermal Printers
export const THERMAL_PRINTER_SERVICES = [
  '000018f0-0000-1000-8000-00805f9b34fb',
  'e7810a71-73ae-499d-8c15-faa9aef0c3f2',
  '49535343-fe7d-4ae5-8fa9-9fafd205e455',
  '0000ffe0-0000-1000-8000-00805f9b34fb',
  '0000fff0-0000-1000-8000-00805f9b34fb',
  '49535343-8841-43f4-a8d4-ecbe34729bb3',
];

export interface PairedDeviceInfo {
  name: string;
  address?: string;
}

export class BluetoothThermalPrinter {
  private device: any = null;
  private characteristic: any = null;
  public isConnected: boolean = false;
  public deviceName: string = '';
  public activeMode: 'apk_bridge' | 'android_intent' | 'web_bluetooth' = 'android_intent';

  constructor() {
    // Check saved paired printer name
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('strukppob_paired_printer_name');
      if (saved) {
        this.deviceName = saved;
      }
    }
  }

  // 1. Detect if running inside an Android APK (WebView Bridge / Cordova / Capacitor)
  public isAndroidApk(): boolean {
    if (typeof window === 'undefined') return false;
    return Boolean(
      window.Android || 
      window.AndroidPrinter || 
      window.AndroidBridge || 
      window.bluetoothSerial
    );
  }

  // 2. Detect Web Bluetooth support in current browser
  public isSupported(): boolean {
    return typeof navigator !== 'undefined' && 'bluetooth' in navigator;
  }

  // 3. Get Paired Devices from Android System
  public async getPairedDevicesFromPhone(): Promise<PairedDeviceInfo[]> {
    const devices: PairedDeviceInfo[] = [];

    // Check Android WebView Bridge
    if (window.Android?.getPairedDevices) {
      try {
        const jsonStr = window.Android.getPairedDevices();
        const parsed = JSON.parse(jsonStr);
        if (Array.isArray(parsed)) {
          return parsed.map((d: any) => ({
            name: d.name || d.deviceName || 'Thermal Printer',
            address: d.address || d.macAddress || '',
          }));
        }
      } catch (e) {
        console.warn('Failed to parse paired devices from Android bridge:', e);
      }
    }

    // Check AndroidPrinter
    if (window.AndroidPrinter?.getBondedDevices) {
      try {
        const jsonStr = window.AndroidPrinter.getBondedDevices();
        const parsed = JSON.parse(jsonStr);
        if (Array.isArray(parsed)) {
          return parsed.map((d: any) => ({
            name: d.name || 'Thermal Printer',
            address: d.address || '',
          }));
        }
      } catch (e) {
        console.warn('Failed to parse bonded devices:', e);
      }
    }

    // Check Cordova / Capacitor bluetoothSerial plugin
    if (window.bluetoothSerial?.list) {
      return new Promise((resolve) => {
        window.bluetoothSerial!.list(
          (list) => {
            const mapped = list.map((d) => ({
              name: d.name || 'Bluetooth Printer',
              address: d.address || d.id || '',
            }));
            resolve(mapped);
          },
          () => {
            resolve([]);
          }
        );
      });
    }

    // Default common Indonesian thermal printer names if no bridge is active yet
    return [
      { name: 'RPP02N' },
      { name: 'POS-58' },
      { name: 'PT-210' },
      { name: 'Panda POS' },
      { name: 'Iware MP-58' },
      { name: 'MPT-II' },
      { name: 'Bluetooth Printer' },
    ];
  }

  // 4. Set Selected Paired Device Name
  public setPairedDeviceName(name: string) {
    this.deviceName = name;
    if (typeof window !== 'undefined') {
      localStorage.setItem('strukppob_paired_printer_name', name);
    }
  }

  // 5. Connect via Web Bluetooth (Browser fallback)
  public async connect(): Promise<{ success: boolean; deviceName?: string; error?: string }> {
    if (this.isAndroidApk()) {
      this.isConnected = true;
      return { 
        success: true, 
        deviceName: this.deviceName || 'Printer Bluetooth HP (APK)' 
      };
    }

    if (!this.isSupported()) {
      // In mobile browser/APK without Web Bluetooth, fallback directly to system paired mode
      this.isConnected = true;
      this.deviceName = this.deviceName || 'Printer Tersanding HP';
      return {
        success: true,
        deviceName: this.deviceName,
      };
    }

    try {
      const nav: any = navigator;
      this.device = await nav.bluetooth.requestDevice({
        acceptAllDevices: true,
        optionalServices: THERMAL_PRINTER_SERVICES,
      });

      if (!this.device) {
        return { success: false, error: 'Tidak ada perangkat yang dipilih' };
      }

      this.deviceName = this.device.name || 'Printer Bluetooth';
      this.setPairedDeviceName(this.deviceName);

      const server = await this.device.gatt.connect();

      let foundChar = null;
      for (const serviceUuid of THERMAL_PRINTER_SERVICES) {
        try {
          const service = await server.getPrimaryService(serviceUuid);
          const characteristics = await service.getCharacteristics();
          for (const char of characteristics) {
            if (char.properties.write || char.properties.writeWithoutResponse) {
              foundChar = char;
              break;
            }
          }
        } catch {
          // Continue searching other services
        }
        if (foundChar) break;
      }

      if (!foundChar) {
        try {
          const services = await server.getPrimaryServices();
          for (const service of services) {
            const characteristics = await service.getCharacteristics();
            for (const char of characteristics) {
              if (char.properties.write || char.properties.writeWithoutResponse) {
                foundChar = char;
                break;
              }
            }
            if (foundChar) break;
          }
        } catch {
          // fallback
        }
      }

      if (!foundChar) {
        throw new Error('Karakteristik penulisan data printer tidak ditemukan.');
      }

      this.characteristic = foundChar;
      this.isConnected = true;

      this.device.addEventListener('gattserverdisconnected', () => {
        this.isConnected = false;
        this.characteristic = null;
      });

      return { success: true, deviceName: this.deviceName };
    } catch (err: any) {
      console.error('Bluetooth connection error:', err);
      // If user cancelled or failed, allow continuing via Phone Pairing
      return { success: false, error: err.message || 'Gagal menyambungkan ke printer' };
    }
  }

  public async disconnect() {
    if (this.device && this.device.gatt && this.device.gatt.connected) {
      await this.device.gatt.disconnect();
    }
    this.isConnected = false;
    this.characteristic = null;
    this.device = null;
  }

  // 6. Convert Uint8Array to Base64 String for Android Bridges & Intents
  public uint8ArrayToBase64(bytes: Uint8Array): string {
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  }

  // 7. Generate Raw Plain Text for Printers or fallback
  public buildPlainTextReceipt(data: ReceiptData, maxCols: number = 32): string {
    const lines: string[] = [];
    const hr = '-'.repeat(maxCols);
    const formatCols = (left: string, right: string): string => {
      const space = maxCols - left.length - right.length;
      return space > 0 ? left + ' '.repeat(space) + right : left + ' ' + right;
    };

    lines.push(data.storeHeader.storeName || 'STRUK TRANSAKSI');
    if (data.storeHeader.storeAddress) lines.push(data.storeHeader.storeAddress);
    if (data.storeHeader.storeContact) lines.push(data.storeHeader.storeContact);
    lines.push(hr);
    lines.push(data.receiptTitle || 'Bukti Transaksi');
    if (data.productName) lines.push(data.productName);
    lines.push(hr);
    if (data.transactionDate || data.transactionTime) {
      lines.push(formatCols('TGL TRANS', `${data.transactionDate} ${data.transactionTime}`.trim()));
    }
    if (data.customerName) lines.push(formatCols('NAMA', data.customerName));
    if (data.idpel) lines.push(formatCols('IDPEL', data.idpel));
    if (data.meterNumber) lines.push(formatCols('NO METER', data.meterNumber));
    if (data.tarifDaya) lines.push(formatCols('TARIF/DAYA', data.tarifDaya));
    if (data.destinationNumber) lines.push(formatCols('NO TUJUAN', data.destinationNumber));
    if (data.serialNumber) {
      lines.push('SERIAL:');
      lines.push(data.serialNumber);
    }
    if (data.tokenListrik) {
      lines.push(hr);
      lines.push('STROOM / TOKEN LISTRIK:');
      lines.push(data.tokenListrik);
      if (data.kwh) lines.push(`JML KWH: ${data.kwh}`);
    }
    lines.push(hr);
    if (data.tagihan) lines.push(formatCols('TAGIHAN', data.tagihan));
    if (data.adminFee) lines.push(formatCols('ADMIN', data.adminFee));
    lines.push(formatCols('TOTAL BAYAR', data.totalBayar));
    if (data.paymentMethod) lines.push(formatCols('METODE', data.paymentMethod));
    if (data.infoNote) {
      lines.push(hr);
      lines.push(data.infoNote);
    }
    if (data.footerNote) lines.push(data.footerNote);
    lines.push('\n\n\n');

    return lines.join('\n');
  }

  // 8. Print to Bluetooth Printer using Phone System Pairing / APK / Intent
  public async printReceipt(
    data: ReceiptData, 
    paperWidth: '58mm' | '80mm' = '58mm',
    preferMode?: 'apk_bridge' | 'android_intent' | 'web_bluetooth'
  ): Promise<{ success: boolean; method: string; message: string }> {
    const maxCols = paperWidth === '80mm' ? 48 : 32;
    const escposBytes = this.buildEscPosCommands(data, maxCols);
    const base64Data = this.uint8ArrayToBase64(escposBytes);
    const plainText = this.buildPlainTextReceipt(data, maxCols);

    // MODE A: Check Android APK Bridge (window.Android / window.AndroidPrinter)
    if (preferMode === 'apk_bridge' || (!preferMode && this.isAndroidApk())) {
      if (window.Android?.printReceipt) {
        try {
          window.Android.printReceipt(base64Data, paperWidth);
          return { success: true, method: 'apk_bridge', message: 'Struk dikirim melalui Android Native Bridge!' };
        } catch (e: any) {
          console.warn('Android bridge error:', e);
        }
      }

      if (window.Android?.print) {
        try {
          window.Android.print(base64Data);
          return { success: true, method: 'apk_bridge', message: 'Struk dikirim melalui Android Bridge (print)!' };
        } catch (e: any) {
          console.warn('Android bridge error:', e);
        }
      }

      if (window.AndroidPrinter?.print) {
        try {
          window.AndroidPrinter.print(base64Data);
          return { success: true, method: 'apk_bridge', message: 'Struk dikirim melalui AndroidPrinter Bridge!' };
        } catch (e: any) {
          console.warn('AndroidPrinter bridge error:', e);
        }
      }

      if (window.bluetoothSerial?.write) {
        return new Promise((resolve) => {
          // Convert to ArrayBuffer
          const buffer = escposBytes.buffer;
          window.bluetoothSerial!.write(
            buffer,
            () => resolve({ success: true, method: 'bluetoothSerial', message: 'Struk dikirim via BluetoothSerial!' }),
            (err) => resolve({ success: false, method: 'bluetoothSerial', message: `Gagal BluetoothSerial: ${err}` })
          );
        });
      }
    }

    // MODE B: If connected via Web Bluetooth GATT
    if (this.characteristic && (preferMode === 'web_bluetooth' || !preferMode)) {
      try {
        const chunkSize = 100;
        for (let i = 0; i < escposBytes.length; i += chunkSize) {
          const chunk = escposBytes.slice(i, i + chunkSize);
          if (this.characteristic.properties.writeWithoutResponse) {
            await this.characteristic.writeValueWithoutResponse(chunk);
          } else {
            await this.characteristic.writeValue(chunk);
          }
          await new Promise((resolve) => setTimeout(resolve, 30));
        }
        return { success: true, method: 'web_bluetooth', message: 'Struk berhasil dicetak via Web Bluetooth!' };
      } catch (err: any) {
        console.warn('Web Bluetooth write failed, trying fallback...', err);
      }
    }

    // MODE C: Android Intent (RawBT / Bluetooth Print Service)
    // RawBT is the universal Android thermal printing app in Indonesia that links directly to paired Bluetooth devices!
    if (preferMode === 'android_intent' || typeof window !== 'undefined') {
      try {
        // Try RawBT Intent scheme (auto-prints to Android's paired bluetooth printer)
        const rawBtUrl = `rawbt:base64,${base64Data}`;
        const intentUrl = `intent:base64,${base64Data}#Intent;scheme=rawbt;package=ru.a402d.rawbtprinter;S.title=Struk%20PPOB;end;`;

        // Create invisible link to launch intent
        const link = document.createElement('a');
        link.href = intentUrl;
        link.style.display = 'none';
        document.body.appendChild(link);
        link.click();
        setTimeout(() => document.body.removeChild(link), 500);

        return { 
          success: true, 
          method: 'android_intent', 
          message: 'Struk dikirim ke layanan printer Bluetooth Android (RawBT / Layanan Cetak HP).' 
        };
      } catch (err: any) {
        console.error('Intent error:', err);
      }
    }

    // Fallback: Browser Print Spooler
    window.print();
    return { success: true, method: 'system_print', message: 'Membuka dialog cetak sistem HP.' };
  }

  // 9. Build ESC/POS Byte Commands
  public buildEscPosCommands(data: ReceiptData, maxCols: number = 32): Uint8Array {
    const commands: number[] = [];

    const append = (bytes: number[]) => {
      commands.push(...bytes);
    };

    const appendText = (text: string) => {
      const encoder = new TextEncoder();
      const encoded = encoder.encode(text);
      for (let i = 0; i < encoded.length; i++) {
        commands.push(encoded[i]);
      }
    };

    const appendLine = (text: string = '') => {
      appendText(text + '\n');
    };

    const formatCols = (left: string, right: string): string => {
      const spaceNeeded = maxCols - left.length - right.length;
      if (spaceNeeded > 0) {
        return left + ' '.repeat(spaceNeeded) + right;
      }
      return left + ' ' + right;
    };

    const hr = (char = '-') => char.repeat(maxCols);

    // Initialize printer
    append([0x1b, 0x40]); // ESC @

    // 1. HEADER (Centered)
    append([0x1b, 0x61, 0x01]); // Align Center
    append([0x1b, 0x45, 0x01]); // Bold ON
    appendLine(data.storeHeader.storeName || 'STRUK TRANSAKSI');
    append([0x1b, 0x45, 0x00]); // Bold OFF

    if (data.storeHeader.storeAddress) {
      const addrLines = data.storeHeader.storeAddress.split('\n');
      for (const line of addrLines) {
        if (line.trim()) appendLine(line.trim());
      }
    }
    if (data.storeHeader.storeNpwp) {
      appendLine(`NPWP: ${data.storeHeader.storeNpwp}`);
    }
    if (data.storeHeader.headerNote) {
      appendLine(data.storeHeader.headerNote);
    }

    appendLine(hr('-'));

    // 2. RECEIPT TITLE & PRODUCT (Centered or Left)
    append([0x1b, 0x61, 0x01]); // Center
    append([0x1b, 0x45, 0x01]); // Bold ON
    appendLine(data.receiptTitle || 'Bukti Transaksi');
    append([0x1b, 0x45, 0x00]); // Bold OFF
    if (data.productName) {
      appendLine(data.productName);
    }

    append([0x1b, 0x61, 0x00]); // Align Left
    appendLine(hr('-'));

    // 3. DATE & TIME
    if (data.transactionDate || data.transactionTime) {
      appendLine(formatCols('TGL TRANS', `${data.transactionDate} ${data.transactionTime}`.trim()));
    }
    if (data.transactionId) {
      appendLine(formatCols('NO TRANSAKSI', data.transactionId));
    }
    if (data.referenceNumber) {
      appendLine(formatCols('NO. REF', data.referenceNumber.length > 16 ? data.referenceNumber.substring(0, 16) + '...' : data.referenceNumber));
    }

    // 4. TRANSACTION CONTENT
    if (data.customerName) {
      appendLine(formatCols('NAMA', data.customerName));
    }
    if (data.destinationNumber) {
      appendLine(formatCols('NO TUJUAN', data.destinationNumber));
    }
    if (data.idpel) {
      appendLine(formatCols('IDPEL', data.idpel));
    }
    if (data.meterNumber) {
      appendLine(formatCols('NO METER', data.meterNumber));
    }
    if (data.tarifDaya) {
      appendLine(formatCols('TARIF/DAYA', data.tarifDaya));
    }
    if (data.periode) {
      appendLine(formatCols('PERIODE', data.periode));
    }
    if (data.standMeter) {
      appendLine(formatCols('STAND METER', data.standMeter));
    }
    if (data.serialNumber) {
      appendLine('SERIAL:');
      append([0x1b, 0x45, 0x01]);
      appendLine(data.serialNumber);
      append([0x1b, 0x45, 0x00]);
    }

    // Special Token Listrik Highlight
    if (data.tokenListrik) {
      appendLine(hr('-'));
      append([0x1b, 0x61, 0x01]); // Center
      append([0x1b, 0x45, 0x01]); // Bold
      appendLine('STROOM / TOKEN LISTRIK:');
      append([0x1d, 0x21, 0x11]); // Double height & width
      appendLine(data.tokenListrik);
      append([0x1d, 0x21, 0x00]); // Normal size
      append([0x1b, 0x45, 0x00]); // Bold OFF
      if (data.kwh) {
        appendLine(`JML KWH: ${data.kwh}`);
      }
      append([0x1b, 0x61, 0x00]); // Left
    }

    // 5. FINANCIAL DETAILS
    appendLine(hr('-'));
    if (data.tagihan) {
      appendLine(formatCols('TAGIHAN', data.tagihan));
    }
    if (data.adminFee) {
      appendLine(formatCols('BIAYA ADMIN', data.adminFee));
    }
    if (data.discount && data.discount !== 'Rp0' && data.discount !== 'Rp.0,-') {
      appendLine(formatCols('DISKON', data.discount));
    }

    append([0x1b, 0x45, 0x01]); // Bold ON
    appendLine(formatCols('TOTAL BAYAR', data.totalBayar));
    append([0x1b, 0x45, 0x00]); // Bold OFF

    if (data.paymentMethod) {
      appendLine(formatCols('METODE BAYAR', data.paymentMethod));
    }

    // 6. CUSTOM ROWS
    if (data.customRows && data.customRows.length > 0) {
      appendLine(hr('-'));
      for (const row of data.customRows) {
        appendLine(formatCols(row.label, row.value));
      }
    }

    // 7. FOOTER
    appendLine(hr('-'));
    append([0x1b, 0x61, 0x01]); // Center

    if (data.infoNote) {
      appendLine(data.infoNote);
      appendLine('');
    }

    if (data.footerNote) {
      const footerLines = data.footerNote.split('\n');
      for (const line of footerLines) {
        if (line.trim()) appendLine(line.trim());
      }
    }

    if (data.storeHeader.storeContact) {
      appendLine('');
      appendLine(data.storeHeader.storeContact);
    }

    // Feed lines & cut
    appendLine('\n\n\n');
    append([0x1d, 0x56, 0x41, 0x00]); // Partial Cut paper

    return new Uint8Array(commands);
  }
}

export const bluetoothPrinterService = new BluetoothThermalPrinter();
