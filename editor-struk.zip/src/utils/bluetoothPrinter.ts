import { ReceiptData } from '../types';
import html2canvas from 'html2canvas';

// Declare global window interfaces for Android WebView Bridge
declare global {
  interface Window {
    AndroidPrinter?: {
      isApkMode?: () => boolean;
      isBluetoothEnabled?: () => boolean;
      getBondedDevices?: () => string;
      printEscPos?: (macAddress: string, base64Data: string) => string;
      printImage?: (macAddress: string, base64Image: string) => string;
      print?: (base64Data: string) => boolean | string;
    };
    Android?: {
      printReceipt?: (base64Data: string, paperWidth: string) => boolean | string;
      print?: (data: string) => boolean | string;
      getPairedDevices?: () => string;
      connectDevice?: (addressOrName: string) => boolean;
      isPrinterConnected?: () => boolean;
    };
    bluetoothSerial?: {
      list: (success: (devices: Array<{ name: string; address: string; id?: string }>) => void, failure: (err: any) => void) => void;
      connect: (address: string, success: () => void, failure: (err: any) => void) => void;
      write: (data: any, success: () => void, failure: (err: any) => void) => void;
      isConnected: (success: () => void, failure: () => void) => void;
      disconnect: (success?: () => void, failure?: () => void) => void;
    };
  }
}

export interface PairedDeviceInfo {
  name: string;
  address: string;
}

// Layanan UUID Bluetooth thermal printer umum
export const THERMAL_PRINTER_SERVICES = [
  '000018f0-0000-1000-8000-00805f9b34fb',
  'e7810a71-73ae-499d-8c15-faa9aef0c3f2',
  '49535343-fe7d-4ae5-8fa9-9fafd205e455',
  '0000ffe0-0000-1000-8000-00805f9b34fb',
  '0000fff0-0000-1000-8000-00805f9b34fb',
  '49535343-8841-43f4-a8d4-ecbe34729bb3',
];

export class BluetoothThermalPrinter {
  public selectedAddress: string = '';
  public deviceName: string = '';
  private webBluetoothDevice: any = null;
  private webBluetoothCharacteristic: any = null;

  constructor() {
    if (typeof window !== 'undefined') {
      const savedAddress = localStorage.getItem('strukppob_paired_printer_address');
      const savedName = localStorage.getItem('strukppob_paired_printer_name');
      if (savedAddress) this.selectedAddress = savedAddress;
      if (savedName) this.deviceName = savedName;
    }
  }

  // 1. Deteksi apakah sedang berjalan di APK Android atau di Browser Web (Chrome)
  public isRunningInApk(): boolean {
    if (typeof window === 'undefined') return false;
    // Jika ada bridge Java AndroidPrinter terdaftar
    if (window.AndroidPrinter?.isApkMode || window.AndroidPrinter?.getBondedDevices) return true;
    if (window.Android || window.bluetoothSerial) return true;
    // Deteksi Capacitor Android User Agent
    if (typeof navigator !== 'undefined' && /capacitor|android.*wv/i.test(navigator.userAgent)) {
      return true;
    }
    return false;
  }

  // 2. Ambil daftar printer bluetooth yang tersanding di HP (khusus mode APK)
  public async getBondedDevices(): Promise<PairedDeviceInfo[]> {
    if (typeof window === 'undefined') return [];

    // Coba dari AndroidPrinter Bridge resmi di APK
    if (window.AndroidPrinter?.getBondedDevices) {
      try {
        const jsonStr = window.AndroidPrinter.getBondedDevices();
        if (jsonStr) {
          const parsed = JSON.parse(jsonStr);
          if (Array.isArray(parsed) && parsed.length > 0) {
            return parsed.map((d: any) => ({
              name: d.name || 'Printer Bluetooth',
              address: d.address || '',
            }));
          }
        }
      } catch (e) {
        console.warn('Gagal membaca bonded devices dari AndroidPrinter:', e);
      }
    }

    // Coba dari window.Android Bridge alternatif
    if (window.Android?.getPairedDevices) {
      try {
        const jsonStr = window.Android.getPairedDevices();
        if (jsonStr) {
          const parsed = JSON.parse(jsonStr);
          if (Array.isArray(parsed) && parsed.length > 0) {
            return parsed.map((d: any) => ({
              name: d.name || 'Printer Bluetooth',
              address: d.address || '',
            }));
          }
        }
      } catch (e) {
        console.warn('Gagal membaca dari window.Android:', e);
      }
    }

    return [];
  }

  // 3. Simpan MAC address yang dipilih
  public setSelectedAddress(address: string, name?: string) {
    this.selectedAddress = address;
    if (name) this.deviceName = name;
    if (typeof window !== 'undefined') {
      localStorage.setItem('strukppob_paired_printer_address', address);
      if (name) localStorage.setItem('strukppob_paired_printer_name', name);
    }
  }

  // 4. Web Bluetooth: Hubungkan langsung dari Google Chrome Android
  public async connectWebBluetooth(): Promise<{ success: boolean; deviceName?: string; error?: string }> {
    if (typeof navigator === 'undefined' || !(navigator as any).bluetooth) {
      return {
        success: false,
        error: 'Browser ini belum mendukung Web Bluetooth. Disarankan menggunakan aplikasi APK yang diinstal di HP.',
      };
    }

    try {
      const device = await (navigator as any).bluetooth.requestDevice({
        acceptAllDevices: true,
        optionalServices: THERMAL_PRINTER_SERVICES,
      });

      if (!device) {
        return { success: false, error: 'Tidak ada perangkat yang dipilih' };
      }

      this.webBluetoothDevice = device;
      this.deviceName = device.name || 'Printer Thermal';
      this.selectedAddress = device.id || 'web_bluetooth';

      const server = await device.gatt.connect();
      
      // Cari karakteristik yang dapat ditulis (write/writeWithoutResponse)
      for (const serviceUuid of THERMAL_PRINTER_SERVICES) {
        try {
          const service = await server.getPrimaryService(serviceUuid);
          const characteristics = await service.getCharacteristics();
          for (const char of characteristics) {
            if (char.properties.write || char.properties.writeWithoutResponse) {
              this.webBluetoothCharacteristic = char;
              break;
            }
          }
          if (this.webBluetoothCharacteristic) break;
        } catch {
          // Lanjut ke service berikutnya
        }
      }

      if (!this.webBluetoothCharacteristic) {
        // Coba ambil semua service yang ada
        try {
          const services = await server.getPrimaryServices();
          for (const s of services) {
            const chars = await s.getCharacteristics();
            for (const c of chars) {
              if (c.properties.write || c.properties.writeWithoutResponse) {
                this.webBluetoothCharacteristic = c;
                break;
              }
            }
            if (this.webBluetoothCharacteristic) break;
          }
        } catch (e) {
          console.warn('Error discovering services:', e);
        }
      }

      return { success: true, deviceName: this.deviceName };
    } catch (err: any) {
      if (err.name === 'NotFoundError') {
        return { success: false, error: 'Pencarian perangkat dibatalkan' };
      }
      return { success: false, error: err.message || 'Gagal menghubungkan Bluetooth di browser' };
    }
  }

  // 5. Cetak ke Printer (Mendukung APK Native Bridge, Web Bluetooth, & RawBT Intent)
  public async printToPrinter(
    targetAddress: string,
    data: ReceiptData,
    paperWidth: '58mm' | '80mm',
    format: 'esc_pos' | 'graphics'
  ): Promise<{ success: boolean; message?: string; error?: string }> {
    const maxCols = paperWidth === '80mm' ? 48 : 32;

    // --- JALUR 1: Jika terkoneksi via Web Bluetooth di Browser Chrome ---
    if (this.webBluetoothCharacteristic) {
      try {
        const escposBytes = this.buildEscPosCommands(data, maxCols);
        const chunkSize = 100;
        for (let i = 0; i < escposBytes.length; i += chunkSize) {
          const chunk = escposBytes.slice(i, i + chunkSize);
          if (this.webBluetoothCharacteristic.properties.writeWithoutResponse) {
            await this.webBluetoothCharacteristic.writeValueWithoutResponse(chunk);
          } else {
            await this.webBluetoothCharacteristic.writeValue(chunk);
          }
          await new Promise((r) => setTimeout(r, 25));
        }
        return { success: true, message: `Struk berhasil dicetak ke ${this.deviceName} via Bluetooth Chrome!` };
      } catch (wbErr: any) {
        console.warn('Web Bluetooth write error:', wbErr);
      }
    }

    // --- JALUR 2: Mode APK Native Java Bridge ---
    if (window.AndroidPrinter?.printEscPos && targetAddress) {
      // Format grafis HD di APK
      if (format === 'graphics') {
        try {
          const base64Img = await this.renderReceiptToBase64(paperWidth);
          if (base64Img && window.AndroidPrinter.printImage) {
            const resStr = window.AndroidPrinter.printImage(targetAddress, base64Img);
            const res = JSON.parse(resStr);
            if (res.success) {
              return { success: true, message: res.message || 'Berhasil mencetak struk grafis HD!' };
            }
          }
        } catch (e) {
          console.warn('Graphics print failed, fallback to ESC/POS:', e);
        }
      }

      // Format teks ESC/POS tajam di APK
      try {
        const escposBytes = this.buildEscPosCommands(data, maxCols);
        const base64Data = this.uint8ArrayToBase64(escposBytes);
        const resStr = window.AndroidPrinter.printEscPos(targetAddress, base64Data);
        const res = JSON.parse(resStr);
        if (res.success) {
          return { success: true, message: res.message || 'Struk berhasil dicetak ke printer!' };
        } else {
          return { success: false, error: res.error || 'Gagal mengirim data ke printer' };
        }
      } catch (e: any) {
        return { success: false, error: e.message || 'Gagal komunikasi ke printer Bluetooth' };
      }
    }

    // --- JALUR 3: Jika di Browser Web Chrome, kirim ke aplikasi RawBT / Bluetooth Printer HP ---
    const escposBytes = this.buildEscPosCommands(data, maxCols);
    const base64Data = this.uint8ArrayToBase64(escposBytes);

    try {
      this.openRawBtDirect(base64Data);
      return {
        success: true,
        message: 'Membuka aplikasi cetak printer HP (RawBT)... Jika struk tidak keluar otomatis, pastikan aplikasi RawBT terpasang di HP.',
      };
    } catch {
      return {
        success: false,
        error: 'Tidak dapat mencetak langsung dari browser web. Silakan buka aplikasi Editor Struk versi APK yang diinstal di HP, atau gunakan tombol "Buka & Cetak di Tab Baru".',
      };
    }
  }

  // 6. Cetak via Tab Baru (Aman dari pembatasan iframe AI Studio)
  public printInNewTab(): void {
    const receiptEl = 
      document.getElementById('printable-receipt-container') || 
      document.getElementById('printable-receipt');

    if (!receiptEl) {
      window.print();
      return;
    }

    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      window.print();
      return;
    }

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Cetak Struk</title>
          <style>
            body {
              margin: 0;
              padding: 10px;
              display: flex;
              justify-content: center;
              font-family: monospace, sans-serif;
              background: #fff;
            }
            .receipt-wrap {
              width: 100%;
              max-width: 380px;
            }
            @media print {
              body { padding: 0; }
              .receipt-wrap { max-width: 100%; }
            }
          </style>
        </head>
        <body>
          <div class="receipt-wrap">
            ${receiptEl.innerHTML}
          </div>
          <script>
            window.onload = function() {
              setTimeout(function() {
                window.print();
              }, 300);
            };
          </script>
        </body>
      </html>
    `;

    printWindow.document.open();
    printWindow.document.write(htmlContent);
    printWindow.document.close();
  }

  // 7. Buka RawBT Printer Scheme
  public openRawBtDirect(base64Data: string): void {
    const intentUrl = `intent:base64,${base64Data}#Intent;scheme=rawbt;package=ru.a402d.rawbtprinter;S.title=Struk;end;`;
    window.location.href = intentUrl;
  }

  // 8. Render Struk ke Gambar Base64
  public async renderReceiptToBase64(paperWidth: '58mm' | '80mm'): Promise<string> {
    const receiptElement = 
      document.getElementById('printable-receipt-container') || 
      document.getElementById('printable-receipt');

    if (!receiptElement) throw new Error('Elemen struk tidak ditemukan');

    const canvas = await html2canvas(receiptElement, {
      scale: 2,
      backgroundColor: '#ffffff',
      useCORS: true,
      logging: false,
    });

    const targetWidth = paperWidth === '80mm' ? 576 : 384;
    const targetHeight = Math.round((canvas.height * targetWidth) / canvas.width);

    const scaledCanvas = document.createElement('canvas');
    scaledCanvas.width = targetWidth;
    scaledCanvas.height = targetHeight;
    const ctx = scaledCanvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, targetWidth, targetHeight);
      ctx.drawImage(canvas, 0, 0, targetWidth, targetHeight);
    }

    return scaledCanvas.toDataURL('image/jpeg', 0.9);
  }

  // 9. Bagikan Struk sebagai Gambar
  public async shareOrExportImage(): Promise<{ success: boolean; message?: string }> {
    try {
      const receiptElement = 
        document.getElementById('printable-receipt-container') || 
        document.getElementById('printable-receipt');

      if (!receiptElement) throw new Error('Elemen struk tidak ditemukan');

      const canvas = await html2canvas(receiptElement, {
        scale: 2,
        backgroundColor: '#ffffff',
        useCORS: true,
        logging: false,
      });

      return new Promise((resolve) => {
        canvas.toBlob(async (blob) => {
          if (!blob) {
            resolve({ success: false, message: 'Gagal membuat file gambar' });
            return;
          }

          const file = new File([blob], 'struk-transaksi.jpg', { type: 'image/jpeg' });

          if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
            try {
              await navigator.share({
                title: 'Struk Transaksi',
                text: 'Cetak Struk Transaksi',
                files: [file],
              });
              resolve({ success: true, message: 'Struk berhasil dibagikan!' });
              return;
            } catch (err: any) {
              if (err.name === 'AbortError') {
                resolve({ success: true, message: 'Berbagi dibatalkan' });
                return;
              }
            }
          }

          // Unduh gambar otomatis jika share API tidak didukung
          const url = URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = url;
          link.download = `struk-${Date.now()}.jpg`;
          link.click();
          URL.revokeObjectURL(url);
          resolve({ success: true, message: 'Gambar struk berhasil diunduh. Silakan buka di aplikasi printer Bluetooth Anda!' });
        }, 'image/jpeg', 0.95);
      });
    } catch (err: any) {
      return { success: false, message: err.message || 'Gagal memproses gambar struk' };
    }
  }

  // 10. Helper konversi Uint8Array ke Base64
  public uint8ArrayToBase64(bytes: Uint8Array): string {
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }

  // 11. Bangun Baris Perintah ESC/POS Lengkap
  public buildEscPosCommands(data: ReceiptData, maxCols: number = 32): Uint8Array {
    const commands: number[] = [];

    const append = (bytes: number[]) => {
      commands.push(...bytes);
    };

    const appendText = (text: string) => {
      const encoder = new TextEncoder();
      const encoded = encoder.encode(text);
      for (let i = 0; i < encoded.length; i++) {
        commands.push(encoded[i]);
      }
    };

    const appendLine = (text: string = '') => {
      appendText(text + '\n');
    };

    const formatCols = (left: string, right: string): string => {
      const spaceNeeded = maxCols - left.length - right.length;
      if (spaceNeeded > 0) {
        return left + ' '.repeat(spaceNeeded) + right;
      }
      return left + ' ' + right;
    };

    const hr = (char = '-') => char.repeat(maxCols);

    // Initialize printer (ESC @)
    append([0x1b, 0x40]);

    // 1. HEADER (Center)
    append([0x1b, 0x61, 0x01]); // Align Center
    append([0x1b, 0x45, 0x01]); // Bold ON
    appendLine(data.storeHeader.storeName || 'STRUK TRANSAKSI');
    append([0x1b, 0x45, 0x00]); // Bold OFF

    if (data.storeHeader.storeAddress) {
      const addrLines = data.storeHeader.storeAddress.split('\n');
      for (const line of addrLines) {
        if (line.trim()) appendLine(line.trim());
      }
    }
    if (data.storeHeader.storeNpwp) {
      appendLine(`NPWP: ${data.storeHeader.storeNpwp}`);
    }
    if (data.storeHeader.headerNote) {
      appendLine(data.storeHeader.headerNote);
    }

    appendLine(hr('-'));

    // 2. RECEIPT TITLE & PRODUCT (Center)
    append([0x1b, 0x61, 0x01]);
    append([0x1b, 0x45, 0x01]);
    appendLine(data.receiptTitle || 'Bukti Transaksi');
    append([0x1b, 0x45, 0x00]);
    if (data.productName) {
      appendLine(data.productName);
    }

    append([0x1b, 0x61, 0x00]); // Align Left
    appendLine(hr('-'));

    // 3. DATE & TIME
    if (data.transactionDate || data.transactionTime) {
      appendLine(formatCols('TGL TRANS', `${data.transactionDate} ${data.transactionTime}`.trim()));
    }
    if (data.transactionId) {
      appendLine(formatCols('NO TRANSAKSI', data.transactionId));
    }
    if (data.referenceNumber) {
      appendLine(formatCols('NO. REF', data.referenceNumber.length > 16 ? data.referenceNumber.substring(0, 16) + '...' : data.referenceNumber));
    }

    // 4. TRANSACTION CONTENT
    if (data.customerName) {
      appendLine(formatCols('NAMA', data.customerName));
    }
    if (data.destinationNumber) {
      appendLine(formatCols('NO TUJUAN', data.destinationNumber));
    }
    if (data.idpel) {
      appendLine(formatCols('IDPEL', data.idpel));
    }
    if (data.meterNumber) {
      appendLine(formatCols('NO METER', data.meterNumber));
    }
    if (data.tarifDaya) {
      appendLine(formatCols('TARIF/DAYA', data.tarifDaya));
    }
    if (data.periode) {
      appendLine(formatCols('PERIODE', data.periode));
    }
    if (data.standMeter) {
      appendLine(formatCols('STAND METER', data.standMeter));
    }
    if (data.serialNumber) {
      appendLine('SERIAL:');
      append([0x1b, 0x45, 0x01]);
      appendLine(data.serialNumber);
      append([0x1b, 0x45, 0x00]);
    }

    // Special Token Listrik Highlight
    if (data.tokenListrik) {
      appendLine(hr('-'));
      append([0x1b, 0x61, 0x01]); // Center
      append([0x1b, 0x45, 0x01]); // Bold
      appendLine('STROOM / TOKEN LISTRIK:');
      append([0x1d, 0x21, 0x11]); // Double height & width
      appendLine(data.tokenListrik);
      append([0x1d, 0x21, 0x00]); // Normal size
      append([0x1b, 0x45, 0x00]); // Bold OFF
      if (data.kwh) {
        appendLine(`JML KWH: ${data.kwh}`);
      }
      append([0x1b, 0x61, 0x00]); // Left
    }

    // 5. FINANCIAL DETAILS
    appendLine(hr('-'));
    if (data.tagihan) {
      appendLine(formatCols('TAGIHAN', data.tagihan));
    }
    if (data.adminFee) {
      appendLine(formatCols('BIAYA ADMIN', data.adminFee));
    }
    if (data.discount && data.discount !== 'Rp0' && data.discount !== 'Rp.0,-') {
      appendLine(formatCols('DISKON', data.discount));
    }

    append([0x1b, 0x45, 0x01]); // Bold ON
    appendLine(formatCols('TOTAL BAYAR', data.totalBayar));
    append([0x1b, 0x45, 0x00]); // Bold OFF

    if (data.paymentMethod) {
      appendLine(formatCols('METODE BAYAR', data.paymentMethod));
    }

    // 6. CUSTOM ROWS
    if (data.customRows && data.customRows.length > 0) {
      appendLine(hr('-'));
      for (const row of data.customRows) {
        appendLine(formatCols(row.label, row.value));
      }
    }

    // 7. FOOTER
    appendLine(hr('-'));
    append([0x1b, 0x61, 0x01]); // Center

    if (data.infoNote) {
      appendLine(data.infoNote);
      appendLine('');
    }

    if (data.footerNote) {
      const footerLines = data.footerNote.split('\n');
      for (const line of footerLines) {
        if (line.trim()) appendLine(line.trim());
      }
    }

    if (data.storeHeader.storeContact) {
      appendLine('');
      appendLine(data.storeHeader.storeContact);
    }

    // Feed lines & cut
    appendLine('\n\n\n');
    append([0x1d, 0x56, 0x41, 0x00]); // Partial cut

    return new Uint8Array(commands);
  }
}

export const bluetoothPrinterService = new BluetoothThermalPrinter();
