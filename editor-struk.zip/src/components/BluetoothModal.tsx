import React, { useState, useEffect } from 'react';
import { ReceiptData } from '../types';
import { bluetoothPrinterService, PairedDeviceInfo } from '../utils/bluetoothPrinter';
import { 
  Bluetooth, 
  Printer, 
  X, 
  CheckCircle2, 
  AlertTriangle, 
  RefreshCw, 
  Loader2,
  Smartphone,
  Code2,
  Copy,
  Check,
  Zap,
  Info,
  ExternalLink,
  Download,
  Package
} from 'lucide-react';
import { downloadProjectZip } from '../utils/downloadZip';

interface BluetoothModalProps {
  isOpen: boolean;
  onClose: () => void;
  receiptData: ReceiptData;
}

export const BluetoothModal: React.FC<BluetoothModalProps> = ({
  isOpen,
  onClose,
  receiptData,
}) => {
  const [activeTab, setActiveTab] = useState<'hp_pairing' | 'apk_guide' | 'web_ble'>('hp_pairing');
  const [isApkDetected, setIsApkDetected] = useState(false);
  const [pairedPrinterName, setPairedPrinterName] = useState('POS-58');
  const [deviceList, setDeviceList] = useState<PairedDeviceInfo[]>([]);
  const [isPrinting, setIsPrinting] = useState(false);
  const [isConnectingBle, setIsConnectingBle] = useState(false);
  const [isBleConnected, setIsBleConnected] = useState(false);
  const [paperWidth, setPaperWidth] = useState<'58mm' | '80mm'>(
    receiptData.paperPreset === '80mm' ? '80mm' : '58mm'
  );
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);
  const [copiedSnippet, setCopiedSnippet] = useState(false);
  const [isDownloadingZip, setIsDownloadingZip] = useState(false);
  const [zipDownloadText, setZipDownloadText] = useState('');

  const handleDownloadZip = async () => {
    try {
      setIsDownloadingZip(true);
      await downloadProjectZip((msg) => setZipDownloadText(msg));
      setTimeout(() => {
        setIsDownloadingZip(false);
        setZipDownloadText('');
      }, 3000);
    } catch (e) {
      console.error(e);
      setIsDownloadingZip(false);
      setZipDownloadText('Gagal mengunduh');
    }
  };

  useEffect(() => {
    if (!isOpen) return;

    const apk = bluetoothPrinterService.isAndroidApk();
    setIsApkDetected(apk);

    const savedName = localStorage.getItem('strukppob_paired_printer_name');
    if (savedName) {
      setPairedPrinterName(savedName);
    }

    setIsBleConnected(bluetoothPrinterService.isConnected);

    // Fetch paired devices from system/bridge if available
    bluetoothPrinterService.getPairedDevicesFromPhone().then((devices) => {
      setDeviceList(devices);
    });
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSelectPrinterName = (name: string) => {
    setPairedPrinterName(name);
    bluetoothPrinterService.setPairedDeviceName(name);
    setStatusMessage({ type: 'info', text: `Printer disetel ke: ${name}` });
  };

  // 1. Direct Print via Phone Paired Device / APK Bridge / Android Intent
  const handlePrintViaPhone = async () => {
    setIsPrinting(true);
    setStatusMessage(null);
    try {
      bluetoothPrinterService.setPairedDeviceName(pairedPrinterName);
      
      const result = await bluetoothPrinterService.printReceipt(
        receiptData, 
        paperWidth, 
        isApkDetected ? 'apk_bridge' : 'android_intent'
      );

      if (result.success) {
        setStatusMessage({ 
          type: 'success', 
          text: isApkDetected 
            ? `Berhasil! Struk dicetak ke printer tersanding ${pairedPrinterName} via APK.` 
            : `Struk dikirim ke layanan printer HP (${pairedPrinterName}). Jika menggunakan RawBT / Layanan Bluetooth HP, cetak akan langsung keluar.`
        });
      } else {
        setStatusMessage({ type: 'error', text: result.message });
      }
    } catch (err: any) {
      console.error('Print failed:', err);
      setStatusMessage({ type: 'error', text: err.message || 'Gagal mengirim cetak.' });
    } finally {
      setIsPrinting(false);
    }
  };

  // 2. Test Print via Phone
  const handleTestPrintPhone = async () => {
    setIsPrinting(true);
    try {
      const testData: ReceiptData = {
        ...receiptData,
        receiptTitle: 'TES PRINTER BLUETOOTH HP',
        productName: `Uji Coba Cetak (${pairedPrinterName})`,
        totalBayar: 'Rp0',
        footerNote: 'Printer Berhasil Terkoneksi ke HP!',
      };

      const result = await bluetoothPrinterService.printReceipt(
        testData, 
        paperWidth, 
        isApkDetected ? 'apk_bridge' : 'android_intent'
      );

      setStatusMessage({ 
        type: 'success', 
        text: result.message || 'Tes cetak berhasil dikirim!' 
      });
    } catch (err: any) {
      setStatusMessage({ type: 'error', text: err.message || 'Gagal tes cetak.' });
    } finally {
      setIsPrinting(false);
    }
  };

  // 3. Fallback Web Bluetooth connect
  const handleConnectBle = async () => {
    setIsConnectingBle(true);
    setStatusMessage(null);
    try {
      const res = await bluetoothPrinterService.connect();
      if (res.success) {
        setIsBleConnected(true);
        if (res.deviceName) {
          setPairedPrinterName(res.deviceName);
        }
        setStatusMessage({ type: 'success', text: `Web Bluetooth terhubung ke ${res.deviceName || 'Printer'}` });
      } else {
        setStatusMessage({ type: 'error', text: res.error || 'Gagal pairing Web Bluetooth.' });
      }
    } catch (err: any) {
      setStatusMessage({ type: 'error', text: err.message || 'Gagal koneksi Bluetooth.' });
    } finally {
      setIsConnectingBle(false);
    }
  };

  const popularPrinters = [
    'RPP02N',
    'POS-58',
    'PT-210',
    'Panda POS',
    'Iware MP-58',
    'MPT-II',
    'BellaV',
    'Goojprt',
  ];

  const apkCodeSnippet = `// Di Android Studio (MainActivity.java):
// 1. Aktifkan Javascript & Tambahkan Bridge
WebView myWebView = findViewById(R.id.webview);
myWebView.getSettings().setJavaScriptEnabled(true);

// 2. Tambahkan Interface "Android"
myWebView.addJavascriptInterface(new Object() {
    @JavascriptInterface
    public void printReceipt(String base64Data, String paperWidth) {
        // base64Data berisi byte ESC/POS lengkap dari aplikasi
        byte[] escPosBytes = android.util.Base64.decode(base64Data, android.util.Base64.DEFAULT);
        
        // Kirim langsung ke BluetoothSocket printer yang sudah dipairing di HP!
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        for (BluetoothDevice device : adapter.getBondedDevices()) {
            // Cocokkan printer thermal HP
            // Kirim escPosBytes melalui OutputStream socket Bluetooth
        }
    }

    @JavascriptInterface
    public String getPairedDevices() {
        // Mengembalikan daftar printer tersanding di HP dalam format JSON
        // Contoh: [{"name":"RPP02N","address":"66:22:BB:AA:33:11"}]
        return "[]";
    }
}, "Android");`;

  const copySnippet = () => {
    navigator.clipboard.writeText(apkCodeSnippet);
    setCopiedSnippet(true);
    setTimeout(() => setCopiedSnippet(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="w-full max-w-xl bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[94vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-white">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-blue-50 text-blue-600 border border-blue-200">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900">Bluetooth Printer Sistem HP & APK</h3>
                {isApkDetected ? (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                    APK Bridge Aktif
                  </span>
                ) : (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200">
                    Mode Siap APK
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500">
                Gunakan printer yang telah dipasangkan di Pengaturan Bluetooth HP
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-6 pt-2 gap-2 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('hp_pairing')}
            className={`pb-2.5 px-3 border-b-2 transition-all flex items-center gap-1.5 ${
              activeTab === 'hp_pairing'
                ? 'border-blue-600 text-blue-700 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            Penyandingan HP (APK)
          </button>
          <button
            onClick={() => setActiveTab('apk_guide')}
            className={`pb-2.5 px-3 border-b-2 transition-all flex items-center gap-1.5 ${
              activeTab === 'apk_guide'
                ? 'border-blue-600 text-blue-700 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Code2 className="w-3.5 h-3.5" />
            Panduan Bridge APK
          </button>
          <button
            onClick={() => setActiveTab('web_ble')}
            className={`pb-2.5 px-3 border-b-2 transition-all flex items-center gap-1.5 ${
              activeTab === 'web_ble'
                ? 'border-blue-600 text-blue-700 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Bluetooth className="w-3.5 h-3.5" />
            Web Bluetooth Browser
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-4 overflow-y-auto flex-1 text-sm">
          
          {/* TAB 1: HP PAIRING (PRIMARY) */}
          {activeTab === 'hp_pairing' && (
            <div className="space-y-4">
              {/* Info Box */}
              <div className="p-4 rounded-xl bg-blue-50/80 border border-blue-200 text-slate-800 text-xs space-y-2">
                <div className="flex items-center gap-2 text-blue-900 font-bold">
                  <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                  <span>Bebas Gagal: Printer Dipasangkan di Pengaturan Bluetooth HP</span>
                </div>
                <p className="text-slate-600 leading-relaxed">
                  Langkah praktis tanpa dialog izin browser:
                  <br />
                  1. Buka <b>Pengaturan HP &gt; Bluetooth &gt; Sandingkan Perangkat Baru</b>.
                  <br />
                  2. Hubungkan printer thermal Anda (PIN biasanya <b>0000</b> atau <b>1234</b>).
                  <br />
                  3. Saat dicetak dari APK / Layanan Cetak HP, struk langsung keluar tanpa perlu scan ulang.
                </p>
              </div>

              {/* Printer Name Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1.5">
                  Nama Printer yang Tersanding di HP:
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={pairedPrinterName}
                    onChange={(e) => handleSelectPrinterName(e.target.value)}
                    placeholder="Contoh: POS-58, RPP02N, PT-210"
                    className="flex-1 px-3.5 py-2.5 rounded-xl text-xs font-semibold bg-white border border-slate-300 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 shadow-2xs"
                  />
                </div>

                {/* Popular Printer Chips */}
                <div className="mt-2.5">
                  <span className="text-[11px] text-slate-500 font-medium block mb-1.5">
                    Pilihan Cepat Printer Kasir Populer:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {popularPrinters.map((p) => (
                      <button
                        key={p}
                        type="button"
                        onClick={() => handleSelectPrinterName(p)}
                        className={`px-2.5 py-1 rounded-lg text-xs transition-all border ${
                          pairedPrinterName === p
                            ? 'bg-blue-600 text-white border-blue-600 font-bold shadow-2xs'
                            : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200 font-medium'
                        }`}
                      >
                        {p}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Paper Width Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-2">Ukuran Kertas Thermal:</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setPaperWidth('58mm')}
                    className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition-all text-left ${
                      paperWidth === '58mm'
                        ? 'bg-blue-50 border-blue-400 text-blue-900 shadow-2xs'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    58mm (32 Karakter)
                    <span className="block text-[10px] font-normal text-slate-500 mt-0.5">Mini Bluetooth / Portable POS-58</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaperWidth('80mm')}
                    className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition-all text-left ${
                      paperWidth === '80mm'
                        ? 'bg-blue-50 border-blue-400 text-blue-900 shadow-2xs'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    80mm (48 Karakter)
                    <span className="block text-[10px] font-normal text-slate-500 mt-0.5">Printer Kasir Besar / POS-80</span>
                  </button>
                </div>
              </div>

              {/* APK Bridge Status Card */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`p-2.5 rounded-xl ${isApkDetected ? 'bg-emerald-100 text-emerald-700' : 'bg-blue-100 text-blue-700'}`}>
                    <Printer className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">
                      {isApkDetected ? 'Android APK Bridge Aktif' : 'Mode Siap Ekspor APK'}
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      Target: <span className="font-semibold text-slate-800">{pairedPrinterName}</span> ({paperWidth})
                    </div>
                  </div>
                </div>

                <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-slate-200 text-slate-700">
                  {isApkDetected ? 'Bridge Terkoneksi' : 'Sistem HP'}
                </span>
              </div>
            </div>
          )}

          {/* TAB 2: APK GUIDE & CODE */}
          {activeTab === 'apk_guide' && (
            <div className="space-y-3.5">
              {/* ZIP Download Card */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-red-50 via-rose-50 to-orange-50 border border-red-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-red-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                    <Package className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">Unduh Berkas Proyek Aplikasi (ZIP)</h4>
                    <p className="text-xs text-slate-600 mt-0.5">
                      Berisi seluruh source code aplikasi, ikon APK, dan file <code className="bg-red-100 text-red-800 px-1 py-0.2 rounded font-mono">.github/workflows/build-apk.yml</code> siap pakai.
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleDownloadZip}
                  disabled={isDownloadingZip}
                  className="w-full sm:w-auto px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 disabled:bg-red-400 text-white text-xs font-bold shrink-0 transition-all shadow-xs flex items-center justify-center gap-1.5 active:scale-95"
                >
                  {isDownloadingZip ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>{zipDownloadText || 'Menyiapkan ZIP...'}</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-3.5 h-3.5" />
                      <span>Unduh File ZIP</span>
                    </>
                  )}
                </button>
              </div>

              {/* Icon APK Card */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-emerald-50 to-blue-50 border border-emerald-200 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 rounded-2xl overflow-hidden shadow-md border-2 border-white shrink-0 bg-white">
                    <img
                      src="/app-icon.png"
                      alt="Ikon Editor Struk"
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">Ikon Resmi "Editor Struk"</h4>
                    <p className="text-xs text-slate-600 mt-0.5">
                      Resolusi tinggi (512x512 PNG), siap digunakan sebagai logo launcher aplikasi Android APK Anda.
                    </p>
                  </div>
                </div>
                <a
                  href="/app-icon.png"
                  download="app-icon-editor-struk.png"
                  className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shrink-0 transition-all shadow-xs flex items-center gap-1.5"
                >
                  <Copy className="w-3.5 h-3.5" />
                  Unduh Ikon
                </a>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1.5">
                <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                  <Code2 className="w-4 h-4 text-blue-600" />
                  Cara Membuat APK dengan Penyandingan Bluetooth HP:
                </h4>
                <p className="text-slate-600 leading-relaxed">
                  Aplikasi ini sudah otomatis menyediakan pemanggilan native bridge <code className="bg-slate-200 px-1 py-0.5 rounded text-blue-800 font-mono">window.Android.printReceipt(base64Data, paperWidth)</code>.
                  Saat Anda membungkus aplikasi ini ke dalam Android WebView di Android Studio, cukup tempel kode di bawah ini:
                </p>
              </div>

              {/* Code snippet with copy button */}
              <div className="relative rounded-xl bg-slate-900 text-slate-100 p-4 font-mono text-[11px] overflow-x-auto">
                <button
                  type="button"
                  onClick={copySnippet}
                  className="absolute top-3 right-3 flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-sans border border-slate-700 transition-colors"
                >
                  {copiedSnippet ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      Tersalin!
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      Salin Kode
                    </>
                  )}
                </button>
                <pre className="pr-16 text-slate-200">{apkCodeSnippet}</pre>
              </div>

              <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900">
                <p className="font-bold">Keuntungan Mode APK HP:</p>
                <p className="text-emerald-800 mt-0.5">
                  Dengan menggunakan bridge ini, pencetakan 100% menggunakan koneksi Bluetooth asli Android (SPP / RFCOMM). Printer cukup di-pair sekali di HP dan tidak akan pernah gagal karena batasan browser.
                </p>
              </div>
            </div>
          )}

          {/* TAB 3: WEB BLUETOOTH BROWSER */}
          {activeTab === 'web_ble' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs">
                <p className="font-bold">Mode Pengujian di Browser (Chrome)</p>
                <p className="text-amber-800 mt-0.5">
                  Web Bluetooth API memerlukan dialog popup browser. Di dalam APK WebView Android, mode ini sering tidak didukung, sehingga direkomendasikan memakai tab <b>Penyandingan HP (APK)</b>.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`p-2.5 rounded-xl ${isBleConnected ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-200 text-slate-500'}`}>
                    <Bluetooth className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">
                      {isBleConnected ? pairedPrinterName : 'Belum Tersambung via Web BLE'}
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      {isBleConnected ? 'Status: Siap Cetak Browser' : 'Gunakan jika membuka di Chrome'}
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleConnectBle}
                  disabled={isConnectingBle}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white transition-all shadow-2xs disabled:opacity-50"
                >
                  {isConnectingBle ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      Mencari...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="w-3.5 h-3.5" />
                      Scan Browser
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {/* Status Message */}
          {statusMessage && (
            <div
              className={`p-3.5 rounded-xl text-xs font-semibold flex items-start gap-2.5 ${
                statusMessage.type === 'success'
                  ? 'bg-emerald-50 border border-emerald-300 text-emerald-900'
                  : statusMessage.type === 'error'
                  ? 'bg-rose-50 border border-rose-300 text-rose-900'
                  : 'bg-blue-50 border border-blue-200 text-blue-900'
              }`}
            >
              {statusMessage.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />}
              {statusMessage.type === 'error' && <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />}
              {statusMessage.type === 'info' && <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />}
              <div className="leading-snug">{statusMessage.text}</div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="space-y-2 pt-2">
            <button
              type="button"
              onClick={handlePrintViaPhone}
              disabled={isPrinting}
              className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-all shadow-xs disabled:opacity-50"
            >
              {isPrinting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Mengirim ke Printer Bluetooth HP...
                </>
              ) : (
                <>
                  <Printer className="w-4 h-4" />
                  Cetak ke Printer Tersanding HP ({pairedPrinterName})
                </>
              )}
            </button>

            <button
              type="button"
              onClick={handleTestPrintPhone}
              disabled={isPrinting}
              className="w-full py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition-colors flex items-center justify-center gap-1.5"
            >
              <Zap className="w-3.5 h-3.5 text-amber-600" />
              Tes Cetak Kertas ke Printer HP
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
