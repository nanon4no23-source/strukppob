import React, { useState, useEffect } from 'react';
import { ReceiptData } from '../types';
import { bluetoothPrinterService, PairedDeviceInfo } from '../utils/bluetoothPrinter';
import { 
  Printer, 
  X, 
  CheckCircle2, 
  AlertTriangle, 
  Loader2,
  RefreshCw,
  Smartphone,
  Bluetooth,
  ChevronDown,
  ExternalLink,
  Globe,
  Share2
} from 'lucide-react';

interface BluetoothModalProps {
  isOpen: boolean;
  onClose: () => void;
  receiptData: ReceiptData;
}

export const BluetoothModal: React.FC<BluetoothModalProps> = ({
  isOpen,
  onClose,
  receiptData,
}) => {
  // Ukuran kertas
  const [paperWidth, setPaperWidth] = useState<'58mm' | '80mm'>(
    receiptData.paperPreset === '80mm' ? '80mm' : '58mm'
  );

  // Format cetak
  const [printFormat, setPrintFormat] = useState<'esc_pos' | 'graphics'>('esc_pos');

  // Status deteksi lingkungan
  const [isApk, setIsApk] = useState(false);
  const [pairedDevices, setPairedDevices] = useState<PairedDeviceInfo[]>([]);
  const [selectedAddress, setSelectedAddress] = useState<string>('');
  const [isLoadingDevices, setIsLoadingDevices] = useState(false);
  const [isConnectingWebBt, setIsConnectingWebBt] = useState(false);
  const [isPrinting, setIsPrinting] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  useEffect(() => {
    if (!isOpen) return;

    setStatusMessage(null);
    const inApk = bluetoothPrinterService.isRunningInApk();
    setIsApk(inApk);

    if (inApk) {
      loadPairedPrinters();
    } else {
      // Jika di browser Chrome
      setPairedDevices([]);
      if (bluetoothPrinterService.deviceName) {
        setSelectedAddress(bluetoothPrinterService.selectedAddress || 'web_bluetooth');
      }
    }
  }, [isOpen]);

  const loadPairedPrinters = async () => {
    setIsLoadingDevices(true);
    try {
      const list = await bluetoothPrinterService.getBondedDevices();
      setPairedDevices(list);

      const saved = localStorage.getItem('strukppob_paired_printer_address');
      if (saved && list.some(d => d.address === saved)) {
        setSelectedAddress(saved);
      } else if (list.length > 0) {
        setSelectedAddress(list[0].address);
        bluetoothPrinterService.setSelectedAddress(list[0].address, list[0].name);
      } else {
        setSelectedAddress('');
      }
    } catch (e: any) {
      console.error('Error loading devices:', e);
    } finally {
      setIsLoadingDevices(false);
    }
  };

  // Sambungkan via Web Bluetooth (Untuk pengguna Google Chrome Android)
  const handleConnectWebBluetooth = async () => {
    setIsConnectingWebBt(true);
    setStatusMessage({ type: 'info', text: 'Membuka pencarian Bluetooth Chrome di HP Anda...' });
    try {
      const res = await bluetoothPrinterService.connectWebBluetooth();
      if (res.success) {
        setStatusMessage({
          type: 'success',
          text: `Berhasil terhubung ke ${res.deviceName}! Silakan klik tombol "CETAK KE PRINTER".`,
        });
        setSelectedAddress('web_bluetooth');
      } else {
        setStatusMessage({
          type: 'error',
          text: res.error || 'Gagal menghubungkan Bluetooth Chrome.',
        });
      }
    } catch (e: any) {
      setStatusMessage({ type: 'error', text: e.message || 'Gagal menghubungkan printer' });
    } finally {
      setIsConnectingWebBt(false);
    }
  };

  const handleDeviceChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const address = e.target.value;
    setSelectedAddress(address);
    const chosen = pairedDevices.find(d => d.address === address);
    bluetoothPrinterService.setSelectedAddress(address, chosen?.name);
  };

  // Eksekusi Cetak Utama
  const handlePrint = async () => {
    setIsPrinting(true);
    setStatusMessage({ type: 'info', text: 'Mengirim struk ke printer...' });

    try {
      const res = await bluetoothPrinterService.printToPrinter(
        selectedAddress,
        receiptData,
        paperWidth,
        printFormat
      );

      if (res.success) {
        setStatusMessage({
          type: 'success',
          text: res.message || 'Struk berhasil dikirim ke printer!',
        });
      } else {
        setStatusMessage({
          type: 'error',
          text: res.error || 'Gagal mencetak. Silakan gunakan tombol "Buka & Cetak di Tab Baru" di bawah.',
        });
      }
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: err.message || 'Terjadi kesalahan saat mencetak.',
      });
    } finally {
      setIsPrinting(false);
    }
  };

  // Cetak via Tab Baru (Melewati blokade iframe preview AI Studio)
  const handlePrintInNewTab = () => {
    setStatusMessage({ type: 'info', text: 'Membuka dialog cetak di tab baru...' });
    bluetoothPrinterService.printInNewTab();
  };

  // Buka / Bagikan Gambar Struk
  const handleShare = async () => {
    setStatusMessage({ type: 'info', text: 'Menyiapkan struk...' });
    const res = await bluetoothPrinterService.shareOrExportImage();
    if (res.success) {
      setStatusMessage({ type: 'success', text: res.message || 'Berhasil!' });
    } else {
      setStatusMessage({ type: 'error', text: res.message || 'Gagal memproses struk' });
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="w-full max-w-lg bg-white border border-slate-200 rounded-3xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header Modal */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-slate-100 bg-white">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
              <Bluetooth className="w-5 h-5 text-indigo-600" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 leading-tight">
                Cetak ke Printer Bluetooth
              </h3>
              <p className="text-xs text-slate-500">Thermal 58/80mm</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Badge Mode Lingkungan */}
            {isApk ? (
              <div className="px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-1.5 shrink-0 shadow-2xs">
                <Smartphone className="w-3.5 h-3.5 text-emerald-600" />
                <span>Mode APK Android</span>
              </div>
            ) : (
              <div className="px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-800 text-xs font-semibold flex items-center gap-1.5 shrink-0 shadow-2xs">
                <Globe className="w-3.5 h-3.5 text-blue-600" />
                <span>Mode Google Chrome</span>
              </div>
            )}

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Isi Modal */}
        <div className="p-6 space-y-5">

          {/* Baris 1: Ukuran Lebar Kertas & Format Cetak */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Lebar Kertas */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-800">
                Ukuran Lebar Kertas:
              </label>
              <div className="grid grid-cols-2 p-1 bg-slate-100 border border-slate-200/80 rounded-xl text-xs font-bold">
                <button
                  type="button"
                  onClick={() => setPaperWidth('58mm')}
                  className={`py-2 px-2 rounded-lg transition-all text-center ${
                    paperWidth === '58mm'
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  58 mm (Standar)
                </button>
                <button
                  type="button"
                  onClick={() => setPaperWidth('80mm')}
                  className={`py-2 px-2 rounded-lg transition-all text-center ${
                    paperWidth === '80mm'
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  80 mm (Besar)
                </button>
              </div>
            </div>

            {/* Format Cetak */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-800">
                Format Cetak:
              </label>
              <div className="grid grid-cols-2 p-1 bg-slate-100 border border-slate-200/80 rounded-xl text-xs font-bold">
                <button
                  type="button"
                  onClick={() => setPrintFormat('esc_pos')}
                  className={`py-2 px-2 rounded-lg transition-all text-center ${
                    printFormat === 'esc_pos'
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Teks ESC/POS (Tajam)
                </button>
                <button
                  type="button"
                  onClick={() => setPrintFormat('graphics')}
                  className={`py-2 px-2 rounded-lg transition-all text-center ${
                    printFormat === 'graphics'
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Grafis HD
                </button>
              </div>
            </div>

          </div>

          {/* Baris 2: Koneksi Printer */}
          {isApk ? (
            /* Tampilan saat di APK */
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-800">
                  Pilih Printer Bluetooth Terpasang di HP:
                </label>
                <button
                  type="button"
                  onClick={loadPairedPrinters}
                  disabled={isLoadingDevices}
                  className="text-xs font-bold text-indigo-600 hover:text-indigo-700 flex items-center gap-1 active:scale-95 transition-all"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isLoadingDevices ? 'animate-spin' : ''}`} />
                  <span>Segarkan Daftar</span>
                </button>
              </div>

              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-600">
                  <Printer className="w-5 h-5" />
                </div>

                <select
                  value={selectedAddress}
                  onChange={handleDeviceChange}
                  className="w-full pl-11 pr-10 py-3.5 bg-white border border-slate-300 hover:border-indigo-400 focus:border-indigo-600 rounded-2xl text-sm font-semibold text-slate-900 shadow-2xs appearance-none focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 cursor-pointer"
                >
                  {pairedDevices.length === 0 ? (
                    <option value="">(Belum ada printer Bluetooth terdeteksi di HP)</option>
                  ) : (
                    pairedDevices.map((device) => (
                      <option key={device.address || device.name} value={device.address}>
                        {device.name} {device.address ? `(${device.address})` : ''}
                      </option>
                    ))
                  )}
                </select>

                <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center pointer-events-none text-slate-500">
                  <ChevronDown className="w-4 h-4" />
                </div>
              </div>
            </div>
          ) : (
            /* Tampilan saat dibuka di Google Chrome (seperti di screenshot pengguna) */
            <div className="space-y-3">
              <div className="p-3.5 bg-blue-50/80 border border-blue-200 rounded-2xl text-xs text-blue-900 space-y-2">
                <div className="flex items-center gap-2 font-bold text-blue-950">
                  <Globe className="w-4 h-4 text-blue-600 shrink-0" />
                  <span>Anda membuka di browser Google Chrome</span>
                </div>
                <p className="leading-relaxed text-slate-700">
                  Untuk mencetak langsung dari Chrome HP, klik tombol <b>Sambungkan Bluetooth (Chrome)</b> di bawah, lalu pilih printer thermal Anda pada jendela pop-up Chrome.
                </p>
                <button
                  type="button"
                  onClick={handleConnectWebBluetooth}
                  disabled={isConnectingWebBt}
                  className="w-full py-2.5 px-3 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white rounded-xl font-bold flex items-center justify-center gap-2 shadow-xs transition-all"
                >
                  {isConnectingWebBt ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Mencari Bluetooth Chrome...</span>
                    </>
                  ) : (
                    <>
                      <Bluetooth className="w-4 h-4" />
                      <span>{bluetoothPrinterService.deviceName ? `Terhubung: ${bluetoothPrinterService.deviceName} (Ubah)` : 'Sambungkan Bluetooth (Chrome)'}</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {/* Status Message Feedback */}
          {statusMessage && (
            <div
              className={`p-3.5 rounded-2xl text-xs flex items-start gap-2.5 border animate-in fade-in duration-150 ${
                statusMessage.type === 'success'
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                  : statusMessage.type === 'error'
                  ? 'bg-red-50 text-red-800 border-red-200'
                  : 'bg-indigo-50 text-indigo-900 border-indigo-200'
              }`}
            >
              {statusMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              ) : statusMessage.type === 'error' ? (
                <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              ) : (
                <Loader2 className="w-4 h-4 text-indigo-600 animate-spin shrink-0 mt-0.5" />
              )}
              <span className="leading-relaxed font-medium">{statusMessage.text}</span>
            </div>
          )}

          {/* Baris 3: Tombol Aksi Utama CETAK KE PRINTER */}
          <div className="space-y-3 pt-1">
            <button
              type="button"
              onClick={handlePrint}
              disabled={isPrinting}
              className="w-full py-4 px-6 rounded-2xl bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white font-black text-sm tracking-wide shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2.5 active:scale-98 transition-all"
            >
              {isPrinting ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>MENGIRIM KE PRINTER...</span>
                </>
              ) : (
                <>
                  <Printer className="w-5 h-5" />
                  <span>CETAK KE PRINTER</span>
                </>
              )}
            </button>

            {/* Opsi Cetak Alternatif Aman */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
              <button
                type="button"
                onClick={handlePrintInNewTab}
                className="py-3 px-3.5 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-800 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-colors border border-slate-200"
              >
                <ExternalLink className="w-4 h-4 text-slate-600" />
                <span>Buka & Cetak di Tab Baru</span>
              </button>

              <button
                type="button"
                onClick={handleShare}
                className="py-3 px-3.5 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-800 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-colors border border-slate-200"
              >
                <Share2 className="w-4 h-4 text-slate-600" />
                <span>Bagikan / Buka Gambar</span>
              </button>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-slate-100 bg-slate-50 flex items-center justify-between text-xs text-slate-500">
          <span>Kompatibel: MPT-II, POS-58, RPP02N, Panda, Iware</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl font-semibold text-slate-600 hover:bg-slate-200 transition-colors"
          >
            Tutup
          </button>
        </div>

      </div>
    </div>
  );
};
