import React, { useState, useEffect } from 'react';
import { ReceiptData } from '../types';
import { bluetoothPrinterService } from '../utils/bluetoothPrinter';
import { 
  Printer, 
  X, 
  CheckCircle2, 
  AlertTriangle, 
  Loader2,
  Smartphone,
  Zap,
  Share2,
  Send
} from 'lucide-react';

interface BluetoothModalProps {
  isOpen: boolean;
  onClose: () => void;
  receiptData: ReceiptData;
}

export const BluetoothModal: React.FC<BluetoothModalProps> = ({
  isOpen,
  onClose,
  receiptData,
}) => {
  const [isPrinting, setIsPrinting] = useState(false);
  const [paperWidth, setPaperWidth] = useState<'58mm' | '80mm'>(
    receiptData.paperPreset === '80mm' ? '80mm' : '58mm'
  );
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    setStatusMessage(null);
  }, [isOpen]);

  if (!isOpen) return null;

  // 1. Cetak Langsung via Dialog Cetak HP Android (Print Spooler)
  const handleSystemPrint = () => {
    setIsPrinting(true);
    setStatusMessage({ type: 'info', text: 'Membuka dialog cetak HP...' });
    setTimeout(() => {
      window.print();
      setIsPrinting(false);
      setStatusMessage({ 
        type: 'success', 
        text: 'Dialog cetak HP berhasil dibuka. Pilih printer Bluetooth Anda pada daftar printer.' 
      });
    }, 250);
  };

  // 2. Cetak via RawBT / Driver Printer Bluetooth Android
  const handleRawBtPrint = async () => {
    setIsPrinting(true);
    setStatusMessage(null);
    try {
      const res = await bluetoothPrinterService.printReceipt(receiptData, paperWidth, 'android_intent');
      setStatusMessage({ 
        type: 'success', 
        text: res.message || 'Struk dikirim ke aplikasi printer Bluetooth HP.' 
      });
    } catch (err: any) {
      setStatusMessage({ type: 'error', text: err.message || 'Gagal mengirim ke printer.' });
    } finally {
      setIsPrinting(false);
    }
  };

  // 3. Bagikan Struk via Menu Bluetooth / Aplikasi HP (Paling Universal)
  const handleShareToBluetooth = async () => {
    setIsPrinting(true);
    setStatusMessage(null);
    try {
      const plainText = bluetoothPrinterService.buildPlainTextReceipt(receiptData, paperWidth === '80mm' ? 48 : 32);

      if (navigator.share) {
        await navigator.share({
          title: `Struk - ${receiptData.productName || 'Transaksi'}`,
          text: plainText,
        });
        setStatusMessage({ type: 'success', text: 'Menu berbagi dibuka. Pilih Bluetooth atau printer Anda.' });
      } else {
        // Fallback salin teks
        await navigator.clipboard.writeText(plainText);
        setStatusMessage({ 
          type: 'info', 
          text: 'Teks struk berhasil disalin ke clipboard! Tempelkan ke aplikasi printer Bluetooth Anda.' 
        });
      }
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        setStatusMessage({ type: 'error', text: 'Gagal membagikan struk.' });
      }
    } finally {
      setIsPrinting(false);
    }
  };

  // 4. Tes Cetak Kertas Singkat
  const handleTestPrint = async () => {
    setIsPrinting(true);
    try {
      const testData: ReceiptData = {
        ...receiptData,
        receiptTitle: 'TES CETAK PRINTER',
        productName: 'Uji Coba Printer Bluetooth',
        totalBayar: 'Rp0',
        footerNote: 'Printer Berhasil Terhubung!',
      };
      await bluetoothPrinterService.printReceipt(testData, paperWidth, 'android_intent');
      setStatusMessage({ type: 'success', text: 'Perintah tes cetak berhasil dikirim!' });
    } catch (err: any) {
      setStatusMessage({ type: 'error', text: 'Gagal mengirim tes cetak.' });
    } finally {
      setIsPrinting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="w-full max-w-sm bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header Ringkas */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-emerald-50 text-emerald-600 border border-emerald-200 shadow-2xs">
              <Printer className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Cetak Printer Bluetooth</h3>
              <p className="text-[11px] text-slate-500">
                Hubungkan ke printer thermal HP
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Isi Ringkas */}
        <div className="p-5 space-y-4">
          
          {/* Pilihan Lebar Kertas */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200">
            <div>
              <span className="text-xs font-bold text-slate-800">Ukuran Kertas</span>
              <p className="text-[10px] text-slate-500">Standar kasir mini adalah 58mm</p>
            </div>
            <div className="flex rounded-lg bg-slate-200 p-0.5 text-[11px] font-bold">
              <button
                type="button"
                onClick={() => setPaperWidth('58mm')}
                className={`px-3 py-1 rounded-md transition-all ${
                  paperWidth === '58mm' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600'
                }`}
              >
                58 mm
              </button>
              <button
                type="button"
                onClick={() => setPaperWidth('80mm')}
                className={`px-3 py-1 rounded-md transition-all ${
                  paperWidth === '80mm' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600'
                }`}
              >
                80 mm
              </button>
            </div>
          </div>

          {/* Status Message */}
          {statusMessage && (
            <div
              className={`p-3 rounded-xl text-xs flex items-start gap-2 border ${
                statusMessage.type === 'success'
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                  : statusMessage.type === 'error'
                  ? 'bg-red-50 text-red-800 border-red-200'
                  : 'bg-blue-50 text-blue-800 border-blue-200'
              }`}
            >
              {statusMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              )}
              <span className="leading-relaxed">{statusMessage.text}</span>
            </div>
          )}

          {/* Tombol Cetak Utama */}
          <div className="space-y-2 pt-1">
            {/* 1. Cetak Langsung */}
            <button
              type="button"
              onClick={handleSystemPrint}
              disabled={isPrinting}
              className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-md shadow-emerald-600/25 flex items-center justify-center gap-2 active:scale-98 transition-all"
            >
              {isPrinting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Menyiapkan Cetak...</span>
                </>
              ) : (
                <>
                  <Printer className="w-4 h-4" />
                  <span>Cetak Langsung (Sistem HP)</span>
                </>
              )}
            </button>

            {/* 2. Kirim ke RawBT & Kirim via Bluetooth */}
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={handleRawBtPrint}
                disabled={isPrinting}
                className="py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-2xs active:scale-95 transition-all"
                title="Kirim ke aplikasi RawBT / ESC-POS printer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Kirim ke RawBT</span>
              </button>

              <button
                type="button"
                onClick={handleShareToBluetooth}
                disabled={isPrinting}
                className="py-2.5 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-2xs active:scale-95 transition-all"
                title="Bagikan teks struk via Bluetooth atau WhatsApp"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>Kirim Bluetooth</span>
              </button>
            </div>

            {/* 3. Tes Kertas */}
            <button
              type="button"
              onClick={handleTestPrint}
              disabled={isPrinting}
              className="w-full py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs border border-slate-300 flex items-center justify-center gap-1.5 active:scale-95 transition-all"
            >
              <Zap className="w-3.5 h-3.5 text-amber-500" />
              <span>Tes Kertas Printer</span>
            </button>
          </div>

          {/* Catatan Bawah */}
          <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-500 flex items-start gap-2">
            <Smartphone className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
            <span>Pastikan printer sudah dipasangkan (pair) di pengaturan Bluetooth HP Anda sebelum mencetak.</span>
          </div>

        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-100 bg-slate-50 flex items-center justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg text-xs font-semibold text-slate-600 hover:bg-slate-200 transition-colors"
          >
            Tutup
          </button>
        </div>

      </div>
    </div>
  );
};
