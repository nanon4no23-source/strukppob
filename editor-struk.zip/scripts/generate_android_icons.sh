#!/usr/bin/env bash
set -e

SOURCE_ICON="public/app-icon.png"
RES_DIR="android/app/src/main/res"

if [ ! -f "$SOURCE_ICON" ]; then
  echo "Error: Sumber icon $SOURCE_ICON tidak ditemukan!"
  exit 1
fi

echo "Memperbarui icon aplikasi Android dari $SOURCE_ICON..."

# Pastikan semua folder ada
mkdir -p "$RES_DIR/mipmap-mdpi"
mkdir -p "$RES_DIR/mipmap-hdpi"
mkdir -p "$RES_DIR/mipmap-xhdpi"
mkdir -p "$RES_DIR/mipmap-xxhdpi"
mkdir -p "$RES_DIR/mipmap-xxxhdpi"
mkdir -p "$RES_DIR/drawable"
mkdir -p "$RES_DIR/values"

if command -v convert >/dev/null 2>&1; then
  convert "$SOURCE_ICON" -resize 48x48 "$RES_DIR/mipmap-mdpi/ic_launcher.png"
  convert "$SOURCE_ICON" -resize 48x48 "$RES_DIR/mipmap-mdpi/ic_launcher_round.png"
  convert "$SOURCE_ICON" -resize 108x108 "$RES_DIR/mipmap-mdpi/ic_launcher_foreground.png"

  convert "$SOURCE_ICON" -resize 72x72 "$RES_DIR/mipmap-hdpi/ic_launcher.png"
  convert "$SOURCE_ICON" -resize 72x72 "$RES_DIR/mipmap-hdpi/ic_launcher_round.png"
  convert "$SOURCE_ICON" -resize 162x162 "$RES_DIR/mipmap-hdpi/ic_launcher_foreground.png"

  convert "$SOURCE_ICON" -resize 96x96 "$RES_DIR/mipmap-xhdpi/ic_launcher.png"
  convert "$SOURCE_ICON" -resize 96x96 "$RES_DIR/mipmap-xhdpi/ic_launcher_round.png"
  convert "$SOURCE_ICON" -resize 216x216 "$RES_DIR/mipmap-xhdpi/ic_launcher_foreground.png"

  convert "$SOURCE_ICON" -resize 144x144 "$RES_DIR/mipmap-xxhdpi/ic_launcher.png"
  convert "$SOURCE_ICON" -resize 144x144 "$RES_DIR/mipmap-xxhdpi/ic_launcher_round.png"
  convert "$SOURCE_ICON" -resize 324x324 "$RES_DIR/mipmap-xxhdpi/ic_launcher_foreground.png"

  convert "$SOURCE_ICON" -resize 192x192 "$RES_DIR/mipmap-xxxhdpi/ic_launcher.png"
  convert "$SOURCE_ICON" -resize 192x192 "$RES_DIR/mipmap-xxxhdpi/ic_launcher_round.png"
  convert "$SOURCE_ICON" -resize 432x432 "$RES_DIR/mipmap-xxxhdpi/ic_launcher_foreground.png"

  # Salin juga ke drawable
  convert "$SOURCE_ICON" -resize 432x432 "$RES_DIR/drawable/ic_launcher_foreground.png" || true
else
  cp "$SOURCE_ICON" "$RES_DIR/mipmap-mdpi/ic_launcher.png"
  cp "$SOURCE_ICON" "$RES_DIR/mipmap-mdpi/ic_launcher_round.png"
  cp "$SOURCE_ICON" "$RES_DIR/mipmap-hdpi/ic_launcher.png"
  cp "$SOURCE_ICON" "$RES_DIR/mipmap-hdpi/ic_launcher_round.png"
  cp "$SOURCE_ICON" "$RES_DIR/mipmap-xhdpi/ic_launcher.png"
  cp "$SOURCE_ICON" "$RES_DIR/mipmap-xhdpi/ic_launcher_round.png"
  cp "$SOURCE_ICON" "$RES_DIR/mipmap-xxhdpi/ic_launcher.png"
  cp "$SOURCE_ICON" "$RES_DIR/mipmap-xxhdpi/ic_launcher_round.png"
  cp "$SOURCE_ICON" "$RES_DIR/mipmap-xxxhdpi/ic_launcher.png"
  cp "$SOURCE_ICON" "$RES_DIR/mipmap-xxxhdpi/ic_launcher_round.png"
fi

# Set warna background icon adaptif menjadi hijau emerald
cat << 'EOF' > "$RES_DIR/values/ic_launcher_background.xml"
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_background">#059669</color>
</resources>
EOF

echo "Ikon aplikasi Android dan Adaptive Icon berhasil diperbarui ke logo kustom!"
