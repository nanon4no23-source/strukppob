package com.editorstruk.app;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import androidx.core.app.ActivityCompat;

import com.getcapacitor.BridgeActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends BridgeActivity {

    private static final String TAG = "EditorStrukPrinter";
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private PrinterBridge printerBridge;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        printerBridge = new PrinterBridge(this);

        // Minta izin Bluetooth di runtime untuk Android 12 ke atas
        checkAndRequestBluetoothPermissions();

        // Daftarkan JavascriptInterface ke WebView bawaan Capacitor
        registerJavascriptBridge();
    }

    @Override
    public void onResume() {
        super.onResume();
        registerJavascriptBridge();
    }

    private void registerJavascriptBridge() {
        try {
            if (this.bridge != null && this.bridge.getWebView() != null) {
                final WebView webView = this.bridge.getWebView();
                webView.post(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            webView.addJavascriptInterface(printerBridge, "AndroidPrinter");
                            Log.d(TAG, "AndroidPrinter bridge registered successfully!");
                        } catch (Exception e) {
                            Log.e(TAG, "Error adding JavascriptInterface: " + e.getMessage());
                        }
                    }
                });
            }
        } catch (Exception e) {
            Log.e(TAG, "registerJavascriptBridge failed: " + e.getMessage());
        }
    }

    private void checkAndRequestBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            List<String> permissionsNeeded = new ArrayList<>();
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(Manifest.permission.BLUETOOTH_CONNECT);
            }
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(Manifest.permission.BLUETOOTH_SCAN);
            }
            if (!permissionsNeeded.isEmpty()) {
                ActivityCompat.requestPermissions(this, permissionsNeeded.toArray(new String[0]), 101);
            }
        }
    }

    public class PrinterBridge {
        private final Context context;

        public PrinterBridge(Context context) {
            this.context = context;
        }

        @JavascriptInterface
        public boolean isApkMode() {
            return true;
        }

        @JavascriptInterface
        public boolean isBluetoothEnabled() {
            try {
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                return adapter != null && adapter.isEnabled();
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public String getBondedDevices() {
            JSONArray list = new JSONArray();
            try {
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter == null) {
                    return list.toString();
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    if (ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                        checkAndRequestBluetoothPermissions();
                        return list.toString();
                    }
                }

                Set<BluetoothDevice> pairedDevices = adapter.getBondedDevices();
                if (pairedDevices != null) {
                    for (BluetoothDevice device : pairedDevices) {
                        JSONObject obj = new JSONObject();
                        String name = device.getName();
                        String address = device.getAddress();
                        obj.put("name", (name != null && !name.trim().isEmpty()) ? name : "Printer Bluetooth");
                        obj.put("address", address != null ? address : "");
                        list.put(obj);
                    }
                }
            } catch (SecurityException se) {
                Log.w(TAG, "SecurityException getting bonded devices: " + se.getMessage());
            } catch (Exception e) {
                Log.e(TAG, "Error getting bonded devices: " + e.getMessage());
            }
            return list.toString();
        }

        @JavascriptInterface
        public String printEscPos(String macAddress, String base64Data) {
            BluetoothSocket socket = null;
            OutputStream out = null;
            try {
                if (macAddress == null || macAddress.trim().isEmpty()) {
                    return "{\"success\":false,\"error\":\"Alamat Bluetooth printer belum dipilih\"}";
                }

                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter == null) {
                    return "{\"success\":false,\"error\":\"Perangkat ini tidak mendukung Bluetooth\"}";
                }
                if (!adapter.isEnabled()) {
                    return "{\"success\":false,\"error\":\"Bluetooth HP belum aktif. Silakan nyalakan Bluetooth Anda.\"}";
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    if (ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                        checkAndRequestBluetoothPermissions();
                        return "{\"success\":false,\"error\":\"Izin Bluetooth di HP belum diberikan. Silakan izinkan akses Bluetooth.\"}";
                    }
                }

                byte[] data = Base64.decode(base64Data, Base64.DEFAULT);
                BluetoothDevice device = adapter.getRemoteDevice(macAddress.trim());

                try {
                    adapter.cancelDiscovery();
                } catch (Exception ignored) {}

                // Coba 1: Secure RFCOMM SPP standard
                boolean connected = false;
                try {
                    socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                    socket.connect();
                    connected = true;
                } catch (Exception e1) {
                    Log.w(TAG, "Koneksi 1 gagal: " + e1.getMessage());
                }

                // Coba 2: Insecure RFCOMM SPP
                if (!connected) {
                    try {
                        socket = device.createInsecureRfcommSocketToServiceRecord(SPP_UUID);
                        socket.connect();
                        connected = true;
                    } catch (Exception e2) {
                        Log.w(TAG, "Koneksi 2 gagal: " + e2.getMessage());
                    }
                }

                // Coba 3: Reflection port 1 (untuk printer portable model lama/tertentu)
                if (!connected) {
                    try {
                        Method m = device.getClass().getMethod("createRfcommSocket", int.class);
                        socket = (BluetoothSocket) m.invoke(device, 1);
                        if (socket != null) {
                            socket.connect();
                            connected = true;
                        }
                    } catch (Exception e3) {
                        Log.w(TAG, "Koneksi 3 gagal: " + e3.getMessage());
                    }
                }

                if (connected && socket != null && socket.isConnected()) {
                    out = socket.getOutputStream();
                    out.write(data);
                    out.flush();
                    try {
                        Thread.sleep(500); // Beri jeda cetak
                    } catch (InterruptedException ignored) {}

                    String devName = "Printer";
                    try {
                        devName = device.getName();
                    } catch (Exception ignored) {}

                    return "{\"success\":true,\"message\":\"Berhasil mencetak ke " + devName + "!\"}";
                } else {
                    return "{\"success\":false,\"error\":\"Tidak dapat terhubung ke printer. Pastikan printer menyala dan berada dalam jangkauan.\"}";
                }

            } catch (Exception e) {
                Log.e(TAG, "Print exception: " + e.getMessage());
                return "{\"success\":false,\"error\":\"Gagal mencetak: " + e.getMessage() + "\"}";
            } finally {
                try {
                    if (out != null) out.close();
                } catch (Exception ignored) {}
                try {
                    if (socket != null) socket.close();
                } catch (Exception ignored) {}
            }
        }

        @JavascriptInterface
        public String printImage(String macAddress, String base64Image) {
            try {
                String cleanBase64 = base64Image;
                if (cleanBase64.contains(",")) {
                    cleanBase64 = cleanBase64.substring(cleanBase64.indexOf(",") + 1);
                }
                byte[] decoded = Base64.decode(cleanBase64, Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(decoded, 0, decoded.length);
                if (bitmap == null) {
                    return "{\"success\":false,\"error\":\"Format gambar struk tidak valid\"}";
                }

                byte[] rasterBytes = convertBitmapToEscPos(bitmap);
                return printEscPos(macAddress, Base64.encodeToString(rasterBytes, Base64.NO_WRAP));

            } catch (Exception e) {
                return "{\"success\":false,\"error\":\"Gagal memproses grafis: " + e.getMessage() + "\"}";
            }
        }

        private byte[] convertBitmapToEscPos(Bitmap bitmap) {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            
            // ESC @ (Inisialisasi)
            baos.write(0x1B);
            baos.write(0x40);

            // Center alignment
            baos.write(0x1B);
            baos.write(0x61);
            baos.write(0x01);

            int width = bitmap.getWidth();
            int height = bitmap.getHeight();
            int widthBytes = (width + 7) / 8;

            // GS v 0 (Raster bit image)
            baos.write(0x1D);
            baos.write(0x76);
            baos.write(0x30);
            baos.write(0x00);
            baos.write(widthBytes % 256);
            baos.write(widthBytes / 256);
            baos.write(height % 256);
            baos.write(height / 256);

            for (int y = 0; y < height; y++) {
                for (int x = 0; x < widthBytes; x++) {
                    byte b = 0;
                    for (int bit = 0; bit < 8; bit++) {
                        int pixelX = x * 8 + bit;
                        if (pixelX < width) {
                            int pixel = bitmap.getPixel(pixelX, y);
                            int r = Color.red(pixel);
                            int g = Color.green(pixel);
                            int bColor = Color.blue(pixel);
                            int luminance = (int) (0.299 * r + 0.587 * g + 0.114 * bColor);
                            if (luminance < 165) {
                                b |= (1 << (7 - bit));
                            }
                        }
                    }
                    baos.write(b);
                }
            }

            // Feed & cut
            baos.write(0x0A);
            baos.write(0x0A);
            baos.write(0x0A);
            baos.write(0x1D);
            baos.write(0x56);
            baos.write(0x41);
            baos.write(0x00);

            return baos.toByteArray();
        }
    }
}
