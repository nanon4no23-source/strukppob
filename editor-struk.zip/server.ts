import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "25mb" }));
app.use(express.urlencoded({ extended: true, limit: "25mb" }));

// Lazy initialize Gemini client
let geminiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY belum dikonfigurasi pada server");
  }
  if (!geminiClient) {
    geminiClient = new GoogleGenAI({
      apiKey,
    });
  }
  return geminiClient;
}

// Health check endpoint
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Extract receipt endpoint using Gemini 3.8 Flash Vision
app.post("/api/extract-receipt", async (req, res) => {
  try {
    const { imageBase64, mimeType = "image/jpeg" } = req.body;
    if (!imageBase64) {
      return res.status(400).json({ success: false, error: "Data gambar tidak ditemukan" });
    }

    // Clean base64 string and extract mime type if present
    let cleanBase64 = imageBase64;
    let validMimeType = mimeType || "image/jpeg";

    if (imageBase64.includes(",")) {
      const parts = imageBase64.split(",");
      cleanBase64 = parts[1];
      const mimeMatch = parts[0].match(/:(.*?);/);
      if (mimeMatch && mimeMatch[1]) {
        validMimeType = mimeMatch[1];
      }
    }

    // Clean any whitespace/newlines
    cleanBase64 = cleanBase64.replace(/\s/g, "");

    const prompt = `Anda adalah sistem OCR cerdas dan parser struk transaksi PPOB & Kasir Indonesia (Token Listrik PLN, Pulsa/Paket Data, Tagihan Listrik Pascabayar, Tagihan WiFi/Indihome, Top Up E-Wallet, atau Struk Kasir Minimarket / Toko).
Analisis gambar struk / screenshot transaksi ini secara teliti, baca setiap teks, angka, dan tata letaknya.

Kembalikan data dalam format JSON murni dengan struktur berikut:
{
  "layoutStyle": "thermal_minimarket" | "digital_mitra",
  "category": "token_listrik" | "pulsa" | "tagihan_listrik" | "tagihan_wifi" | "topup_ewallet" | "retail" | "lainnya",
  "detectedPreset": "token_listrik_bukalapak" | "token_listrik_thermal" | "pulsa_telkomsel" | "paket_data_indosat" | "tagihan_listrik_bukalapak" | "tagihan_wifi_indihome" | "topup_ewallet_dana",
  "storeHeader": {
    "storeName": "Nama Toko / Minimarket / Agen (contoh: ALFAMART RAYA RAKIT atau SRC MASNGUD)",
    "storeAddress": "Alamat toko jika ada",
    "storeNpwp": "NPWP jika tertera",
    "storeContact": "No HP / CS / Call Center jika tertera",
    "headerNote": "Teks judul layanan di header jika ada (contoh: TELKOM PAY TELKOM INDIHOME atau STRUK PEMBAYARAN TAGIHAN LISTRIK)"
  },
  "receiptTitle": "Bukti Transaksi / STRUK PEMBAYARAN / TELKOM PAY",
  "productName": "Nama produk / layanan (contoh: Token Listrik Prabayar 50000, TELKOM INDIHOME, Telkomsel 10.000, dll)",
  "transactionDate": "Tanggal transaksi (contoh: 15 SEP 2026 atau 10-07-2026)",
  "transactionTime": "Jam transaksi (contoh: 21:51 WIB atau 16:44:03)",
  "customerName": "Nama Pelanggan jika ada",
  "meterNumber": "Nomor Meter jika PLN (11 atau 12 digit)",
  "idpel": "ID Pelanggan (IDPEL) jika ada (11-12 digit)",
  "tarifDaya": "Tarif/Daya jika listrik (contoh: R1M/900 VA atau R1/1300 VA)",
  "destinationNumber": "Nomor Tujuan / No HP untuk pulsa atau ewallet",
  "serialNumber": "Nomor Serial / SN pulsa jika ada",
  "referenceNumber": "No. Referensi / Ref ID transaksi jika ada",
  "transactionId": "No. Transaksi jika ada",
  "tokenListrik": "Nomor token listrik 20 digit jika ada (format kelompok 4 digit seperti 1760-1252-4112-3428-5165)",
  "kwh": "Jumlah KWH jika ada (contoh: 33,7 KWH)",
  "periode": "Periode tagihan jika ada (contoh: September 2026)",
  "standMeter": "Stand meter jika ada (contoh: 00020529-00020557)",
  "tagihan": "Nominal tagihan / harga dasar (contoh: Rp50.000)",
  "adminFee": "Biaya admin jika ada (contoh: Rp3.000)",
  "discount": "Diskon jika ada",
  "totalBayar": "Total bayar transaksi (contoh: Rp54.000)",
  "paymentMethod": "Tunai / Non Tunai / Saldo Mitra",
  "infoNote": "Catatan informasi di bawah token atau rincian",
  "footerNote": "Pesan informasi atau ucapan di bagian bawah struk",
  "customRows": [
    { "label": "Label baris tambahan jika ada", "value": "Nilai baris tambahan" }
  ]
}

PANDUAN KATEGORI & PRESET (SANGAT PENTING):
1. TOKEN LISTRIK PLN: Jika struk/screenshot memiliki 20 digit nomor token (atau ada kata TOKEN, STROOM, PLN PRABAYAR, KWH, NO METER):
   - WAJIB set category: "token_listrik"
   - Jika struk kertas kasir/thermal: detectedPreset: "token_listrik_thermal", layoutStyle: "thermal_minimarket"
   - Jika screenshot aplikasi Bukalapak/smartphone: detectedPreset: "token_listrik_bukalapak", layoutStyle: "digital_mitra"
   - Ekstrak 20 digit angka token ke "tokenListrik" (format: 4 digit dipisah tanda strip: XXXX-XXXX-XXXX-XXXX-XXXX)
   - Ekstrak No Meter ke "meterNumber", IDPEL ke "idpel", KWH ke "kwh", Daya ke "tarifDaya".
2. TAGIHAN LISTRIK PASCABAYAR: Jika PLN bulanan (ada stand meter, periode bulan, tanpa nomor token 20 digit):
   - category: "tagihan_listrik", detectedPreset: "tagihan_listrik_bukalapak"
3. PULSA / PAKET DATA: Jika transaksi pulsa, kuota, masa aktif:
   - category: "pulsa", detectedPreset: jika kuota internet "paket_data_indosat", jika pulsa nominal "pulsa_telkomsel"
   - Ekstrak nomor HP ke "destinationNumber" dan SN ke "serialNumber".
4. TAGIHAN WIFI: Jika Indihome, Telkom, internet kabel:
   - category: "tagihan_wifi", detectedPreset: "tagihan_wifi_indihome", layoutStyle: "thermal_minimarket"
5. TOPUP E-WALLET: Jika DANA, GoPay, ShopeePay, OVO:
   - category: "topup_ewallet", detectedPreset: "topup_ewallet_dana"

Respon HANYA teks JSON murni tanpa pembuka/penutup markdown.`;

    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: validMimeType,
              data: cleanBase64,
            },
          },
          { text: prompt },
        ],
      },
      config: {
        responseMimeType: "application/json",
      },
    });

    const responseText = response.text || "{}";
    let parsedData = {};
    try {
      const jsonStart = responseText.indexOf("{");
      const jsonEnd = responseText.lastIndexOf("}");
      if (jsonStart !== -1 && jsonEnd !== -1) {
        parsedData = JSON.parse(responseText.substring(jsonStart, jsonEnd + 1));
      } else {
        parsedData = JSON.parse(responseText.trim());
      }
    } catch {
      const cleaned = responseText.replace(/```json/gi, "").replace(/```/g, "").trim();
      parsedData = JSON.parse(cleaned);
    }

    res.json({
      success: true,
      data: parsedData,
    });
  } catch (error: any) {
    console.error("Error in extract-receipt:", error);
    res.status(500).json({
      success: false,
      error: "Gagal membaca struk dari gambar",
      details: error?.message || String(error),
    });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
