import { ReceiptData, ReceiptHistoryItem } from '../types';

export const HISTORY_STORAGE_KEY = 'struk_ppob_edit_history_v1';

export const loadHistory = (): ReceiptHistoryItem[] => {
  try {
    const raw = localStorage.getItem(HISTORY_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      return parsed.sort((a, b) => b.timestamp - a.timestamp);
    }
    return [];
  } catch (err) {
    console.error('Failed to load receipt history:', err);
    return [];
  }
};

export const saveToHistory = (data: ReceiptData): ReceiptHistoryItem[] => {
  try {
    const current = loadHistory();
    const timestamp = Date.now();

    // Determine customer/identifier
    let customerOrMeter = '';
    if (data.customerName && data.customerName.trim()) {
      customerOrMeter = data.customerName;
    } else if (data.meterNumber && data.meterNumber.trim()) {
      customerOrMeter = `Meter: ${data.meterNumber}`;
    } else if (data.idpel && data.idpel.trim()) {
      customerOrMeter = `IDPEL: ${data.idpel}`;
    } else if (data.destinationNumber && data.destinationNumber.trim()) {
      customerOrMeter = data.destinationNumber;
    }

    const newItem: ReceiptHistoryItem = {
      id: `hist_${timestamp}_${Math.random().toString(36).substring(2, 7)}`,
      timestamp,
      data: JSON.parse(JSON.stringify(data)),
      summary: {
        title: data.receiptTitle || 'Struk Transaksi',
        productName: data.productName || 'Produk Transaksi',
        totalBayar: data.totalBayar || 'Rp0',
        category: data.category,
        date: data.transactionDate || '',
        time: data.transactionTime || '',
        customerOrMeter: customerOrMeter || undefined,
        tokenListrik: data.tokenListrik || undefined,
        layoutStyle: data.layoutStyle,
        paperPreset: data.paperPreset,
      },
    };

    // Check if the most recent item is nearly identical (e.g. rapid edits of same receipt)
    // If so, update it instead of creating duplicates
    if (current.length > 0) {
      const top = current[0];
      const sameProduct = top.data.productName === data.productName;
      const sameTotal = top.data.totalBayar === data.totalBayar;
      const sameTokenOrMeter = top.data.tokenListrik === data.tokenListrik && top.data.meterNumber === data.meterNumber;
      const withinFiveMinutes = timestamp - top.timestamp < 5 * 60 * 1000;

      if (sameProduct && sameTotal && sameTokenOrMeter && withinFiveMinutes) {
        current[0] = newItem;
        localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(current.slice(0, 50)));
        return current;
      }
    }

    const updated = [newItem, ...current].slice(0, 50);
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(updated));
    return updated;
  } catch (err) {
    console.error('Failed to save to receipt history:', err);
    return loadHistory();
  }
};

export const deleteHistoryItem = (id: string): ReceiptHistoryItem[] => {
  try {
    const current = loadHistory();
    const updated = current.filter((item) => item.id !== id);
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(updated));
    return updated;
  } catch (err) {
    console.error('Failed to delete history item:', err);
    return loadHistory();
  }
};

export const clearAllHistory = (): void => {
  try {
    localStorage.removeItem(HISTORY_STORAGE_KEY);
  } catch (err) {
    console.error('Failed to clear history:', err);
  }
};
