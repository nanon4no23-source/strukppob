import { ReceiptData } from '../types';

export interface ExtractedReceiptResult {
  layoutStyle: 'thermal_minimarket' | 'digital_mitra';
  category: 'token_listrik' | 'pulsa' | 'tagihan_listrik' | 'tagihan_wifi' | 'topup_ewallet' | 'retail' | 'lainnya';
  detectedPreset?: string;
  storeHeader?: {
    storeName?: string;
    storeAddress?: string;
    storeContact?: string;
    headerNote?: string;
  };
  receiptTitle?: string;
  productName?: string;
  transactionDate?: string;
  transactionTime?: string;
  customerName?: string;
  meterNumber?: string;
  idpel?: string;
  tarifDaya?: string;
  destinationNumber?: string;
  serialNumber?: string;
  referenceNumber?: string;
  transactionId?: string;
  tokenListrik?: string;
  kwh?: string;
  periode?: string;
  standMeter?: string;
  tagihan?: string;
  adminFee?: string;
  totalBayar?: string;
}

/**
 * Parsing teks hasil OCR struk Indonesia secara lokal (Offline & Instan di HP)
 */
export function parseReceiptFromText(rawText: string): ExtractedReceiptResult {
  const text = rawText.toUpperCase();
  const lines = rawText.split('\n').map((l) => l.trim()).filter(Boolean);

  const result: ExtractedReceiptResult = {
    layoutStyle: 'thermal_minimarket',
    category: 'lainnya',
  };

  // 1. Deteksi Token Listrik 20 Digit (Format: 1234-5678-9012-3456-7890 atau 20 digit bersambung)
  const tokenRegex = /\b(\d{4})[-\s]?(\d{4})[-\s]?(\d{4})[-\s]?(\d{4})[-\s]?(\d{4})\b/;
  const tokenMatch = rawText.match(tokenRegex);
  if (tokenMatch) {
    result.tokenListrik = `${tokenMatch[1]}-${tokenMatch[2]}-${tokenMatch[3]}-${tokenMatch[4]}-${tokenMatch[5]}`;
    result.category = 'token_listrik';
    result.productName = 'Token Listrik Prabayar PLN';
    result.receiptTitle = 'STRUK PEMBELIAN LISTRIK PRABAYAR';
    result.detectedPreset = 'token_listrik_thermal';
  }

  // 2. Deteksi No Meter / IDPEL (11-12 digit)
  const idpelMatch = rawText.match(/(?:IDPEL|ID PELANGGAN|NO METER|NOMOR METER|METER|ID)\s*[:.]?\s*(\d{11,12})/i);
  if (idpelMatch) {
    result.idpel = idpelMatch[1];
    result.meterNumber = idpelMatch[1];
  } else {
    // Cari urutan 11 atau 12 digit jika belum ada token
    const any11to12 = rawText.match(/\b(14\d{9,10}|32\d{9,10}|5\d{10,11}|\d{11,12})\b/);
    if (any11to12 && (!result.tokenListrik || !result.tokenListrik.includes(any11to12[1]))) {
      result.idpel = any11to12[1];
      result.meterNumber = any11to12[1];
    }
  }

  // 3. Deteksi Nama Pelanggan
  const nameMatch = rawText.match(/(?:NAMA|NAMA PEL|NAMA PELANGGAN|CUST|PLG)\s*[:.]?\s*([A-Z0-9\s/.,'-]{3,30})/i);
  if (nameMatch) {
    const rawName = nameMatch[1].trim().split('\n')[0];
    result.customerName = rawName.replace(/TARIF|DAYA|KWH|TOTAL|RP/i, '').trim();
  }

  // 4. Deteksi Tarif / Daya (contoh: R1M/900 VA, R1/1300VA, B1/450)
  const tarifMatch = rawText.match(/(?:TARIF\/DAYA|TARIF|DAYA|TRF\/DAYA|TRF)\s*[:.]?\s*([A-Z0-9/]+(?:\s*(?:VA|WATT))?)/i);
  if (tarifMatch) {
    result.tarifDaya = tarifMatch[1].trim();
  } else {
    const inlineTarif = rawText.match(/\b(R[0-9][A-Z]?\s*\/\s*\d+\s*(?:VA)?)\b/i);
    if (inlineTarif) {
      result.tarifDaya = inlineTarif[1].trim();
    }
  }

  // 5. Deteksi KWH (contoh: 33,7 KWH atau 65.4)
  const kwhMatch = rawText.match(/(?:JML KWH|KWH|JUMLAH KWH)\s*[:.]?\s*([\d,.]+)/i) || rawText.match(/([\d,.]+)\s*KWH/i);
  if (kwhMatch) {
    result.kwh = `${kwhMatch[1].replace('.', ',')} KWH`;
  }

  // 6. Deteksi Total Bayar / RP Bayar
  const totalMatch = 
    rawText.match(/(?:TOTAL BAYAR|RP BAYAR|TOTAL|JUMLAH BAYAR|TAGIHAN)\s*[:.]?\s*(?:RP\.?|RP)?\s*([\d.,]{4,15})/i) ||
    rawText.match(/(?:RP\.?|RP)\s*([\d.,]{4,15})/i);
  if (totalMatch) {
    const cleanNum = totalMatch[1].trim();
    result.totalBayar = cleanNum.startsWith('Rp') ? cleanNum : `Rp${cleanNum}`;
  }

  // 7. Deteksi No Handphone / No Tujuan Pulsa
  const hpMatch = rawText.match(/\b(08[1-9][0-9]{7,10})\b/);
  if (hpMatch) {
    result.destinationNumber = hpMatch[1];
    if (result.category !== 'token_listrik') {
      result.category = 'pulsa';
      result.productName = 'Pulsa / Paket Data';
      result.detectedPreset = 'pulsa_telkomsel';
    }
  }

  // 8. Deteksi Tanggal & Jam
  const dateMatch = rawText.match(/\b(\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4})\b/) || rawText.match(/\b(\d{1,2}\s+(?:JAN|FEB|MAR|APR|MEI|JUN|JUL|AGU|SEP|OKT|NOV|DES)[A-Z]*\s+\d{2,4})\b/i);
  if (dateMatch) {
    result.transactionDate = dateMatch[1];
  }
  const timeMatch = rawText.match(/\b(\d{2}[:.]\d{2}(?:[:.]\d{2})?)\s*(?:WIB|WITA|WIT)?\b/i);
  if (timeMatch) {
    result.transactionTime = `${timeMatch[1]} WIB`;
  }

  // 9. Deteksi No Ref / SN
  const refMatch = rawText.match(/(?:NO\.?\s*REF|REF|NO\.?\s*REFERENSI)\s*[:.]?\s*([A-Z0-9]{6,25})/i);
  if (refMatch) {
    result.referenceNumber = refMatch[1];
  }
  const snMatch = rawText.match(/(?:SN|SERIAL|SERIAL NUMBER)\s*[:.]?\s*([A-Z0-9/]{8,30})/i);
  if (snMatch) {
    result.serialNumber = snMatch[1];
  }

  // 10. Deteksi Nama Toko / Header Toko
  for (let i = 0; i < Math.min(lines.length, 4); i++) {
    const line = lines[i];
    if (/ALFAMART|INDOMARET|AGEN|LOKET|KASIR|PPOB|WARUNG|TOKO|CELL|PULSA/i.test(line)) {
      result.storeHeader = {
        storeName: line.trim(),
      };
      break;
    }
  }

  // 11. Kategori Tagihan WiFi / Indihome
  if (/INDIHOME|TELKOM|SPEEDY|WIFI|FIBER/i.test(rawText)) {
    result.category = 'tagihan_wifi';
    result.productName = 'TELKOM INDIHOME';
    result.receiptTitle = 'TELKOM PAY';
    result.detectedPreset = 'tagihan_wifi_indihome';
  }

  // 12. Kategori E-Wallet (DANA, Gopay, OVO, ShopeePay)
  if (/DANA|GOPAY|OVO|SHOPEEPAY|LINKAJA/i.test(rawText)) {
    result.category = 'topup_ewallet';
    result.productName = 'Top Up Saldo E-Wallet';
    result.receiptTitle = 'BUKTI TRANSAKSI';
    result.detectedPreset = 'topup_ewallet_dana';
  }

  return result;
}
