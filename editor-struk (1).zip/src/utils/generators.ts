// Utility for generating random numbers and formatted data for Indonesian receipts

export function generateRandomTokenListrik(): string {
  const generate4Digits = () => Math.floor(1000 + Math.random() * 9000).toString();
  return `${generate4Digits()}-${generate4Digits()}-${generate4Digits()}-${generate4Digits()}-${generate4Digits()}`;
}

export function generateRandomSerial(): string {
  // Typical Indonesian telecom SN: 18-21 digits starting with carrier node codes (e.g. 0427, 0852, 2309)
  const prefix = ['0427', '0428', '0852', '0812', '2410', '0429'][Math.floor(Math.random() * 6)];
  let remaining = '';
  for (let i = 0; i < 15; i++) {
    remaining += Math.floor(Math.random() * 10).toString();
  }
  return prefix + remaining;
}

export function generateRandomReference(): string {
  // 32-character hexadecimal/alphanumeric reference ID like Bukalapak/BRI or 24-char
  const chars = '0123456789ABCDEF';
  let ref = '2BK';
  for (let i = 0; i < 29; i++) {
    ref += chars[Math.floor(Math.random() * chars.length)];
  }
  return ref;
}

export function generateRandomTransactionId(): string {
  return Math.floor(10000000 + Math.random() * 90000000).toString();
}

export function generateRandomStandMeter(): string {
  const base = Math.floor(15000 + Math.random() * 80000);
  const usage = Math.floor(50 + Math.random() * 250);
  const startStr = base.toString().padStart(8, '0');
  const endStr = (base + usage).toString().padStart(8, '0');
  return `${startStr}-${endStr}`;
}

export function generateCurrentDateTime() {
  const now = new Date();
  const months = ['JAN', 'FEB', 'MAR', 'APR', 'MEI', 'JUN', 'JUL', 'AGU', 'SEP', 'OKT', 'NOV', 'DES'];
  const day = String(now.getDate()).padStart(2, '0');
  const month = months[now.getMonth()];
  const year = now.getFullYear();
  
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const seconds = String(now.getSeconds()).padStart(2, '0');

  // Digital format: "15 SEP 2026", "21:51 WIB"
  const dateDigital = `${day} ${month} ${year}`;
  const timeDigital = `${hours}:${minutes} WIB`;

  // Thermal format: "10-07-2026", "16:44:03"
  const monthNum = String(now.getMonth() + 1).padStart(2, '0');
  const dateThermal = `${day}-${monthNum}-${year}`;
  const timeThermal = `${hours}:${minutes}:${seconds}`;

  return {
    date: dateDigital,
    time: timeDigital,
    dateDigital,
    timeDigital,
    dateThermal,
    timeThermal,
  };
}

export function calculateEstimatedKwh(nominalStr: string, dayaStr: string = '900'): string {
  const numericNominal = parseInt(nominalStr.replace(/[^0-9]/g, ''), 10) || 50000;
  // Net nominal after PPJ (~3-5%)
  const net = numericNominal * 0.95;
  let tariffPerKwh = 1352; // R1M 900VA subsidized approx ~1352
  if (dayaStr.includes('1300') || dayaStr.includes('2200')) {
    tariffPerKwh = 1444.70;
  } else if (dayaStr.includes('450')) {
    tariffPerKwh = 415;
  }
  const kwh = (net / tariffPerKwh).toFixed(1).replace('.', ',');
  return `${kwh} KWH`;
}

export function formatRupiah(val: string | number): string {
  const num = typeof val === 'number' ? val : parseInt(String(val).replace(/[^0-9]/g, ''), 10) || 0;
  return `Rp${num.toLocaleString('id-ID')}`;
}
