import JSZip from 'jszip';
import { GITHUB_WORKFLOW_YAML } from '../components/ApkExportModal';

export const CAPACITOR_CONFIG_JSON = `{
  "appId": "com.editorstruk.app",
  "appName": "Editor Struk",
  "webDir": "dist",
  "server": {
    "androidScheme": "https"
  }
}`;

/**
 * Downloads the project ZIP file safely.
 * Tries fetching the pre-built binary ZIP from the server first.
 * If running inside an iframe or offline where server returns HTML,
 * falls back to generating a valid ZIP archive on-the-fly using JSZip.
 */
export async function downloadProjectZip(onProgress?: (msg: string) => void): Promise<void> {
  onProgress?.('Mengunduh berkas ZIP...');

  try {
    const response = await fetch('/api/download-zip', {
      headers: {
        'Accept': 'application/zip, application/octet-stream, */*'
      }
    });

    const contentType = response.headers.get('content-type') || '';
    
    // Check if the response is genuinely a binary zip (not an HTML fallback)
    if (response.ok && !contentType.includes('text/html')) {
      const blob = await response.blob();
      if (blob.size > 50000) { // genuine zip is ~1.4MB
        triggerBlobDownload(blob, 'editor-struk.zip');
        onProgress?.('Berhasil mengunduh!');
        return;
      }
    }
  } catch (err) {
    console.warn('Direct zip fetch failed, falling back to JSZip generator', err);
  }

  // Fallback: Generate ZIP in-browser using JSZip
  onProgress?.('Menyiapkan paket ZIP mandiri...');
  const zip = new JSZip();

  // Add GitHub Actions workflow
  zip.file('.github/workflows/build-apk.yml', GITHUB_WORKFLOW_YAML);
  zip.file('capacitor.config.json', CAPACITOR_CONFIG_JSON);

  // Fetch critical assets if available
  try {
    const iconRes = await fetch('/app-icon.png');
    if (iconRes.ok) {
      const iconBlob = await iconRes.blob();
      zip.file('public/app-icon.png', iconBlob);
    }
  } catch {
    // Ignore icon fetch error
  }

  // Generate ZIP blob
  const zipBlob = await zip.generateAsync({ type: 'blob' });
  triggerBlobDownload(zipBlob, 'editor-struk.zip');
  onProgress?.('Berhasil mengunduh ZIP!');
}

function triggerBlobDownload(blob: Blob, filename: string) {
  const blobWithZipType = new Blob([blob], { type: 'application/zip' });
  const blobUrl = window.URL.createObjectURL(blobWithZipType);
  const a = document.createElement('a');
  a.style.display = 'none';
  a.href = blobUrl;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    document.body.removeChild(a);
    window.URL.revokeObjectURL(blobUrl);
  }, 1000);
}
