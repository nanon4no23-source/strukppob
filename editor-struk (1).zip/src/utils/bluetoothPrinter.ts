import { ReceiptData } from '../types';
import html2canvas from 'html2canvas';

// Declare global window interfaces for Android WebView Bridge and Cordova/Capacitor
declare global {
  interface Window {
    AndroidPrinter?: {
      isApkMode?: () => boolean;
      isBluetoothEnabled?: () => boolean;
      getBondedDevices?: () => string; // Returns JSON string of [{ name, address }]
      printEscPos?: (macAddress: string, base64Data: string) => string; // Returns JSON string
      printImage?: (macAddress: string, base64Image: string) => string;
      print?: (base64Data: string) => boolean | string;
    };
    Android?: {
      printReceipt?: (base64Data: string, paperWidth: string) => boolean | string;
      print?: (data: string) => boolean | string;
      getPairedDevices?: () => string;
      connectDevice?: (addressOrName: string) => boolean;
      isPrinterConnected?: () => boolean;
    };
    bluetoothSerial?: {
      list: (success: (devices: Array<{ name: string; address: string; id?: string }>) => void, failure: (err: any) => void) => void;
      connect: (address: string, success: () => void, failure: (err: any) => void) => void;
      write: (data: any, success: () => void, failure: (err: any) => void) => void;
      isConnected: (success: () => void, failure: () => void) => void;
      disconnect: (success?: () => void, failure?: () => void) => void;
    };
  }
}

// Common Bluetooth Low Energy Service UUIDs
export const THERMAL_PRINTER_SERVICES = [
  '000018f0-0000-1000-8000-00805f9b34fb',
  'e7810a71-73ae-499d-8c15-faa9aef0c3f2',
  '49535343-fe7d-4ae5-8fa9-9fafd205e455',
  '0000ffe0-0000-1000-8000-00805f9b34fb',
  '0000fff0-0000-1000-8000-00805f9b34fb',
  '49535343-8841-43f4-a8d4-ecbe34729bb3',
];

export interface PairedDeviceInfo {
  name: string;
  address: string;
}

export class BluetoothThermalPrinter {
  private device: any = null;
  private characteristic: any = null;
  public isConnected: boolean = false;
  public selectedAddress: string = '';
  public deviceName: string = '';

  constructor() {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('strukppob_paired_printer_address');
      if (saved) {
        this.selectedAddress = saved;
      }
    }
  }

  // 1. Deteksi apakah sedang berjalan di dalam APK Android
  public isAndroidApk(): boolean {
    if (typeof window === 'undefined') return false;
    if (window.AndroidPrinter?.isApkMode && window.AndroidPrinter.isApkMode()) return true;
    if (window.AndroidPrinter?.getBondedDevices) return true;
    if (window.Android || window.bluetoothSerial) return true;
    // Deteksi Capacitor Android User Agent
    if (typeof navigator !== 'undefined' && /android.*capacitor|capacitor.*android/i.test(navigator.userAgent)) {
      return true;
    }
    return false;
  }

  // 2. Ambil daftar printer bluetooth yang terpasang di HP Android
  public async getBondedDevices(): Promise<PairedDeviceInfo[]> {
    // 1. Coba dari AndroidPrinter Bridge
    if (window.AndroidPrinter?.getBondedDevices) {
      try {
        const jsonStr = window.AndroidPrinter.getBondedDevices();
        const parsed = JSON.parse(jsonStr);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.map((d: any) => ({
            name: d.name || 'Printer Bluetooth',
            address: d.address || '',
          }));
        }
      } catch (e) {
        console.warn('Error reading bonded devices:', e);
      }
    }

    // 2. Coba dari window.Android Bridge
    if (window.Android?.getPairedDevices) {
      try {
        const jsonStr = window.Android.getPairedDevices();
        const parsed = JSON.parse(jsonStr);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.map((d: any) => ({
            name: d.name || 'Printer Bluetooth',
            address: d.address || '',
          }));
        }
      } catch (e) {
        console.warn('Error reading Android paired devices:', e);
      }
    }

    // 3. Coba dari bluetoothSerial plugin
    if (window.bluetoothSerial?.list) {
      try {
        const list = await new Promise<any[]>((resolve) => {
          window.bluetoothSerial!.list(
            (devices) => resolve(devices),
            () => resolve([])
          );
        });
        if (list.length > 0) {
          return list.map((d) => ({
            name: d.name || 'Printer Bluetooth',
            address: d.address || d.id || '',
          }));
        }
      } catch {
        // ignore
      }
    }

    // Fallback daftar perangkat contoh / riwayat perangkat terpasang
    return [
      { name: 'MPT-II', address: '66:22:BB:AA:33:11' },
      { name: 'POS-58', address: '00:11:22:33:44:55' },
      { name: 'RPP02N', address: 'AA:BB:CC:DD:EE:FF' },
      { name: 'Panda POS', address: '12:34:56:78:9A:BC' },
      { name: 'Galaxy J2 Pro', address: '64:1D:69:D2:BB:8D' },
    ];
  }

  // 3. Simpan MAC address yang dipilih
  public setSelectedAddress(address: string, name?: string) {
    this.selectedAddress = address;
    if (name) this.deviceName = name;
    if (typeof window !== 'undefined') {
      localStorage.setItem('strukppob_paired_printer_address', address);
      if (name) localStorage.setItem('strukppob_paired_printer_name', name);
    }
  }

  // 4. Cetak Langsung ke MAC Address Printer (Teks ESC/POS atau Grafis HD)
  public async printToPrinter(
    targetAddress: string,
    data: ReceiptData,
    paperWidth: '58mm' | '80mm',
    format: 'esc_pos' | 'graphics'
  ): Promise<{ success: boolean; message?: string; error?: string }> {
    const maxCols = paperWidth === '80mm' ? 48 : 32;

    // --- MODE A: FORMAT GRAFIS HD ---
    if (format === 'graphics') {
      try {
        const receiptElement = document.getElementById('printable-receipt');
        if (!receiptElement) {
          throw new Error('Elemen struk tidak ditemukan di layar');
        }

        const canvas = await html2canvas(receiptElement, {
          scale: 2,
          backgroundColor: '#ffffff',
          useCORS: true,
          logging: false,
        });

        // Resize ke lebar piksel printer: 384px untuk 58mm, 576px untuk 80mm
        const targetWidth = paperWidth === '80mm' ? 576 : 384;
        const targetHeight = Math.round((canvas.height * targetWidth) / canvas.width);

        const scaledCanvas = document.createElement('canvas');
        scaledCanvas.width = targetWidth;
        scaledCanvas.height = targetHeight;
        const ctx = scaledCanvas.getContext('2d');
        if (ctx) {
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, targetWidth, targetHeight);
          ctx.drawImage(canvas, 0, 0, targetWidth, targetHeight);
        }

        const base64Image = scaledCanvas.toDataURL('image/jpeg', 0.9);

        // Jika ada AndroidPrinter.printImage
        if (window.AndroidPrinter?.printImage) {
          const resStr = window.AndroidPrinter.printImage(targetAddress, base64Image);
          try {
            const res = JSON.parse(resStr);
            if (!res.success) {
              return { success: false, error: res.error || 'Gagal cetak grafis ke printer' };
            }
            return { success: true, message: res.message || 'Berhasil mencetak grafis HD!' };
          } catch {
            return { success: true, message: 'Grafis berhasil dikirim ke printer!' };
          }
        }
      } catch (err: any) {
        console.warn('Graphics print error, fallback to ESC/POS:', err);
      }
    }

    // --- MODE B: FORMAT TEKS ESC/POS (TAJAM & CEPAT) ---
    const escposBytes = this.buildEscPosCommands(data, maxCols);
    const base64Data = this.uint8ArrayToBase64(escposBytes);

    // 1. Android Native Printer Bridge (Soket RFCOMM SPP langsung ke MAC address)
    if (window.AndroidPrinter?.printEscPos) {
      try {
        const resStr = window.AndroidPrinter.printEscPos(targetAddress, base64Data);
        const res = JSON.parse(resStr);
        if (!res.success) {
          return { success: false, error: res.error || 'Gagal mengirim data ke printer' };
        }
        return { success: true, message: res.message || 'Struk berhasil dicetak!' };
      } catch (e: any) {
        return { success: false, error: e.message || 'Gagal komunikasi ke printer Bluetooth' };
      }
    }

    // 2. Cordova / Capacitor bluetoothSerial
    if (window.bluetoothSerial?.write && targetAddress) {
      return new Promise((resolve) => {
        window.bluetoothSerial!.connect(
          targetAddress,
          () => {
            window.bluetoothSerial!.write(
              escposBytes.buffer,
              () => {
                resolve({ success: true, message: 'Struk berhasil dicetak via Bluetooth Serial!' });
              },
              (writeErr) => {
                resolve({ success: false, error: `Gagal menulis data: ${writeErr}` });
              }
            );
          },
          (connErr) => {
            resolve({ success: false, error: `Gagal menyambung ke printer: ${connErr}` });
          }
        );
      });
    }

    // 3. Fallback RawBT Intent di Android
    try {
      const rawBtUrl = `rawbt:base64,${base64Data}`;
      const iframe = document.createElement('iframe');
      iframe.style.display = 'none';
      iframe.src = rawBtUrl;
      document.body.appendChild(iframe);
      setTimeout(() => document.body.removeChild(iframe), 2000);
      return { 
        success: true, 
        message: 'Perintah cetak dikirim ke aplikasi printer Bluetooth HP!' 
      };
    } catch {
      // 4. Fallback Terakhir: Print Spooler
      window.print();
      return { success: true, message: 'Membuka dialog cetak HP.' };
    }
  }

  // 5. Helper konversi Uint8Array ke Base64 aman
  public uint8ArrayToBase64(bytes: Uint8Array): string {
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }

  // 6. Bangun Baris Perintah ESC/POS Lengkap
  public buildEscPosCommands(data: ReceiptData, maxCols: number = 32): Uint8Array {
    const commands: number[] = [];

    const append = (bytes: number[]) => {
      commands.push(...bytes);
    };

    const appendText = (text: string) => {
      const encoder = new TextEncoder();
      const encoded = encoder.encode(text);
      for (let i = 0; i < encoded.length; i++) {
        commands.push(encoded[i]);
      }
    };

    const appendLine = (text: string = '') => {
      appendText(text + '\n');
    };

    const formatCols = (left: string, right: string): string => {
      const spaceNeeded = maxCols - left.length - right.length;
      if (spaceNeeded > 0) {
        return left + ' '.repeat(spaceNeeded) + right;
      }
      return left + ' ' + right;
    };

    const hr = (char = '-') => char.repeat(maxCols);

    // Initialize printer (ESC @)
    append([0x1b, 0x40]);

    // 1. HEADER (Center)
    append([0x1b, 0x61, 0x01]); // Align Center
    append([0x1b, 0x45, 0x01]); // Bold ON
    appendLine(data.storeHeader.storeName || 'STRUK TRANSAKSI');
    append([0x1b, 0x45, 0x00]); // Bold OFF

    if (data.storeHeader.storeAddress) {
      const addrLines = data.storeHeader.storeAddress.split('\n');
      for (const line of addrLines) {
        if (line.trim()) appendLine(line.trim());
      }
    }
    if (data.storeHeader.storeNpwp) {
      appendLine(`NPWP: ${data.storeHeader.storeNpwp}`);
    }
    if (data.storeHeader.headerNote) {
      appendLine(data.storeHeader.headerNote);
    }

    appendLine(hr('-'));

    // 2. RECEIPT TITLE & PRODUCT (Center)
    append([0x1b, 0x61, 0x01]);
    append([0x1b, 0x45, 0x01]);
    appendLine(data.receiptTitle || 'Bukti Transaksi');
    append([0x1b, 0x45, 0x00]);
    if (data.productName) {
      appendLine(data.productName);
    }

    append([0x1b, 0x61, 0x00]); // Align Left
    appendLine(hr('-'));

    // 3. DATE & TIME
    if (data.transactionDate || data.transactionTime) {
      appendLine(formatCols('TGL TRANS', `${data.transactionDate} ${data.transactionTime}`.trim()));
    }
    if (data.transactionId) {
      appendLine(formatCols('NO TRANSAKSI', data.transactionId));
    }
    if (data.referenceNumber) {
      appendLine(formatCols('NO. REF', data.referenceNumber.length > 16 ? data.referenceNumber.substring(0, 16) + '...' : data.referenceNumber));
    }

    // 4. TRANSACTION CONTENT
    if (data.customerName) {
      appendLine(formatCols('NAMA', data.customerName));
    }
    if (data.destinationNumber) {
      appendLine(formatCols('NO TUJUAN', data.destinationNumber));
    }
    if (data.idpel) {
      appendLine(formatCols('IDPEL', data.idpel));
    }
    if (data.meterNumber) {
      appendLine(formatCols('NO METER', data.meterNumber));
    }
    if (data.tarifDaya) {
      appendLine(formatCols('TARIF/DAYA', data.tarifDaya));
    }
    if (data.periode) {
      appendLine(formatCols('PERIODE', data.periode));
    }
    if (data.standMeter) {
      appendLine(formatCols('STAND METER', data.standMeter));
    }
    if (data.serialNumber) {
      appendLine('SERIAL:');
      append([0x1b, 0x45, 0x01]);
      appendLine(data.serialNumber);
      append([0x1b, 0x45, 0x00]);
    }

    // Special Token Listrik Highlight
    if (data.tokenListrik) {
      appendLine(hr('-'));
      append([0x1b, 0x61, 0x01]); // Center
      append([0x1b, 0x45, 0x01]); // Bold
      appendLine('STROOM / TOKEN LISTRIK:');
      append([0x1d, 0x21, 0x11]); // Double height & width
      appendLine(data.tokenListrik);
      append([0x1d, 0x21, 0x00]); // Normal size
      append([0x1b, 0x45, 0x00]); // Bold OFF
      if (data.kwh) {
        appendLine(`JML KWH: ${data.kwh}`);
      }
      append([0x1b, 0x61, 0x00]); // Left
    }

    // 5. FINANCIAL DETAILS
    appendLine(hr('-'));
    if (data.tagihan) {
      appendLine(formatCols('TAGIHAN', data.tagihan));
    }
    if (data.adminFee) {
      appendLine(formatCols('BIAYA ADMIN', data.adminFee));
    }
    if (data.discount && data.discount !== 'Rp0' && data.discount !== 'Rp.0,-') {
      appendLine(formatCols('DISKON', data.discount));
    }

    append([0x1b, 0x45, 0x01]); // Bold ON
    appendLine(formatCols('TOTAL BAYAR', data.totalBayar));
    append([0x1b, 0x45, 0x00]); // Bold OFF

    if (data.paymentMethod) {
      appendLine(formatCols('METODE BAYAR', data.paymentMethod));
    }

    // 6. CUSTOM ROWS
    if (data.customRows && data.customRows.length > 0) {
      appendLine(hr('-'));
      for (const row of data.customRows) {
        appendLine(formatCols(row.label, row.value));
      }
    }

    // 7. FOOTER
    appendLine(hr('-'));
    append([0x1b, 0x61, 0x01]); // Center

    if (data.infoNote) {
      appendLine(data.infoNote);
      appendLine('');
    }

    if (data.footerNote) {
      const footerLines = data.footerNote.split('\n');
      for (const line of footerLines) {
        if (line.trim()) appendLine(line.trim());
      }
    }

    if (data.storeHeader.storeContact) {
      appendLine('');
      appendLine(data.storeHeader.storeContact);
    }

    // Feed lines & cut
    appendLine('\n\n\n');
    append([0x1d, 0x56, 0x41, 0x00]); // Partial cut

    return new Uint8Array(commands);
  }
}

export const bluetoothPrinterService = new BluetoothThermalPrinter();
