import React, { useState, useEffect } from 'react';
import { StoreHeader } from '../types';
import { Store, Save, RotateCcw, X, Check, Building2, Phone, FileText } from 'lucide-react';

interface HeaderSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentHeader: StoreHeader;
  onSaveHeader: (header: StoreHeader) => void;
}

const STORAGE_KEY = 'struk_ppob_saved_store_header';

export const HeaderSettingsModal: React.FC<HeaderSettingsModalProps> = ({
  isOpen,
  onClose,
  currentHeader,
  onSaveHeader,
}) => {
  const [headerData, setHeaderData] = useState<StoreHeader>(currentHeader);
  const [savedSuccess, setSavedSuccess] = useState(false);

  useEffect(() => {
    setHeaderData(currentHeader);
  }, [currentHeader, isOpen]);

  if (!isOpen) return null;

  const handleSave = () => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(headerData));
    onSaveHeader(headerData);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 900);
  };

  const handleResetDefault = () => {
    const defaultData: StoreHeader = {
      storeName: 'SRC MASNGUD Banjarnegara',
      storeAddress: 'Jl. Raya Rakit, Banjarnegara, Jawa Tengah',
      storeNpwp: '06.056.900.5-529.000',
      storeContact: 'WA: 0812-3456-7890',
      headerNote: 'Mitra PPOB & Agen Pembayaran Resmi',
    };
    setHeaderData(defaultData);
  };

  const applyPresetTemplate = (type: 'src' | 'alfamart' | 'konter') => {
    if (type === 'src') {
      setHeaderData({
        storeName: 'SRC MASNGUD Banjarnegara',
        storeAddress: 'Jl. Raya Rakit, Banjarnegara, Jawa Tengah',
        storeNpwp: '06.056.900.5-529.000',
        storeContact: 'SMS/WA: 08123456789',
        headerNote: 'Partner Resmi Bukalapak & PPOB',
      });
    } else if (type === 'alfamart') {
      setHeaderData({
        storeName: 'ALFAMART RAKIT BANJARNEGARA',
        storeAddress: 'RAYA RAKIT/ F (YAKI)\nCV. CAHAYA MULYA\nRAKIT RT. 005 RW. 003',
        storeNpwp: '06.056.900.5-529.000',
        storeContact: 'SMS/WA: 081110640888 / TELP 1500959',
        headerNote: '.: TELKOM PAY TELKOM INDIHOME :.',
      });
    } else if (type === 'konter') {
      setHeaderData({
        storeName: 'BERKAH CELLULAR PPOB',
        storeAddress: 'Pasar Wage Kios No. 12, Banjarnegara',
        storeNpwp: '',
        storeContact: 'WA: 0857-1234-5678',
        headerNote: 'Pulsa, Paket Data, Token Listrik & Tagihan',
      });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div 
        className="w-full max-w-lg bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-white">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200">
              <Store className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Pengaturan Header Struk</h3>
              <p className="text-xs text-slate-500">Data toko tersimpan otomatis untuk seluruh struk transaksi</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-4 text-sm max-h-[75vh] overflow-y-auto">
          {/* Quick Preset Buttons */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-2">Template Header Cepat:</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => applyPresetTemplate('src')}
                className="px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 transition-colors text-center truncate"
              >
                SRC Masngud
              </button>
              <button
                type="button"
                onClick={() => applyPresetTemplate('alfamart')}
                className="px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 transition-colors text-center truncate"
              >
                Alfamart Rakit
              </button>
              <button
                type="button"
                onClick={() => applyPresetTemplate('konter')}
                className="px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 transition-colors text-center truncate"
              >
                Konter Pulsa
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
              <Building2 className="w-3.5 h-3.5 text-emerald-600" />
              Nama Toko / Agen / Warung
            </label>
            <input
              type="text"
              value={headerData.storeName}
              onChange={(e) => setHeaderData({ ...headerData, storeName: e.target.value })}
              placeholder="Contoh: SRC MASNGUD Banjarnegara"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 placeholder-slate-400 focus:bg-white focus:outline-hidden focus:border-emerald-500 transition-colors"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-emerald-600" />
              Alamat Lengkap Toko (Bisa beberapa baris)
            </label>
            <textarea
              rows={3}
              value={headerData.storeAddress}
              onChange={(e) => setHeaderData({ ...headerData, storeAddress: e.target.value })}
              placeholder="Contoh: RAYA RAKIT/ F (YAKI)&#10;CV. CAHAYA MULYA&#10;RAKIT RT. 005 RW. 003"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 placeholder-slate-400 focus:bg-white focus:outline-hidden focus:border-emerald-500 transition-colors font-mono text-xs"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                NPWP Toko (Opsional)
              </label>
              <input
                type="text"
                value={headerData.storeNpwp}
                onChange={(e) => setHeaderData({ ...headerData, storeNpwp: e.target.value })}
                placeholder="06.056.900.5-529.000"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 placeholder-slate-400 focus:bg-white focus:outline-hidden focus:border-emerald-500 transition-colors"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-emerald-600" />
                No. HP / WA / Kontak Toko
              </label>
              <input
                type="text"
                value={headerData.storeContact}
                onChange={(e) => setHeaderData({ ...headerData, storeContact: e.target.value })}
                placeholder="SMS/WA: 081110640888"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 placeholder-slate-400 focus:bg-white focus:outline-hidden focus:border-emerald-500 transition-colors"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Catatan Header / Slogan (Opsional)
            </label>
            <input
              type="text"
              value={headerData.headerNote || ''}
              onChange={(e) => setHeaderData({ ...headerData, headerNote: e.target.value })}
              placeholder="Contoh: .: TELKOM PAY TELKOM INDIHOME :."
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 placeholder-slate-400 focus:bg-white focus:outline-hidden focus:border-emerald-500 transition-colors"
            />
          </div>

          {savedSuccess && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold">
              <Check className="w-4 h-4 text-emerald-600" />
              Pengaturan header toko berhasil disimpan!
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-200 bg-slate-50">
          <button
            type="button"
            onClick={handleResetDefault}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset Default
          </button>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold rounded-xl bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 transition-colors"
            >
              Batal
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white transition-colors shadow-xs"
            >
              <Save className="w-4 h-4" />
              Simpan Header
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
