import React, { useState, useEffect } from 'react';
import { ReceiptData } from '../types';
import { bluetoothPrinterService, PairedDeviceInfo } from '../utils/bluetoothPrinter';
import { 
  Printer, 
  X, 
  CheckCircle2, 
  AlertTriangle, 
  Loader2,
  Smartphone,
  Zap,
  Bluetooth,
  Send,
  FileText
} from 'lucide-react';

interface BluetoothModalProps {
  isOpen: boolean;
  onClose: () => void;
  receiptData: ReceiptData;
}

export const BluetoothModal: React.FC<BluetoothModalProps> = ({
  isOpen,
  onClose,
  receiptData,
}) => {
  const [pairedPrinterName, setPairedPrinterName] = useState('MPT-II');
  const [isPrinting, setIsPrinting] = useState(false);
  const [isConnectingBle, setIsConnectingBle] = useState(false);
  const [isBleConnected, setIsBleConnected] = useState(false);
  const [paperWidth, setPaperWidth] = useState<'58mm' | '80mm'>(
    receiptData.paperPreset === '80mm' ? '80mm' : '58mm'
  );
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  const popularPrinters = ['MPT-II', 'POS-58', 'RPP02N', 'PT-210', 'Panda POS', 'Iware MP-58'];

  useEffect(() => {
    if (!isOpen) return;

    const savedName = localStorage.getItem('strukppob_paired_printer_name');
    if (savedName) {
      setPairedPrinterName(savedName);
    }
    setIsBleConnected(bluetoothPrinterService.isConnected);
    setStatusMessage(null);
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSelectPrinter = (name: string) => {
    setPairedPrinterName(name);
    bluetoothPrinterService.setPairedDeviceName(name);
  };

  // 1. Cetak Langsung via Sistem HP (Android Print Spooler / Bluetooth Service)
  const handleSystemPrint = () => {
    setIsPrinting(true);
    setStatusMessage({ type: 'info', text: 'Membuka dialog cetak HP...' });
    setTimeout(() => {
      window.print();
      setIsPrinting(false);
      setStatusMessage({ 
        type: 'success', 
        text: `Dialog cetak dibuka. Pilih printer ${pairedPrinterName} di menu atas.` 
      });
    }, 200);
  };

  // 2. Cetak via RawBT / Bluetooth Intent App
  const handleRawBtPrint = async () => {
    setIsPrinting(true);
    setStatusMessage(null);
    try {
      bluetoothPrinterService.setPairedDeviceName(pairedPrinterName);
      const res = await bluetoothPrinterService.printReceipt(receiptData, paperWidth, 'android_intent');
      setStatusMessage({ 
        type: 'success', 
        text: res.message || `Struk dikirim ke layanan printer Bluetooth (${pairedPrinterName}).` 
      });
    } catch (err: any) {
      setStatusMessage({ type: 'error', text: err.message || 'Gagal mengirim ke printer.' });
    } finally {
      setIsPrinting(false);
    }
  };

  // 3. Scan & Hubungkan Web Bluetooth
  const handleConnectBle = async () => {
    setIsConnectingBle(true);
    setStatusMessage(null);
    try {
      const res = await bluetoothPrinterService.connect();
      if (res.success) {
        setIsBleConnected(true);
        if (res.deviceName) {
          setPairedPrinterName(res.deviceName);
        }
        setStatusMessage({ type: 'success', text: `Terhubung ke ${res.deviceName || 'Printer Bluetooth'}!` });
      } else {
        setStatusMessage({ 
          type: 'info', 
          text: res.error || 'Pasangkan printer di Pengaturan Bluetooth HP, lalu tekan Cetak Langsung.' 
        });
      }
    } catch (err: any) {
      setStatusMessage({ 
        type: 'info', 
        text: 'Pasangkan printer di Pengaturan Bluetooth HP Anda, lalu gunakan tombol Cetak Langsung.' 
      });
    } finally {
      setIsConnectingBle(false);
    }
  };

  // 4. Tes Cetak Kertas
  const handleTestPrint = async () => {
    setIsPrinting(true);
    try {
      const testData: ReceiptData = {
        ...receiptData,
        receiptTitle: 'TES CETAK PRINTER',
        productName: `Uji Coba Printer (${pairedPrinterName})`,
        totalBayar: 'Rp0',
        footerNote: 'Printer Berhasil Terhubung!',
      };
      await bluetoothPrinterService.printReceipt(testData, paperWidth, 'android_intent');
      setStatusMessage({ type: 'success', text: 'Perintah tes cetak berhasil dikirim!' });
    } catch (err: any) {
      setStatusMessage({ type: 'error', text: 'Gagal mengirim tes cetak.' });
    } finally {
      setIsPrinting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="w-full max-w-md bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header Ringkas */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-emerald-50 text-emerald-600 border border-emerald-200 shadow-2xs">
              <Printer className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Cetak Printer Bluetooth</h3>
              <p className="text-[11px] text-slate-500">
                Hubungkan printer thermal 58mm / 80mm
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Isi Pengaturan Ringkas */}
        <div className="p-5 space-y-4">
          
          {/* Pilihan Cepat Printer */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-700 mb-1.5">
              Nama Printer Anda:
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={pairedPrinterName}
                onChange={(e) => handleSelectPrinter(e.target.value)}
                placeholder="Contoh: MPT-II atau POS-58"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
              />
              <button
                type="button"
                onClick={handleConnectBle}
                disabled={isConnectingBle}
                className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-700 text-xs font-bold flex items-center gap-1 shrink-0 active:scale-95 transition-all"
                title="Scan Bluetooth Langsung"
              >
                {isConnectingBle ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Bluetooth className="w-3.5 h-3.5 text-blue-600" />
                )}
                <span>Scan</span>
              </button>
            </div>

            {/* Quick chips */}
            <div className="flex flex-wrap gap-1.5 mt-2">
              {popularPrinters.map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => handleSelectPrinter(p)}
                  className={`px-2 py-1 rounded-lg text-[10px] font-semibold border transition-all ${
                    pairedPrinterName.toLowerCase() === p.toLowerCase()
                      ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                      : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          {/* Ukuran Kertas */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200">
            <div>
              <span className="text-xs font-bold text-slate-800">Lebar Kertas</span>
              <p className="text-[10px] text-slate-500">Standar struk kasir mini adalah 58mm</p>
            </div>
            <div className="flex rounded-lg bg-slate-200 p-0.5 text-[11px] font-bold">
              <button
                type="button"
                onClick={() => setPaperWidth('58mm')}
                className={`px-3 py-1 rounded-md transition-all ${
                  paperWidth === '58mm' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600'
                }`}
              >
                58 mm
              </button>
              <button
                type="button"
                onClick={() => setPaperWidth('80mm')}
                className={`px-3 py-1 rounded-md transition-all ${
                  paperWidth === '80mm' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600'
                }`}
              >
                80 mm
              </button>
            </div>
          </div>

          {/* Status Alert jika ada */}
          {statusMessage && (
            <div
              className={`p-3 rounded-xl text-xs flex items-start gap-2 border ${
                statusMessage.type === 'success'
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                  : statusMessage.type === 'error'
                  ? 'bg-red-50 text-red-800 border-red-200'
                  : 'bg-blue-50 text-blue-800 border-blue-200'
              }`}
            >
              {statusMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              )}
              <span className="leading-relaxed">{statusMessage.text}</span>
            </div>
          )}

          {/* Tombol Aksi Utama */}
          <div className="space-y-2 pt-1">
            {/* Tombol Utama: Cetak Langsung */}
            <button
              type="button"
              onClick={handleSystemPrint}
              disabled={isPrinting}
              className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-md shadow-emerald-600/25 flex items-center justify-center gap-2 active:scale-98 transition-all"
            >
              {isPrinting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Menyiapkan Cetak...</span>
                </>
              ) : (
                <>
                  <Printer className="w-4 h-4" />
                  <span>Cetak Langsung (Sistem HP & Bluetooth)</span>
                </>
              )}
            </button>

            {/* Tombol Alternatif: RawBT / Intent Bluetooth */}
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={handleRawBtPrint}
                disabled={isPrinting}
                className="py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-2xs active:scale-95 transition-all"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Kirim ke RawBT</span>
              </button>

              <button
                type="button"
                onClick={handleTestPrint}
                disabled={isPrinting}
                className="py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs border border-slate-300 flex items-center justify-center gap-1.5 active:scale-95 transition-all"
              >
                <Zap className="w-3.5 h-3.5 text-amber-500" />
                <span>Tes Kertas</span>
              </button>
            </div>
          </div>

          {/* Tips Singkat 1 Baris */}
          <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-500 flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-slate-400 shrink-0" />
            <span>Pastikan printer sudah dipasangkan di menu Bluetooth HP Anda sebelum mencetak.</span>
          </div>

        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-100 bg-slate-50 flex items-center justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg text-xs font-semibold text-slate-600 hover:bg-slate-200 transition-colors"
          >
            Tutup
          </button>
        </div>

      </div>
    </div>
  );
};
