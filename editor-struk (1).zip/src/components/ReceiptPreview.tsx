import React, { forwardRef } from 'react';
import { ReceiptData } from '../types';

interface ReceiptPreviewProps {
  data: ReceiptData;
  isInlineEditable?: boolean;
  onUpdateField?: (field: keyof ReceiptData, value: any) => void;
  scale?: number;
}

export const ReceiptPreview = forwardRef<HTMLDivElement, ReceiptPreviewProps>(
  ({ data, isInlineEditable = false, onUpdateField, scale = 1 }, ref) => {
    const isDigital = data.layoutStyle === 'digital_mitra';

    // Width classes based on preset
    const getWidthClass = () => {
      if (data.paperPreset === '58mm') return 'w-[320px]';
      if (data.paperPreset === '80mm') return 'w-[400px]';
      if (data.paperPreset === 'a5') return 'w-[480px]';
      // digital screenshot style
      return 'w-[360px] sm:w-[380px]';
    };

    // Helper for direct contentEditable update
    const handleBlur = (field: keyof ReceiptData, e: React.FocusEvent<HTMLElement>) => {
      if (onUpdateField && isInlineEditable) {
        onUpdateField(field, e.currentTarget.innerText.trim());
      }
    };

    // Helper to format 20-digit token into 2 lines Bukalapak style
    const formatTokenBukalapak = (token: string) => {
      if (!token) return { line1: '', line2: '' };
      const cleaned = token.replace(/[^0-9]/g, '');
      if (cleaned.length >= 20) {
        const p1 = cleaned.substring(0, 4);
        const p2 = cleaned.substring(4, 8);
        const p3 = cleaned.substring(8, 12);
        const p4 = cleaned.substring(12, 16);
        const p5 = cleaned.substring(16, 20);
        return {
          line1: `${p1}-${p2}-${p3}-${p4}`,
          line2: `-${p5}`,
        };
      }
      // If already formatted with dashes
      if (token.includes('-')) {
        const parts = token.split('-');
        if (parts.length === 5) {
          return {
            line1: `${parts[0]}-${parts[1]}-${parts[2]}-${parts[3]}`,
            line2: `-${parts[4]}`,
          };
        }
      }
      return { line1: token, line2: '' };
    };

    const tokenBukalapak = formatTokenBukalapak(data.tokenListrik || '');

    return (
      <div
        style={{ transform: `scale(${scale})`, transformOrigin: 'top center' }}
        className="transition-transform duration-200 flex justify-center"
      >
        <div
          ref={ref}
          id="printable-receipt-container"
          className={`${getWidthClass()} ${
            isDigital
              ? 'bg-white text-neutral-800 font-digital rounded-none sm:rounded-2xl shadow-xl'
              : 'bg-white text-neutral-900 font-thermal shadow-2xl relative'
          } p-6 sm:p-7 overflow-hidden select-text text-sm transition-all`}
        >
          {/* Jagged Top Tear Effect for Thermal Style */}
          {!isDigital && (
            <div className="receipt-tear-top h-3 w-full -mt-7 mb-4 opacity-70 no-print" />
          )}

          {/* ==================== DIGITAL MITRA BUKALAPAK STYLE ==================== */}
          {isDigital ? (
            <div className="space-y-4">
              {/* Header: Title & Store Name */}
              <div className="text-center pt-2">
                <h1
                  contentEditable={isInlineEditable}
                  suppressContentEditableWarning
                  onBlur={(e) => handleBlur('receiptTitle', e)}
                  className="text-xl font-bold text-neutral-900 tracking-tight"
                >
                  {data.receiptTitle || 'Bukti Transaksi'}
                </h1>
                <h2
                  contentEditable={isInlineEditable}
                  suppressContentEditableWarning
                  className="text-sm font-medium text-neutral-800 mt-1"
                >
                  {data.storeHeader.storeName || 'SRC MASNGUD Banjarnegara'}
                </h2>
              </div>

              {/* Product Name & Date Section */}
              <div className="pt-2">
                <div
                  contentEditable={isInlineEditable}
                  suppressContentEditableWarning
                  onBlur={(e) => handleBlur('productName', e)}
                  className="text-sm text-neutral-800 font-normal mb-1.5"
                >
                  {data.productName}
                </div>

                <div className="flex justify-between items-start text-xs text-neutral-900 pt-1">
                  <span className="text-neutral-800 font-normal">TGL TRANSAKSI</span>
                  <div className="text-right">
                    <div
                      contentEditable={isInlineEditable}
                      suppressContentEditableWarning
                      onBlur={(e) => handleBlur('transactionDate', e)}
                      className="font-normal text-neutral-900"
                    >
                      {data.transactionDate}
                    </div>
                    <div
                      contentEditable={isInlineEditable}
                      suppressContentEditableWarning
                      onBlur={(e) => handleBlur('transactionTime', e)}
                      className="font-normal text-neutral-900"
                    >
                      {data.transactionTime}
                    </div>
                  </div>
                </div>
              </div>

              {/* Thin Divider */}
              <div className="border-t border-neutral-200/90 my-2" />

              {/* TOKEN LISTRIK HIGHLIGHT (if PLN Prepaid) */}
              {data.tokenListrik && (
                <div className="text-center py-2 space-y-1">
                  <div className="text-xs uppercase tracking-wider text-neutral-800 font-normal">
                    TOKEN LISTRIK
                  </div>
                  <div className="font-extrabold text-2xl text-neutral-900 tracking-wider leading-tight">
                    <div>{tokenBukalapak.line1}</div>
                    {tokenBukalapak.line2 && <div>{tokenBukalapak.line2}</div>}
                  </div>

                  {data.infoNote && (
                    <p
                      contentEditable={isInlineEditable}
                      suppressContentEditableWarning
                      onBlur={(e) => handleBlur('infoNote', e)}
                      className="text-[11px] text-neutral-700 leading-snug pt-2 px-2 text-center"
                    >
                      {data.infoNote}
                    </p>
                  )}
                </div>
              )}

              {/* Key-Value Details */}
              <div className="space-y-1.5 text-xs text-neutral-800 pt-1">
                {data.periode && (
                  <div className="flex justify-between">
                    <span className="text-neutral-800">PERIODE</span>
                    <span className="text-neutral-900 font-normal text-right">{data.periode}</span>
                  </div>
                )}
                {data.standMeter && (
                  <div className="flex justify-between">
                    <span className="text-neutral-800">STAND METER</span>
                    <span className="text-neutral-900 font-normal text-right">{data.standMeter}</span>
                  </div>
                )}
                {data.customerName && (
                  <div className="flex justify-between">
                    <span className="text-neutral-800">NAMA</span>
                    <span
                      contentEditable={isInlineEditable}
                      suppressContentEditableWarning
                      onBlur={(e) => handleBlur('customerName', e)}
                      className="text-neutral-900 font-normal text-right"
                    >
                      {data.customerName}
                    </span>
                  </div>
                )}
                {data.destinationNumber && (
                  <div className="flex justify-between">
                    <span className="text-neutral-800">NOMOR TUJUAN</span>
                    <span
                      contentEditable={isInlineEditable}
                      suppressContentEditableWarning
                      onBlur={(e) => handleBlur('destinationNumber', e)}
                      className="text-neutral-900 font-normal text-right"
                    >
                      {data.destinationNumber}
                    </span>
                  </div>
                )}
                {data.meterNumber && (
                  <div className="flex justify-between">
                    <span className="text-neutral-800">NOMOR METER</span>
                    <span
                      contentEditable={isInlineEditable}
                      suppressContentEditableWarning
                      onBlur={(e) => handleBlur('meterNumber', e)}
                      className="text-neutral-900 font-normal text-right"
                    >
                      {data.meterNumber}
                    </span>
                  </div>
                )}
                {data.idpel && (
                  <div className="flex justify-between">
                    <span className="text-neutral-800">IDPEL</span>
                    <span
                      contentEditable={isInlineEditable}
                      suppressContentEditableWarning
                      onBlur={(e) => handleBlur('idpel', e)}
                      className="text-neutral-900 font-normal text-right"
                    >
                      {data.idpel}
                    </span>
                  </div>
                )}
                {data.tarifDaya && (
                  <div className="flex justify-between">
                    <span className="text-neutral-800">TARIF/DAYA</span>
                    <span
                      contentEditable={isInlineEditable}
                      suppressContentEditableWarning
                      onBlur={(e) => handleBlur('tarifDaya', e)}
                      className="text-neutral-900 font-normal text-right"
                    >
                      {data.tarifDaya}
                    </span>
                  </div>
                )}
                {data.serialNumber && (
                  <div className="flex justify-between items-baseline">
                    <span className="text-neutral-800">SERIAL</span>
                    <span
                      contentEditable={isInlineEditable}
                      suppressContentEditableWarning
                      onBlur={(e) => handleBlur('serialNumber', e)}
                      className="text-neutral-900 font-normal text-right max-w-[200px] break-all leading-snug"
                    >
                      {data.serialNumber}
                    </span>
                  </div>
                )}
                {data.referenceNumber && (
                  <div className="flex justify-between items-baseline">
                    <span className="text-neutral-800 shrink-0">NO. REFERENSI</span>
                    <span
                      contentEditable={isInlineEditable}
                      suppressContentEditableWarning
                      onBlur={(e) => handleBlur('referenceNumber', e)}
                      className="text-neutral-900 font-normal text-right max-w-[210px] break-all leading-tight text-[11px]"
                    >
                      {data.referenceNumber}
                    </span>
                  </div>
                )}
                {data.kwh && (
                  <div className="flex justify-between">
                    <span className="text-neutral-800">JML KWH</span>
                    <span
                      contentEditable={isInlineEditable}
                      suppressContentEditableWarning
                      onBlur={(e) => handleBlur('kwh', e)}
                      className="text-neutral-900 font-normal text-right"
                    >
                      {data.kwh}
                    </span>
                  </div>
                )}

                {/* Additional custom rows */}
                {data.customRows?.map((row, idx) => (
                  <div key={row.id || idx} className="flex justify-between">
                    <span className="text-neutral-800">{row.label}</span>
                    <span className="text-neutral-900 font-normal text-right">{row.value}</span>
                  </div>
                ))}
              </div>

              {/* Thin Divider */}
              <div className="border-t border-neutral-200/90 my-2" />

              {/* TOTAL ROW */}
              <div className="flex justify-between items-center py-1">
                <span className="text-xs font-semibold text-neutral-900">TOTAL</span>
                <span
                  contentEditable={isInlineEditable}
                  suppressContentEditableWarning
                  onBlur={(e) => handleBlur('totalBayar', e)}
                  className="text-xs font-bold text-neutral-900"
                >
                  {data.totalBayar}
                </span>
              </div>

              {/* Post-Total Info Note (if present) */}
              {data.infoNote && !data.tokenListrik && (
                <div className="text-center text-[11px] text-neutral-700 leading-snug pt-1">
                  {data.infoNote}
                </div>
              )}

              {/* FOOTER MESSAGES */}
              {data.footerNote && (
                <div className="pt-4 text-center text-xs text-neutral-700 space-y-4 leading-relaxed whitespace-pre-line">
                  {data.footerNote}
                </div>
              )}
            </div>
          ) : (
            /* ==================== THERMAL KERTAS MINIMARKET / ALFAMART STYLE ==================== */
            <div className="space-y-2 text-xs leading-relaxed">
              {/* Header Store & Address */}
              <div className="text-center space-y-0.5">
                <div className="font-bold text-sm uppercase tracking-wide">
                  {data.storeHeader.storeName || 'ALFAMART RAYA RAKIT'}
                </div>
                {data.storeHeader.storeAddress && (
                  <div className="whitespace-pre-line text-[11px] text-neutral-800">
                    {data.storeHeader.storeAddress}
                  </div>
                )}
                {data.storeHeader.storeNpwp && (
                  <div className="text-[11px] text-neutral-800">
                    NPWP: {data.storeHeader.storeNpwp}
                  </div>
                )}
              </div>

              {/* Dashed line */}
              <div className="border-b border-dashed border-neutral-900 my-2" />

              {/* Header Note / Service Title */}
              {data.storeHeader.headerNote ? (
                <div className="text-center font-bold tracking-wide">
                  {data.storeHeader.headerNote}
                </div>
              ) : (
                <div className="text-center font-bold tracking-wide">
                  .: {data.receiptTitle} :.
                </div>
              )}

              <div className="border-b border-dashed border-neutral-900 my-2" />

              {/* Aligned Key-Value Table */}
              <div className="space-y-0.5">
                <div className="flex justify-between">
                  <span>TGL TRANS</span>
                  <span>: {data.transactionDate} {data.transactionTime}</span>
                </div>
                {data.transactionId && (
                  <div className="flex justify-between">
                    <span>NO TRANSAKSI</span>
                    <span>: {data.transactionId}</span>
                  </div>
                )}
                {data.idpel && (
                  <div className="flex justify-between">
                    <span>ID PELANGGAN</span>
                    <span>: {data.idpel}</span>
                  </div>
                )}
                {data.meterNumber && (
                  <div className="flex justify-between">
                    <span>NO METER</span>
                    <span>: {data.meterNumber}</span>
                  </div>
                )}
                {data.customerName && (
                  <div className="flex justify-between">
                    <span>NAMA</span>
                    <span>: {data.customerName}</span>
                  </div>
                )}
                {data.destinationNumber && (
                  <div className="flex justify-between">
                    <span>NO TUJUAN</span>
                    <span>: {data.destinationNumber}</span>
                  </div>
                )}
                {data.periode && (
                  <div className="flex justify-between">
                    <span>PERIODE BAYAR</span>
                    <span>: {data.periode}</span>
                  </div>
                )}
                {data.tarifDaya && (
                  <div className="flex justify-between">
                    <span>TARIF/DAYA</span>
                    <span>: {data.tarifDaya}</span>
                  </div>
                )}
                {data.standMeter && (
                  <div className="flex justify-between">
                    <span>STAND METER</span>
                    <span>: {data.standMeter}</span>
                  </div>
                )}
                {data.tagihan && (
                  <div className="flex justify-between">
                    <span>TAGIHAN</span>
                    <span>: {data.tagihan}</span>
                  </div>
                )}
                {data.adminFee && (
                  <div className="flex justify-between">
                    <span>BIAYA ADMIN</span>
                    <span>: {data.adminFee}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold">
                  <span>TOTAL BAYAR</span>
                  <span>: {data.totalBayar}</span>
                </div>
              </div>

              {/* TOKEN LISTRIK IN THERMAL */}
              {data.tokenListrik && (
                <div className="border-t border-b border-dashed border-neutral-900 py-2 my-2 text-center">
                  <div className="text-[11px] font-bold">STROOM / TOKEN LISTRIK:</div>
                  <div className="font-bold text-base tracking-widest my-1">
                    {data.tokenListrik}
                  </div>
                  {data.kwh && <div className="text-[11px]">JML KWH : {data.kwh}</div>}
                </div>
              )}

              {/* SERIAL NUMBER */}
              {data.serialNumber && (
                <div className="border-t border-dashed border-neutral-900 pt-1">
                  <div>SERIAL:</div>
                  <div className="font-mono break-all font-bold">{data.serialNumber}</div>
                </div>
              )}

              {/* DETAIL BAYAR SECTION */}
              <div className="border-t border-dashed border-neutral-900 my-2 pt-1">
                <div className="text-center font-bold mb-1">DETAIL BAYAR</div>
                <div className="space-y-0.5">
                  <div className="flex justify-between">
                    <span>TOTAL TAGIHAN</span>
                    <span>: {data.totalBayar}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>TOTAL DISKON</span>
                    <span>: {data.discount || 'Rp.0,-'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>TUNAI</span>
                    <span>: {data.totalBayar}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>NON TUNAI/KARTU</span>
                    <span>: Rp.0,-</span>
                  </div>
                  <div className="flex justify-between">
                    <span>VOUCHER</span>
                    <span>: Rp.0,-</span>
                  </div>
                </div>
              </div>

              {/* FOOTER */}
              <div className="text-center pt-3 space-y-2">
                {data.footerNote && (
                  <div className="text-[11px] whitespace-pre-line leading-relaxed">
                    {data.footerNote}
                  </div>
                )}

                <div className="border-b border-dashed border-neutral-900 my-2" />

                {data.storeHeader.storeContact && (
                  <div className="text-[11px] whitespace-pre-line font-bold">
                    {data.storeHeader.storeContact}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Jagged Bottom Tear Effect for Thermal Style */}
          {!isDigital && (
            <div className="receipt-tear-bottom h-3 w-full -mb-7 mt-4 opacity-70 no-print" />
          )}
        </div>
      </div>
    );
  }
);
