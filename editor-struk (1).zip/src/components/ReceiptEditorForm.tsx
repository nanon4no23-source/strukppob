import React from 'react';
import { ReceiptData } from '../types';
import { 
  Dices, 
  Clock, 
  Store, 
  Plus, 
  Trash2, 
  Zap, 
  Phone, 
  Wifi, 
  Wallet, 
  Receipt,
  FileSpreadsheet
} from 'lucide-react';
import { 
  generateRandomTokenListrik, 
  generateRandomSerial, 
  generateRandomReference, 
  generateRandomStandMeter, 
  generateCurrentDateTime,
  formatRupiah 
} from '../utils/generators';

interface ReceiptEditorFormProps {
  data: ReceiptData;
  onChange: (updated: ReceiptData) => void;
  onOpenHeaderModal: () => void;
  onSelectPreset: (presetKey: string) => void;
}

export const ReceiptEditorForm: React.FC<ReceiptEditorFormProps> = ({
  data,
  onChange,
  onOpenHeaderModal,
  onSelectPreset,
}) => {
  const updateField = (field: keyof ReceiptData, value: any) => {
    onChange({ ...data, [field]: value });
  };

  // Randomize single fields
  const handleRandomizeToken = () => {
    updateField('tokenListrik', generateRandomTokenListrik());
  };

  const handleRandomizeSerial = () => {
    updateField('serialNumber', generateRandomSerial());
  };

  const handleRandomizeReference = () => {
    updateField('referenceNumber', generateRandomReference());
  };

  const handleRandomizeStandMeter = () => {
    updateField('standMeter', generateRandomStandMeter());
  };

  const handleSetCurrentTime = () => {
    const dt = generateCurrentDateTime();
    onChange({
      ...data,
      transactionDate: dt.date,
      transactionTime: dt.time,
    });
  };

  // Master Randomize All Numbers
  const handleRandomizeAll = () => {
    const dt = generateCurrentDateTime();
    const updated: ReceiptData = {
      ...data,
      referenceNumber: generateRandomReference(),
      transactionDate: dt.date,
      transactionTime: dt.time,
    };

    if (data.tokenListrik !== undefined || data.category === 'token_listrik') {
      updated.tokenListrik = generateRandomTokenListrik();
    }

    if (data.serialNumber !== undefined || data.category === 'pulsa') {
      updated.serialNumber = generateRandomSerial();
    }

    if (data.standMeter !== undefined || data.category === 'tagihan_listrik') {
      updated.standMeter = generateRandomStandMeter();
    }

    onChange(updated);
  };

  // Recalculate total when price or admin fee changes
  const handleCalculateTotal = (tagihanStr: string, adminFeeStr: string) => {
    const tagihanNum = parseInt(tagihanStr.replace(/[^0-9]/g, '') || '0', 10);
    const adminFeeNum = parseInt(adminFeeStr.replace(/[^0-9]/g, '') || '0', 10);
    const total = tagihanNum + adminFeeNum;

    onChange({
      ...data,
      tagihan: formatRupiah(tagihanNum),
      adminFee: formatRupiah(adminFeeNum),
      totalBayar: formatRupiah(total),
    });
  };

  // Custom Rows management
  const handleAddCustomRow = () => {
    const newRow = {
      id: `row_${Date.now()}`,
      label: 'Keterangan',
      value: 'Nilai',
    };
    onChange({
      ...data,
      customRows: [...(data.customRows || []), newRow],
    });
  };

  const handleUpdateCustomRow = (id: string, field: 'label' | 'value', val: string) => {
    onChange({
      ...data,
      customRows: (data.customRows || []).map((r) =>
        r.id === id ? { ...r, [field]: val } : r
      ),
    });
  };

  const handleDeleteCustomRow = (id: string) => {
    onChange({
      ...data,
      customRows: (data.customRows || []).map((r) => r).filter((r) => r.id !== id),
    });
  };

  return (
    <div className="space-y-5 text-sm">
      {/* 1. PRESET SELEKSI CEPAT */}
      <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
        <label className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
          Pilih Preset Transaksi PPOB:
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
          <button
            type="button"
            onClick={() => onSelectPreset('token_listrik_bukalapak')}
            className={`p-3 rounded-xl border text-left flex items-center gap-2.5 transition-all ${
              data.category === 'token_listrik' && data.layoutStyle === 'digital_mitra'
                ? 'bg-amber-50 border-amber-400 text-amber-900 shadow-xs font-semibold'
                : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            <div className="p-1.5 rounded-lg bg-amber-100 text-amber-700 shrink-0">
              <Zap className="w-4 h-4" />
            </div>
            <div className="truncate">
              <div className="text-xs font-bold truncate">Token PLN 50k</div>
              <div className="text-[10px] text-slate-500">Bukalapak Digital</div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onSelectPreset('pulsa_telkomsel')}
            className={`p-3 rounded-xl border text-left flex items-center gap-2.5 transition-all ${
              data.category === 'pulsa' && data.productName.includes('Telkomsel')
                ? 'bg-red-50 border-red-400 text-red-900 shadow-xs font-semibold'
                : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            <div className="p-1.5 rounded-lg bg-red-100 text-red-700 shrink-0">
              <Phone className="w-4 h-4" />
            </div>
            <div className="truncate">
              <div className="text-xs font-bold truncate">Pulsa 10k</div>
              <div className="text-[10px] text-slate-500">Bukalapak Digital</div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onSelectPreset('paket_data_indosat')}
            className={`p-3 rounded-xl border text-left flex items-center gap-2.5 transition-all ${
              data.category === 'pulsa' && data.productName.includes('Freedom')
                ? 'bg-amber-50 border-amber-400 text-amber-900 shadow-xs font-semibold'
                : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            <div className="p-1.5 rounded-lg bg-yellow-100 text-yellow-800 shrink-0">
              <Phone className="w-4 h-4" />
            </div>
            <div className="truncate">
              <div className="text-xs font-bold truncate">Paket Data</div>
              <div className="text-[10px] text-slate-500">Bukalapak Digital</div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onSelectPreset('tagihan_listrik_bukalapak')}
            className={`p-3 rounded-xl border text-left flex items-center gap-2.5 transition-all ${
              data.category === 'tagihan_listrik'
                ? 'bg-cyan-50 border-cyan-400 text-cyan-900 shadow-xs font-semibold'
                : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            <div className="p-1.5 rounded-lg bg-cyan-100 text-cyan-700 shrink-0">
              <FileSpreadsheet className="w-4 h-4" />
            </div>
            <div className="truncate">
              <div className="text-xs font-bold truncate">Tagihan PLN</div>
              <div className="text-[10px] text-slate-500">Pascabayar</div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onSelectPreset('tagihan_wifi_indihome')}
            className={`p-3 rounded-xl border text-left flex items-center gap-2.5 transition-all ${
              data.category === 'tagihan_wifi'
                ? 'bg-rose-50 border-rose-400 text-rose-900 shadow-xs font-semibold'
                : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            <div className="p-1.5 rounded-lg bg-rose-100 text-rose-700 shrink-0">
              <Wifi className="w-4 h-4" />
            </div>
            <div className="truncate">
              <div className="text-xs font-bold truncate">Tagihan WiFi</div>
              <div className="text-[10px] text-slate-500">Alfamart / Thermal</div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onSelectPreset('topup_ewallet_dana')}
            className={`p-3 rounded-xl border text-left flex items-center gap-2.5 transition-all ${
              data.category === 'topup_ewallet'
                ? 'bg-blue-50 border-blue-400 text-blue-900 shadow-xs font-semibold'
                : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            <div className="p-1.5 rounded-lg bg-blue-100 text-blue-700 shrink-0">
              <Wallet className="w-4 h-4" />
            </div>
            <div className="truncate">
              <div className="text-xs font-bold truncate">Topup E-Wallet</div>
              <div className="text-[10px] text-slate-500">DANA / GoPay</div>
            </div>
          </button>
        </div>
      </div>

      {/* 2. FORMAT KERTAS & TATA LETAK */}
      <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
        <label className="text-xs font-bold text-slate-800 block">
          Format Layout & Ukuran Kertas:
        </label>
        <div className="grid grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={() => {
              onChange({
                ...data,
                layoutStyle: 'digital_mitra',
                paperPreset: 'digital',
              });
            }}
            className={`py-2.5 px-3 rounded-xl text-xs font-bold border text-center transition-all ${
              data.layoutStyle === 'digital_mitra'
                ? 'bg-emerald-50 border-emerald-500 text-emerald-900 shadow-xs'
                : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
            }`}
          >
            Bukti Digital (Mitra Bukalapak)
            <span className="block text-[10px] font-normal text-slate-500">Tampilan Screenshot HP</span>
          </button>

          <button
            type="button"
            onClick={() => {
              onChange({
                ...data,
                layoutStyle: 'thermal_minimarket',
                paperPreset: '58mm',
              });
            }}
            className={`py-2.5 px-3 rounded-xl text-xs font-bold border text-center transition-all ${
              data.layoutStyle !== 'digital_mitra'
                ? 'bg-emerald-50 border-emerald-500 text-emerald-900 shadow-xs'
                : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
            }`}
          >
            Struk Kertas Kasir (Thermal)
            <span className="block text-[10px] font-normal text-slate-500">Font Monospace Kasir</span>
          </button>
        </div>

        {data.layoutStyle !== 'digital_mitra' && (
          <div className="pt-2 flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-600">Lebar Kertas:</span>
            <button
              type="button"
              onClick={() => updateField('paperPreset', '58mm')}
              className={`px-3 py-1 text-xs rounded-lg border transition-colors ${
                data.paperPreset === '58mm'
                  ? 'bg-slate-800 border-slate-900 text-white font-bold'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              58mm (Printer Kasir Kecil)
            </button>
            <button
              type="button"
              onClick={() => updateField('paperPreset', '80mm')}
              className={`px-3 py-1 text-xs rounded-lg border transition-colors ${
                data.paperPreset === '80mm'
                  ? 'bg-slate-800 border-slate-900 text-white font-bold'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              80mm (Lebar Standar)
            </button>
          </div>
        )}
      </div>

      {/* 3. TOMBOL MASTER ACAK OTOMATIS */}
      <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <div className="text-xs font-bold text-emerald-900 flex items-center gap-1.5">
              <Dices className="w-4 h-4 text-emerald-600" />
              Acak Otomatis Nomor Transaksi
            </div>
            <p className="text-[11px] text-emerald-700 mt-0.5">
              Acak token PLN, serial number (SN), no referensi, & waktu transaksi dengan 1 klik
            </p>
          </div>
          <button
            type="button"
            onClick={handleRandomizeAll}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-all shadow-xs active:scale-95 shrink-0"
          >
            <Dices className="w-4 h-4" />
            Acak Semua Nomor
          </button>
        </div>
      </div>

      {/* 4. PENGATURAN TOKO / HEADER */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-700">
            <Store className="w-4 h-4 text-emerald-600" />
            <span>Header Toko:</span>
            <span className="text-slate-900 font-bold">{data.storeHeader.storeName}</span>
          </div>
          <button
            type="button"
            onClick={onOpenHeaderModal}
            className="text-xs text-emerald-700 hover:text-emerald-800 font-bold underline transition-colors"
          >
            Ubah & Simpan Header
          </button>
        </div>
      </div>

      {/* 5. FORM DETAIL TRANSAKSI */}
      <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-2">
          <Receipt className="w-4 h-4 text-emerald-600" />
          Rincian Transaksi
        </h4>

        {/* Judul & Produk */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Judul Struk</label>
            <input
              type="text"
              value={data.receiptTitle}
              onChange={(e) => updateField('receiptTitle', e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-xs focus:bg-white focus:outline-hidden focus:border-emerald-500"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Nama Produk / Layanan</label>
            <input
              type="text"
              value={data.productName}
              onChange={(e) => updateField('productName', e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-xs focus:bg-white focus:outline-hidden focus:border-emerald-500"
            />
          </div>
        </div>

        {/* Tanggal & Waktu dengan tombol Sekarang */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-semibold text-slate-700">Tanggal Transaksi</label>
              <button
                type="button"
                onClick={handleSetCurrentTime}
                className="text-[11px] text-emerald-700 hover:underline flex items-center gap-1 font-medium"
              >
                <Clock className="w-3 h-3" /> Sekarang
              </button>
            </div>
            <input
              type="text"
              value={data.transactionDate}
              onChange={(e) => updateField('transactionDate', e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-xs focus:bg-white focus:outline-hidden focus:border-emerald-500"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Jam Transaksi</label>
            <input
              type="text"
              value={data.transactionTime}
              onChange={(e) => updateField('transactionTime', e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-xs focus:bg-white focus:outline-hidden focus:border-emerald-500"
            />
          </div>
        </div>

        {/* TOKEN LISTRIK (JIKA ADA) */}
        {(data.tokenListrik !== undefined || data.category === 'token_listrik') && (
          <div className="p-3.5 rounded-xl bg-amber-50/80 border border-amber-200 space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-amber-900 flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-amber-600" />
                Nomor Token Listrik (20 Digit)
              </label>
              <button
                type="button"
                onClick={handleRandomizeToken}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-100 hover:bg-amber-200 text-amber-900 text-xs font-bold transition-colors"
              >
                <Dices className="w-3.5 h-3.5" /> Acak Token
              </button>
            </div>
            <input
              type="text"
              value={data.tokenListrik || ''}
              onChange={(e) => updateField('tokenListrik', e.target.value)}
              placeholder="1760-1252-4112-3428-5165"
              className="w-full px-3 py-2 bg-white border border-amber-400 rounded-xl text-amber-900 font-mono text-sm font-bold tracking-wider focus:outline-hidden focus:ring-2 focus:ring-amber-300"
            />
            <div className="grid grid-cols-2 gap-2 pt-1">
              <div>
                <label className="text-[11px] font-semibold text-slate-600 block mb-0.5">Jumlah KWH</label>
                <input
                  type="text"
                  value={data.kwh || ''}
                  onChange={(e) => updateField('kwh', e.target.value)}
                  placeholder="33,7 KWH"
                  className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-slate-800 text-xs"
                />
              </div>
              <div>
                <label className="text-[11px] font-semibold text-slate-600 block mb-0.5">Tarif / Daya</label>
                <input
                  type="text"
                  value={data.tarifDaya || ''}
                  onChange={(e) => updateField('tarifDaya', e.target.value)}
                  placeholder="R1M/900 VA"
                  className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-slate-800 text-xs"
                />
              </div>
            </div>
          </div>
        )}

        {/* SERIAL NUMBER (SN) PULSA / PAKET DATA */}
        {(data.serialNumber !== undefined || data.category === 'pulsa') && (
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-emerald-600" />
                Nomor Serial (SN Pulsa / Kuota)
              </label>
              <button
                type="button"
                onClick={handleRandomizeSerial}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 text-xs font-semibold transition-colors"
              >
                <Dices className="w-3.5 h-3.5 text-emerald-600" /> Acak SN
              </button>
            </div>
            <input
              type="text"
              value={data.serialNumber || ''}
              onChange={(e) => updateField('serialNumber', e.target.value)}
              placeholder="Contoh: 0427130000589139803"
              className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-slate-900 font-mono text-xs focus:outline-hidden focus:border-emerald-500"
            />
          </div>
        )}

        {/* NO REFERENSI */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <label className="text-xs font-semibold text-slate-700">No. Referensi Transaksi</label>
            <button
              type="button"
              onClick={handleRandomizeReference}
              className="text-[11px] text-emerald-700 hover:underline flex items-center gap-1 font-medium"
            >
              <Dices className="w-3 h-3" /> Acak Ref
            </button>
          </div>
          <input
            type="text"
            value={data.referenceNumber || ''}
            onChange={(e) => updateField('referenceNumber', e.target.value)}
            placeholder="2BK125F37B1CFAD1C940E794FA3A0F0F"
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-mono text-xs focus:bg-white focus:outline-hidden focus:border-emerald-500"
          />
        </div>

        {/* PELANGGAN / NOMOR TUJUAN */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {(data.category === 'pulsa' || data.category === 'topup_ewallet' || (data.destinationNumber !== undefined && data.category !== 'token_listrik' && data.category !== 'tagihan_listrik')) && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Nomor Tujuan / No HP</label>
              <input
                type="text"
                value={data.destinationNumber || ''}
                onChange={(e) => updateField('destinationNumber', e.target.value)}
                placeholder="08123456789"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-xs focus:bg-white focus:outline-hidden focus:border-emerald-500"
              />
            </div>
          )}

          {(data.customerName !== undefined || data.category === 'token_listrik' || data.category === 'tagihan_listrik' || data.category === 'tagihan_wifi' || data.category === 'topup_ewallet') && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Nama Pelanggan</label>
              <input
                type="text"
                value={data.customerName || ''}
                onChange={(e) => updateField('customerName', e.target.value)}
                placeholder="Contoh: ATMIYAH"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-xs focus:bg-white focus:outline-hidden focus:border-emerald-500"
              />
            </div>
          )}

          {(data.meterNumber !== undefined || data.category === 'token_listrik' || data.category === 'tagihan_listrik') && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Nomor Meter PLN</label>
              <input
                type="text"
                value={data.meterNumber || ''}
                onChange={(e) => updateField('meterNumber', e.target.value)}
                placeholder="86032448739"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-mono text-xs focus:bg-white focus:outline-hidden focus:border-emerald-500"
              />
            </div>
          )}

          {(data.idpel !== undefined || data.category === 'token_listrik' || data.category === 'tagihan_listrik' || data.category === 'tagihan_wifi') && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">ID Pelanggan (IDPEL)</label>
              <input
                type="text"
                value={data.idpel || ''}
                onChange={(e) => updateField('idpel', e.target.value)}
                placeholder="522042444117"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-mono text-xs focus:bg-white focus:outline-hidden focus:border-emerald-500"
              />
            </div>
          )}

          {data.standMeter !== undefined && (
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-slate-700">Stand Meter</label>
                <button
                  type="button"
                  onClick={handleRandomizeStandMeter}
                  className="text-[11px] text-emerald-700 hover:underline flex items-center gap-1 font-medium"
                >
                  <Dices className="w-3 h-3" /> Acak
                </button>
              </div>
              <input
                type="text"
                value={data.standMeter}
                onChange={(e) => updateField('standMeter', e.target.value)}
                placeholder="00020529-00020557"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-xs focus:bg-white focus:outline-hidden focus:border-emerald-500"
              />
            </div>
          )}

          {data.periode !== undefined && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Periode</label>
              <input
                type="text"
                value={data.periode}
                onChange={(e) => updateField('periode', e.target.value)}
                placeholder="September 2026"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-xs focus:bg-white focus:outline-hidden focus:border-emerald-500"
              />
            </div>
          )}
        </div>

        {/* 6. NOMINAL & BIAYA ADMIN */}
        <div className="pt-3 border-t border-slate-200 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Tagihan / Harga Dasar</label>
              <input
                type="text"
                value={data.tagihan || ''}
                onChange={(e) => handleCalculateTotal(e.target.value, data.adminFee || '0')}
                placeholder="Rp50.000"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-xs focus:bg-white focus:outline-hidden focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Biaya Admin</label>
              <input
                type="text"
                value={data.adminFee || ''}
                onChange={(e) => handleCalculateTotal(data.tagihan || '0', e.target.value)}
                placeholder="Rp3.000"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-xs focus:bg-white focus:outline-hidden focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-emerald-800 mb-1">TOTAL BAYAR</label>
              <input
                type="text"
                value={data.totalBayar}
                onChange={(e) => updateField('totalBayar', e.target.value)}
                className="w-full px-3 py-2 bg-emerald-50 border border-emerald-400 rounded-xl text-emerald-900 text-xs font-bold"
              />
            </div>
          </div>
        </div>

        {/* 7. CATATAN & FOOTER */}
        <div className="space-y-3 pt-3 border-t border-slate-200">
          {data.infoNote !== undefined && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Catatan Petunjuk Transaksi (Di Bawah Token / Tagihan)
              </label>
              <input
                type="text"
                value={data.infoNote}
                onChange={(e) => updateField('infoNote', e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-xs focus:bg-white focus:outline-hidden focus:border-emerald-500"
              />
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Pesan Footer Struk (Bisa beberapa baris)
            </label>
            <textarea
              rows={4}
              value={data.footerNote}
              onChange={(e) => updateField('footerNote', e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-xs font-mono focus:bg-white focus:outline-hidden focus:border-emerald-500"
            />
          </div>
        </div>

        {/* 8. BARIS KUSTOM TAMBAHAN */}
        <div className="pt-3 border-t border-slate-200 space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-semibold text-slate-700">Baris Kustom Tambahan</label>
            <button
              type="button"
              onClick={handleAddCustomRow}
              className="flex items-center gap-1 text-xs text-emerald-700 font-bold hover:underline"
            >
              <Plus className="w-3.5 h-3.5" /> Tambah Baris
            </button>
          </div>

          {data.customRows?.map((row) => (
            <div key={row.id} className="flex items-center gap-2">
              <input
                type="text"
                value={row.label}
                onChange={(e) => handleUpdateCustomRow(row.id, 'label', e.target.value)}
                placeholder="Label"
                className="w-1/3 px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800"
              />
              <input
                type="text"
                value={row.value}
                onChange={(e) => handleUpdateCustomRow(row.id, 'value', e.target.value)}
                placeholder="Nilai"
                className="flex-1 px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800"
              />
              <button
                type="button"
                onClick={() => handleDeleteCustomRow(row.id)}
                className="p-1.5 text-slate-400 hover:text-red-500"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
