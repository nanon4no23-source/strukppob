import React, { useState, useRef, useEffect } from 'react';
import { 
  Upload, 
  Camera, 
  Sparkles, 
  X, 
  AlertCircle, 
  Check, 
  Loader2, 
  FileImage, 
  Zap, 
  Phone, 
  Wifi, 
  Wallet, 
  ArrowRight,
  RefreshCw
} from 'lucide-react';
import { ReceiptData } from '../types';

interface PhotoUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyExtractedData: (data: Partial<ReceiptData>, detectedPresetKey?: string) => void;
  initialImage?: string | null;
}

export const PhotoUploadModal: React.FC<PhotoUploadModalProps> = ({
  isOpen,
  onClose,
  onApplyExtractedData,
  initialImage = null,
}) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(initialImage);
  const [mimeType, setMimeType] = useState<string>('image/jpeg');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [processingStatus, setProcessingStatus] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [extractedData, setExtractedData] = useState<any | null>(null);
  const [appliedCategory, setAppliedCategory] = useState<string | null>(null);
  const [autoCloseSeconds, setAutoCloseSeconds] = useState<number | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  // Reset state when opening or closing
  useEffect(() => {
    if (!isOpen) {
      setSelectedImage(null);
      setExtractedData(null);
      setErrorMessage(null);
      setIsProcessing(false);
      setAppliedCategory(null);
      setAutoCloseSeconds(null);
    }
  }, [isOpen]);

  // Clipboard paste listener when modal is open
  useEffect(() => {
    if (!isOpen) return;

    const handlePaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (!items) return;

      for (let i = 0; i < items.length; i++) {
        if (items[i].type.startsWith('image/')) {
          const file = items[i].getAsFile();
          if (file) {
            processAndExtractFile(file);
            break;
          }
        }
      }
    };

    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, [isOpen]);

  // Countdown timer after auto-apply
  useEffect(() => {
    if (autoCloseSeconds === null) return;
    if (autoCloseSeconds <= 0) {
      onClose();
      return;
    }
    const timer = setTimeout(() => {
      setAutoCloseSeconds((prev) => (prev !== null ? prev - 1 : null));
    }, 1000);
    return () => clearTimeout(timer);
  }, [autoCloseSeconds, onClose]);

  if (!isOpen) return null;

  // Compress image on client side so camera photos don't timeout
  const compressImage = (file: File): Promise<{ base64: string; mimeType: string }> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = reject;
      reader.onload = () => {
        const img = new Image();
        img.onerror = reject;
        img.onload = () => {
          const maxDim = 1600;
          let width = img.width;
          let height = img.height;

          if (width > maxDim || height > maxDim) {
            if (width > height) {
              height = Math.round((height * maxDim) / width);
              width = maxDim;
            } else {
              width = Math.round((width * maxDim) / height);
              height = maxDim;
            }
          }

          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');

          if (!ctx) {
            resolve({ base64: reader.result as string, mimeType: file.type || 'image/jpeg' });
            return;
          }

          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, width, height);
          ctx.drawImage(img, 0, 0, width, height);

          // Quality 0.85 jpeg
          const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.85);
          resolve({ base64: compressedDataUrl, mimeType: 'image/jpeg' });
        };
        img.src = reader.result as string;
      };
      reader.readAsDataURL(file);
    });
  };

  // Convert raw AI extracted data into ReceiptData & trigger application
  const applyExtractedResult = (raw: any) => {
    // Detect thermal layout vs digital
    const isThermal = 
      raw.layoutStyle?.includes('thermal') ||
      (raw.receiptTitle && /STRUK|TELKOM PAY|ALFAMART|INDOMARET/i.test(raw.receiptTitle)) ||
      (raw.storeHeader?.storeName && /ALFAMART|INDOMARET/i.test(raw.storeHeader.storeName));

    // Check if Token Listrik
    const isTokenListrik = 
      raw.category === 'token_listrik' ||
      Boolean(raw.tokenListrik && raw.tokenListrik.trim().length > 0) ||
      /token|stroom|prabayar/i.test(raw.productName || '') ||
      /token|stroom|prabayar/i.test(raw.receiptTitle || '');

    // Format 20 digit token into 4-digit groups if needed
    let cleanToken = raw.tokenListrik || '';
    if (cleanToken) {
      const digitsOnly = cleanToken.replace(/[^0-9]/g, '');
      if (digitsOnly.length === 20) {
        cleanToken = `${digitsOnly.slice(0, 4)}-${digitsOnly.slice(4, 8)}-${digitsOnly.slice(8, 12)}-${digitsOnly.slice(12, 16)}-${digitsOnly.slice(16, 20)}`;
      }
    }

    const partialData: Partial<ReceiptData> = {
      layoutStyle: isThermal ? 'thermal_minimarket' : 'digital_mitra',
      paperPreset: isThermal ? '58mm' : 'digital',
      category: isTokenListrik ? 'token_listrik' : (raw.category || 'token_listrik'),
      receiptTitle: raw.receiptTitle || (isThermal ? 'STRUK PEMBAYARAN' : 'Bukti Transaksi'),
      productName: raw.productName || (isTokenListrik ? 'Token Listrik Prabayar 50000' : 'Produk Transaksi'),
      transactionDate: raw.transactionDate || '',
      transactionTime: raw.transactionTime || '',
      customerName: raw.customerName || '',
      meterNumber: raw.meterNumber || '',
      idpel: raw.idpel || '',
      tarifDaya: raw.tarifDaya || '',
      destinationNumber: raw.destinationNumber || '',
      serialNumber: raw.serialNumber || '',
      referenceNumber: raw.referenceNumber || '',
      transactionId: raw.transactionId || '',
      tokenListrik: cleanToken,
      kwh: raw.kwh || '',
      periode: raw.periode || '',
      standMeter: raw.standMeter || '',
      tagihan: raw.tagihan || '',
      adminFee: raw.adminFee || '',
      discount: raw.discount || '',
      totalBayar: raw.totalBayar || 'Rp0',
      paymentMethod: raw.paymentMethod || (isThermal ? 'TUNAI' : 'Tunai'),
      infoNote: raw.infoNote || (isTokenListrik ? 'Jika gagal isi token: Rekam pengisian token yang gagal, telepon (kode area) 123.' : ''),
      footerNote: raw.footerNote || '',
    };

    if (raw.storeHeader) {
      partialData.storeHeader = {
        storeName: raw.storeHeader.storeName || '',
        storeAddress: raw.storeHeader.storeAddress || '',
        storeNpwp: raw.storeHeader.storeNpwp || '',
        storeContact: raw.storeHeader.storeContact || '',
        headerNote: raw.storeHeader.headerNote || '',
      };
    }

    if (raw.customRows && Array.isArray(raw.customRows)) {
      partialData.customRows = raw.customRows.map((r: any, idx: number) => ({
        id: `ocr-custom-${idx}`,
        label: r.label || '',
        value: r.value || '',
      }));
    }

    let presetKey = raw.detectedPreset;
    if (!presetKey) {
      if (isTokenListrik) {
        presetKey = isThermal ? 'token_listrik_thermal' : 'token_listrik_bukalapak';
      } else if (raw.category === 'tagihan_wifi') {
        presetKey = 'tagihan_wifi_indihome';
      } else if (raw.category === 'pulsa') {
        presetKey = /data|kuota|internet/i.test(raw.productName || '') ? 'paket_data_indosat' : 'pulsa_telkomsel';
      } else if (raw.category === 'tagihan_listrik') {
        presetKey = 'tagihan_listrik_bukalapak';
      } else if (raw.category === 'topup_ewallet') {
        presetKey = 'topup_ewallet_dana';
      }
    }

    // Automatically apply to editor form!
    onApplyExtractedData(partialData, presetKey);

    const categoryText = isTokenListrik 
      ? 'Token Listrik PLN' 
      : raw.category === 'tagihan_wifi' 
      ? 'Tagihan WiFi / Indihome'
      : raw.category === 'pulsa' 
      ? 'Pulsa / Paket Data'
      : raw.category === 'tagihan_listrik'
      ? 'Tagihan Listrik Pascabayar'
      : raw.category === 'topup_ewallet'
      ? 'Top Up E-Wallet'
      : 'Struk Kasir';

    setAppliedCategory(categoryText);
    setAutoCloseSeconds(3); // Auto-close modal after 3 seconds so user can see what happened
  };

  // Automated end-to-end extraction upon file upload
  const processAndExtractFile = async (file: File) => {
    if (!file.type.startsWith('image/')) {
      setErrorMessage('Silakan pilih file gambar (JPG, PNG, WEBP).');
      return;
    }

    setErrorMessage(null);
    setExtractedData(null);
    setAppliedCategory(null);
    setAutoCloseSeconds(null);
    setIsProcessing(true);
    setProcessingStatus('Mengoptimalkan resolusi foto...');

    try {
      // Step 1: Compress photo client-side
      const { base64, mimeType: compMime } = await compressImage(file);
      setSelectedImage(base64);
      setMimeType(compMime);

      // Step 2: Extract directly with Gemini AI (Multi-endpoint fallback for APK & Web)
      setProcessingStatus('AI Gemini sedang menganalisis nomor token, teks & data struk...');
      
      const payload = JSON.stringify({
        imageBase64: base64,
        mimeType: compMime,
      });

      // Di dalam APK Capacitor, tidak ada backend Node.js lokal, sehingga panggil Cloud Run backend
      const isLocalApk = 
        typeof window !== 'undefined' && 
        (window.location.protocol === 'capacitor:' || 
         window.location.hostname === 'localhost' || 
         window.location.hostname === '127.0.0.1');

      const candidateEndpoints: string[] = [];
      if (!isLocalApk) {
        candidateEndpoints.push('/api/extract-receipt');
      }
      // Endpoint cloud AI Studio aktif
      candidateEndpoints.push(
        'https://ais-dev-5kd4azqyfxlrtjrzjg6v6b-386138592370.asia-southeast1.run.app/api/extract-receipt',
        'https://ais-pre-5kd4azqyfxlrtjrzjg6v6b-386138592370.asia-southeast1.run.app/api/extract-receipt'
      );
      if (isLocalApk) {
        candidateEndpoints.push('/api/extract-receipt');
      }

      let lastError: Error | null = null;
      let result: any = null;

      for (const endpoint of candidateEndpoints) {
        try {
          const response = await fetch(endpoint, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
            },
            body: payload,
          });

          const responseText = await response.text();
          
          // Cegah error Unexpected token '<', "<!doctype "
          if (responseText.trim().startsWith('<') || !responseText.trim().startsWith('{')) {
            console.warn(`Endpoint ${endpoint} mengembalikan HTML, beralih ke endpoint berikutnya...`);
            continue;
          }

          const parsed = JSON.parse(responseText);
          if (response.ok && parsed.success) {
            result = parsed;
            break;
          } else {
            lastError = new Error(parsed.error || parsed.details || 'Gagal membaca respon AI');
          }
        } catch (fetchErr: any) {
          console.warn(`Gagal memanggil endpoint ${endpoint}:`, fetchErr);
          lastError = fetchErr;
        }
      }

      if (!result || !result.success) {
        throw lastError || new Error('Gagal menganalisis foto struk. Pastikan HP terhubung ke internet dan foto struk terbaca jelas.');
      }

      setProcessingStatus('Menyalin data ke form preset...');
      setExtractedData(result.data);

      // Step 3: Automatically apply to form!
      applyExtractedResult(result.data);

    } catch (err: any) {
      console.error('Extraction error:', err);
      setErrorMessage(err.message || 'Gagal memproses gambar. Pastikan foto struk cukup terang dan terbaca jelas.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    processAndExtractFile(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (!file) return;
    processAndExtractFile(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="w-full max-w-xl bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-white">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-cyan-50 text-cyan-600 border border-cyan-200">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Upload Foto & Salin ke Form Otomatis</h3>
              <p className="text-xs text-slate-500">
                Unggah foto token listrik / struk, AI akan otomatis mengisi formulir preset
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4 overflow-y-auto flex-1">
          {/* Main Upload Dropzone */}
          {!selectedImage && !isProcessing && (
            <div className="space-y-3">
              <div
                onDragOver={handleDragOver}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-300 hover:border-cyan-500 rounded-2xl p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-all bg-slate-50 hover:bg-slate-100/70 group"
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleFileChange}
                />
                <input
                  ref={cameraInputRef}
                  type="file"
                  accept="image/*"
                  capture="environment"
                  className="hidden"
                  onChange={handleFileChange}
                />

                <div className="p-4 rounded-2xl bg-white text-slate-600 group-hover:text-cyan-600 group-hover:bg-cyan-50 transition-all mb-3 shadow-xs border border-slate-200">
                  <Upload className="w-8 h-8" />
                </div>

                <p className="text-sm font-bold text-slate-900">
                  Pilih atau Tarik Foto Struk ke Sini
                </p>
                <p className="text-xs text-slate-500 mt-1 max-w-sm">
                  Struk Token PLN, screenshot Bukalapak, pulsa, WiFi, atau kertas kasir Alfamart / Indomaret.
                </p>

                <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                  <span className="text-[11px] text-cyan-800 bg-cyan-50 border border-cyan-200 px-2.5 py-1 rounded-full flex items-center gap-1 font-semibold">
                    <Sparkles className="w-3 h-3 text-cyan-600" /> Otomatis Terisi ke Form
                  </span>
                  <span className="text-[11px] text-slate-600 bg-slate-100 px-2.5 py-1 rounded-full flex items-center gap-1 font-medium">
                    <FileImage className="w-3 h-3" /> JPG, PNG, atau Paste (Ctrl+V)
                  </span>
                </div>
              </div>

              {/* Mobile Quick Camera Button */}
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => cameraInputRef.current?.click()}
                  className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold border border-slate-200 transition-colors"
                >
                  <Camera className="w-4 h-4 text-cyan-600" />
                  Foto dengan Kamera
                </button>
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold border border-slate-200 transition-colors"
                >
                  <Upload className="w-4 h-4 text-emerald-600" />
                  Pilih dari Galeri
                </button>
              </div>
            </div>
          )}

          {/* Processing State with Live Animation */}
          {isProcessing && (
            <div className="p-8 rounded-2xl bg-slate-50 border border-cyan-300 flex flex-col items-center justify-center text-center space-y-4">
              {selectedImage && (
                <div className="relative w-28 h-36 rounded-xl overflow-hidden border border-cyan-400 shadow-lg mb-1">
                  <img
                    src={selectedImage}
                    alt="Scanning"
                    className="w-full h-full object-cover"
                  />
                  {/* Laser scan animation */}
                  <div className="absolute inset-x-0 h-1 bg-cyan-500 shadow-[0_0_12px_#06b6d4] animate-bounce" />
                </div>
              )}

              <div className="flex items-center gap-2 text-cyan-700 font-bold text-sm">
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>{processingStatus || 'Sedang Memproses Foto...'}</span>
              </div>

              <p className="text-xs text-slate-500 max-w-sm">
                AI sedang membaca nomor meter, nomor token 20 digit, nominal, nama pelanggan, dan format struk agar form terisi persis.
              </p>
            </div>
          )}

          {/* SUCCESS State: Automatically Applied! */}
          {!isProcessing && extractedData && appliedCategory && (
            <div className="space-y-4">
              {/* Success Banner */}
              <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-300 flex items-start gap-3">
                <div className="p-2 rounded-full bg-emerald-100 text-emerald-700 mt-0.5">
                  <Check className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-bold text-emerald-900">
                      Berhasil! Form {appliedCategory} Telah Terisi Otomatis
                    </h4>
                    <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold">
                      {extractedData.category || 'PPOB'}
                    </span>
                  </div>
                  <p className="text-xs text-emerald-700 mt-1">
                    Semua rincian dari foto telah disalin ke formulir editor dan tampilan struk telah diperbarui.
                  </p>
                </div>
              </div>

              {/* Data Summary Preview */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="text-xs font-bold text-slate-700 flex items-center justify-between">
                  <span>Rincian yang Disalin dari Foto:</span>
                  {autoCloseSeconds !== null && (
                    <span className="text-[11px] text-cyan-700 font-semibold animate-pulse">
                      Menutup dalam {autoCloseSeconds}s...
                    </span>
                  )}
                </div>

                {/* Token PLN Highlight */}
                {extractedData.tokenListrik && (
                  <div className="p-3 rounded-xl bg-amber-50 border border-amber-300 space-y-1">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-amber-900">
                      <Zap className="w-3.5 h-3.5 text-amber-600" />
                      Nomor Token Listrik (20 Digit) Disalin:
                    </div>
                    <div className="font-mono text-base font-bold text-amber-900 tracking-wider">
                      {extractedData.tokenListrik}
                    </div>
                  </div>
                )}

                {/* Grid details */}
                <div className="grid grid-cols-2 gap-2 text-xs">
                  {extractedData.meterNumber && (
                    <div className="p-2 rounded-lg bg-white border border-slate-200">
                      <span className="text-slate-500 block text-[10px]">No. Meter PLN:</span>
                      <span className="font-mono font-bold text-slate-900">{extractedData.meterNumber}</span>
                    </div>
                  )}
                  {extractedData.idpel && (
                    <div className="p-2 rounded-lg bg-white border border-slate-200">
                      <span className="text-slate-500 block text-[10px]">ID Pelanggan (IDPEL):</span>
                      <span className="font-mono font-bold text-slate-900">{extractedData.idpel}</span>
                    </div>
                  )}
                  {extractedData.customerName && (
                    <div className="p-2 rounded-lg bg-white border border-slate-200">
                      <span className="text-slate-500 block text-[10px]">Nama Pelanggan:</span>
                      <span className="font-bold text-slate-900 truncate block">{extractedData.customerName}</span>
                    </div>
                  )}
                  {extractedData.tarifDaya && (
                    <div className="p-2 rounded-lg bg-white border border-slate-200">
                      <span className="text-slate-500 block text-[10px]">Tarif / Daya:</span>
                      <span className="font-bold text-slate-900">{extractedData.tarifDaya}</span>
                    </div>
                  )}
                  {extractedData.kwh && (
                    <div className="p-2 rounded-lg bg-white border border-slate-200">
                      <span className="text-slate-500 block text-[10px]">Jumlah KWH:</span>
                      <span className="font-bold text-slate-900">{extractedData.kwh}</span>
                    </div>
                  )}
                  {extractedData.totalBayar && (
                    <div className="p-2 rounded-lg bg-white border border-slate-200">
                      <span className="text-slate-500 block text-[10px]">Total Bayar:</span>
                      <span className="font-bold text-emerald-700">{extractedData.totalBayar}</span>
                    </div>
                  )}
                  {extractedData.destinationNumber && (
                    <div className="p-2 rounded-lg bg-white border border-slate-200">
                      <span className="text-slate-500 block text-[10px]">No. HP Tujuan:</span>
                      <span className="font-mono font-bold text-slate-900">{extractedData.destinationNumber}</span>
                    </div>
                  )}
                  {extractedData.serialNumber && (
                    <div className="p-2 rounded-lg bg-white border border-slate-200">
                      <span className="text-slate-500 block text-[10px]">SN / Serial:</span>
                      <span className="font-mono font-bold text-slate-900 text-[11px] truncate block">{extractedData.serialNumber}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Error Notice */}
          {errorMessage && (
            <div className="flex items-start gap-3 p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
              <div className="flex-1">
                <p className="font-bold">Gagal Membaca Struk</p>
                <p className="text-rose-700 mt-0.5">{errorMessage}</p>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="mt-2 text-xs font-bold text-rose-800 hover:underline flex items-center gap-1"
                >
                  <RefreshCw className="w-3 h-3" /> Coba Unggah Foto Lain
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-200 bg-slate-50">
          {extractedData ? (
            <>
              <button
                type="button"
                onClick={() => {
                  setSelectedImage(null);
                  setExtractedData(null);
                  setAutoCloseSeconds(null);
                  fileInputRef.current?.click();
                }}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-xl bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 transition-colors"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Upload Foto Lain
              </button>

              <button
                type="button"
                onClick={onClose}
                className="flex items-center gap-2 px-5 py-2 text-xs font-bold rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white transition-all shadow-xs active:scale-95"
              >
                <span>Buka & Edit Form Struk</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </>
          ) : (
            <>
              <span className="text-[11px] text-slate-500">
                Pilih foto untuk langsung mengisi formulir
              </span>
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold rounded-xl bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 transition-colors"
              >
                Batal
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
