import React, { useState, useRef, useEffect } from 'react';
import { 
  Upload, 
  Camera, 
  Sparkles, 
  X, 
  AlertCircle, 
  Check, 
  Loader2, 
  FileImage, 
  Zap, 
  Phone, 
  Wifi, 
  Wallet, 
  ArrowRight,
  RefreshCw,
  FileText,
  ClipboardPaste
} from 'lucide-react';
import { ReceiptData } from '../types';
import { parseReceiptFromText, ExtractedReceiptResult } from '../utils/receiptOcrParser';
import { createWorker } from 'tesseract.js';

interface PhotoUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyExtractedData: (data: Partial<ReceiptData>, detectedPresetKey?: string) => void;
  initialImage?: string | null;
}

export const PhotoUploadModal: React.FC<PhotoUploadModalProps> = ({
  isOpen,
  onClose,
  onApplyExtractedData,
  initialImage = null,
}) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(initialImage);
  const [mimeType, setMimeType] = useState<string>('image/jpeg');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [processingStatus, setProcessingStatus] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [extractedData, setExtractedData] = useState<any | null>(null);
  const [appliedCategory, setAppliedCategory] = useState<string | null>(null);
  const [autoCloseSeconds, setAutoCloseSeconds] = useState<number | null>(null);
  const [isManualPasteOpen, setIsManualPasteOpen] = useState(false);
  const [manualText, setManualText] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  // Reset state when opening or closing
  useEffect(() => {
    if (!isOpen) {
      setSelectedImage(null);
      setExtractedData(null);
      setErrorMessage(null);
      setIsProcessing(false);
      setAppliedCategory(null);
      setAutoCloseSeconds(null);
      setIsManualPasteOpen(false);
      setManualText('');
    }
  }, [isOpen]);

  // Clipboard paste listener when modal is open
  useEffect(() => {
    if (!isOpen) return;

    const handlePaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (!items) return;

      for (let i = 0; i < items.length; i++) {
        if (items[i].type.startsWith('image/')) {
          const file = items[i].getAsFile();
          if (file) {
            processAndExtractFile(file);
            break;
          }
        }
      }
    };

    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, [isOpen]);

  // Countdown timer after auto-apply
  useEffect(() => {
    if (autoCloseSeconds === null) return;
    if (autoCloseSeconds <= 0) {
      onClose();
      return;
    }
    const timer = setTimeout(() => {
      setAutoCloseSeconds((prev) => (prev !== null ? prev - 1 : null));
    }, 1000);
    return () => clearTimeout(timer);
  }, [autoCloseSeconds, onClose]);

  if (!isOpen) return null;

  // Compress image on client side
  const compressImage = (file: File): Promise<{ base64: string; mimeType: string }> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = reject;
      reader.onload = () => {
        const img = new Image();
        img.onerror = reject;
        img.onload = () => {
          const maxDim = 1200;
          let width = img.width;
          let height = img.height;

          if (width > maxDim || height > maxDim) {
            if (width > height) {
              height = Math.round((height * maxDim) / width);
              width = maxDim;
            } else {
              width = Math.round((width * maxDim) / height);
              height = maxDim;
            }
          }

          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');

          if (!ctx) {
            resolve({ base64: reader.result as string, mimeType: file.type || 'image/jpeg' });
            return;
          }

          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, width, height);
          ctx.drawImage(img, 0, 0, width, height);

          const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.85);
          resolve({ base64: compressedDataUrl, mimeType: 'image/jpeg' });
        };
        img.src = reader.result as string;
      };
      reader.readAsDataURL(file);
    });
  };

  // Convert raw extracted data into ReceiptData & trigger application
  const applyExtractedResult = (raw: any) => {
    const isThermal = 
      raw.layoutStyle?.includes('thermal') ||
      (raw.receiptTitle && /STRUK|TELKOM PAY|ALFAMART|INDOMARET/i.test(raw.receiptTitle)) ||
      (raw.storeHeader?.storeName && /ALFAMART|INDOMARET/i.test(raw.storeHeader.storeName));

    const isTokenListrik = Boolean(
      raw.category === 'token_listrik' || 
      (raw.tokenListrik && raw.tokenListrik.replace(/[^0-9]/g, '').length >= 20) ||
      (raw.productName && /TOKEN|PLN|PRABAYAR/i.test(raw.productName))
    );

    const partialData: Partial<ReceiptData> = {
      productName: raw.productName || (isTokenListrik ? 'Token Listrik Prabayar' : 'Struk Transaksi'),
      receiptTitle: raw.receiptTitle || (isTokenListrik ? 'STRUK PEMBELIAN LISTRIK PRABAYAR' : 'BUKTI TRANSAKSI'),
      transactionDate: raw.transactionDate || '',
      transactionTime: raw.transactionTime || '',
      customerName: raw.customerName || '',
      meterNumber: raw.meterNumber || '',
      idpel: raw.idpel || '',
      tarifDaya: raw.tarifDaya || '',
      destinationNumber: raw.destinationNumber || '',
      serialNumber: raw.serialNumber || '',
      referenceNumber: raw.referenceNumber || '',
      transactionId: raw.transactionId || '',
      tokenListrik: raw.tokenListrik || '',
      kwh: raw.kwh || '',
      periode: raw.periode || '',
      standMeter: raw.standMeter || '',
      tagihan: raw.tagihan || '',
      adminFee: raw.adminFee || '',
      totalBayar: raw.totalBayar || '',
    };

    if (raw.storeHeader) {
      partialData.storeHeader = {
        storeName: raw.storeHeader.storeName || '',
        storeAddress: raw.storeHeader.storeAddress || '',
        storeNpwp: raw.storeHeader.storeNpwp || '',
        storeContact: raw.storeHeader.storeContact || '',
        headerNote: raw.storeHeader.headerNote || '',
      };
    }

    let presetKey = raw.detectedPreset;
    if (!presetKey) {
      if (isTokenListrik) {
        presetKey = isThermal ? 'token_listrik_thermal' : 'token_listrik_bukalapak';
      } else if (raw.category === 'tagihan_wifi') {
        presetKey = 'tagihan_wifi_indihome';
      } else if (raw.category === 'pulsa') {
        presetKey = /data|kuota|internet/i.test(raw.productName || '') ? 'paket_data_indosat' : 'pulsa_telkomsel';
      } else if (raw.category === 'tagihan_listrik') {
        presetKey = 'tagihan_listrik_bukalapak';
      } else if (raw.category === 'topup_ewallet') {
        presetKey = 'topup_ewallet_dana';
      }
    }

    onApplyExtractedData(partialData, presetKey);

    const categoryText = isTokenListrik 
      ? 'Token Listrik PLN' 
      : raw.category === 'tagihan_wifi' 
      ? 'Tagihan WiFi / Indihome'
      : raw.category === 'pulsa' 
      ? 'Pulsa / Paket Data'
      : raw.category === 'tagihan_listrik'
      ? 'Tagihan Listrik Pascabayar'
      : raw.category === 'topup_ewallet'
      ? 'Top Up E-Wallet'
      : 'Struk Kasir';

    setAppliedCategory(categoryText);
    setAutoCloseSeconds(3);
  };

  // Perform Local OCR via Tesseract.js directly inside Phone
  const performLocalOcr = async (imageSrc: string): Promise<any> => {
    setProcessingStatus('Memindai nomor token & teks struk di HP...');
    try {
      const worker = await createWorker('eng', 1, {
        logger: (m) => {
          if (m.status === 'recognizing text') {
            const pct = Math.round((m.progress || 0) * 100);
            setProcessingStatus(`Membaca teks foto: ${pct}%...`);
          }
        },
      });

      const ret = await worker.recognize(imageSrc);
      await worker.terminate();

      const ocrText = ret.data.text || '';
      console.log('Tesseract OCR Output:', ocrText);

      const parsed = parseReceiptFromText(ocrText);
      return parsed;
    } catch (e: any) {
      console.warn('Local OCR warning:', e);
      // Fallback regex langsung
      return parseReceiptFromText('');
    }
  };

  // Automated extraction upon file upload
  const processAndExtractFile = async (file: File) => {
    if (!file.type.startsWith('image/')) {
      setErrorMessage('Silakan pilih file gambar (JPG, PNG, WEBP).');
      return;
    }

    setErrorMessage(null);
    setExtractedData(null);
    setAppliedCategory(null);
    setAutoCloseSeconds(null);
    setIsProcessing(true);
    setProcessingStatus('Mengoptimalkan foto...');

    try {
      const { base64, mimeType: compMime } = await compressImage(file);
      setSelectedImage(base64);
      setMimeType(compMime);

      setProcessingStatus('Menganalisis nomor token & data struk...');

      let resultData: any = null;

      // Coba panggil server jika ada koneksi
      const isLocalHost = typeof window !== 'undefined' && 
        (window.location.protocol === 'capacitor:' || window.location.hostname === 'localhost');

      if (!isLocalHost) {
        try {
          const response = await fetch('/api/extract-receipt', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ imageBase64: base64, mimeType: compMime }),
          });
          const text = await response.text();
          if (text.trim().startsWith('{')) {
            const parsed = JSON.parse(text);
            if (parsed.success && parsed.data) {
              resultData = parsed.data;
            }
          }
        } catch {
          // ignore, continue to local OCR
        }
      }

      // Jika server tidak tersedia (seperti di APK Android), gunakan OCR lokal Tesseract di HP!
      if (!resultData) {
        setProcessingStatus('Memindai foto langsung di HP (Mode Mandiri)...');
        resultData = await performLocalOcr(base64);
      }

      setProcessingStatus('Menyalin data ke form preset...');
      setExtractedData(resultData);
      applyExtractedResult(resultData);

    } catch (err: any) {
      console.error('Extraction error:', err);
      setErrorMessage('Gagal memproses gambar. Pastikan foto cukup terang atau gunakan fitur Tempel Teks.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleManualTextSubmit = () => {
    if (!manualText.trim()) return;
    setIsProcessing(true);
    setProcessingStatus('Membaca teks...');
    try {
      const parsed = parseReceiptFromText(manualText);
      setExtractedData(parsed);
      applyExtractedResult(parsed);
    } catch (e: any) {
      setErrorMessage('Gagal memproses teks.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    processAndExtractFile(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (!file) return;
    processAndExtractFile(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="w-full max-w-lg bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-cyan-50 text-cyan-600 border border-cyan-200 shadow-2xs">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Upload Foto Struk & Token</h3>
              <p className="text-xs text-slate-500">
                AI & Scanner otomatis mengisi formulir preset
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-4">
          
          {/* Status Sukses Diterapkan */}
          {appliedCategory && (
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-center justify-between animate-in fade-in slide-in-from-top-2 duration-200">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0">
                  <Check className="w-4 h-4" />
                </div>
                <div>
                  <p className="font-bold text-sm">Data Berhasil Disalin!</p>
                  <p className="text-emerald-700 text-[11px]">
                    Kategori <span className="font-bold">{appliedCategory}</span> telah terisi ke form editor.
                  </p>
                </div>
              </div>
              {autoCloseSeconds !== null && (
                <span className="text-[11px] font-semibold text-emerald-700 px-2 py-1 bg-emerald-100/80 rounded-lg">
                  Tutup ({autoCloseSeconds}s)
                </span>
              )}
            </div>
          )}

          {/* Loading Indicator */}
          {isProcessing && (
            <div className="p-5 rounded-2xl bg-cyan-50/80 border border-cyan-200 text-cyan-900 text-center space-y-3">
              <Loader2 className="w-8 h-8 text-cyan-600 animate-spin mx-auto" />
              <p className="font-bold text-sm text-cyan-950">{processingStatus}</p>
              <p className="text-xs text-cyan-700">Memproses di perangkat HP Anda...</p>
            </div>
          )}

          {/* Error Message */}
          {errorMessage && (
            <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-red-900 text-xs flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-sm">Pemberitahuan</p>
                <p className="text-red-700 text-xs mt-0.5">{errorMessage}</p>
              </div>
            </div>
          )}

          {/* Main Upload Dropzone */}
          {!isProcessing && !isManualPasteOpen && (
            <div
              onDrop={handleDrop}
              onDragOver={(e) => e.preventDefault()}
              className="border-2 border-dashed border-slate-300 hover:border-cyan-500 rounded-2xl p-6 sm:p-8 text-center bg-slate-50/50 hover:bg-cyan-50/20 transition-all cursor-pointer group"
              onClick={() => fileInputRef.current?.click()}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleFileChange}
              />
              <input
                ref={cameraInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                className="hidden"
                onChange={handleFileChange}
              />

              <div className="w-14 h-14 mx-auto mb-3 rounded-2xl bg-cyan-100 text-cyan-600 flex items-center justify-center group-hover:scale-105 transition-transform shadow-2xs">
                <Upload className="w-7 h-7" />
              </div>

              <h4 className="text-sm font-bold text-slate-800 mb-1">
                Pilih Foto dari Galeri atau Kamera HP
              </h4>
              <p className="text-xs text-slate-500 mb-4 max-w-xs mx-auto">
                Foto struk minimarket, token PLN, atau screenshot transaksi PPOB
              </p>

              <div className="flex items-center justify-center gap-2">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    fileInputRef.current?.click();
                  }}
                  className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-sm flex items-center gap-1.5 transition-all"
                >
                  <FileImage className="w-3.5 h-3.5" />
                  <span>Buka Galeri</span>
                </button>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    cameraInputRef.current?.click();
                  }}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs shadow-sm flex items-center gap-1.5 transition-all"
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>Ambil Foto</span>
                </button>
              </div>
            </div>
          )}

          {/* Opsi Tempel Teks Manual */}
          {!isProcessing && isManualPasteOpen && (
            <div className="space-y-3">
              <label className="block text-xs font-bold text-slate-800">
                Tempelkan Teks SMS / WhatsApp Transaksi:
              </label>
              <textarea
                value={manualText}
                onChange={(e) => setManualText(e.target.value)}
                placeholder="Contoh: Pembelian Token PLN 50.000 No Meter: 14123456789 Token: 1234-5678-9012-3456-7890 Total: Rp53.000"
                rows={4}
                className="w-full p-3 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-cyan-500"
              />
              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsManualPasteOpen(false)}
                  className="px-3 py-1.5 rounded-lg text-xs text-slate-600 hover:bg-slate-100"
                >
                  Kembali ke Foto
                </button>
                <button
                  type="button"
                  onClick={handleManualTextSubmit}
                  className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold"
                >
                  Salin ke Form
                </button>
              </div>
            </div>
          )}

          {/* Toggle Tempel Teks */}
          {!isProcessing && !isManualPasteOpen && (
            <div className="text-center">
              <button
                type="button"
                onClick={() => setIsManualPasteOpen(true)}
                className="text-xs text-cyan-600 hover:text-cyan-700 font-semibold flex items-center justify-center gap-1.5 mx-auto"
              >
                <ClipboardPaste className="w-3.5 h-3.5" />
                <span>Atau Tempel Teks Transaksi / SMS di sini</span>
              </button>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
          <span className="text-[11px] text-slate-500">
            Mendukung Token PLN, Pulsa, IndiHome, dan Struk Toko
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg text-xs font-semibold text-slate-600 hover:bg-slate-200 transition-colors"
          >
            Tutup
          </button>
        </div>

      </div>
    </div>
  );
};
