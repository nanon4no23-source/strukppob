import React, { useState, useMemo } from 'react';
import { 
  History, 
  Search, 
  X, 
  Trash2, 
  ArrowRight, 
  Zap, 
  Phone, 
  Wifi, 
  Wallet, 
  FileText, 
  Clock, 
  Calendar,
  AlertTriangle,
  RotateCcw
} from 'lucide-react';
import { ReceiptData, ReceiptHistoryItem, ProductCategory } from '../types';

interface ReceiptHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  history: ReceiptHistoryItem[];
  onSelectReceipt: (data: ReceiptData) => void;
  onDeleteReceipt: (id: string) => void;
  onClearAllHistory: () => void;
}

export const ReceiptHistoryModal: React.FC<ReceiptHistoryModalProps> = ({
  isOpen,
  onClose,
  history,
  onSelectReceipt,
  onDeleteReceipt,
  onClearAllHistory,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [confirmClearAll, setConfirmClearAll] = useState(false);

  // Filter history based on search & category
  const filteredHistory = useMemo(() => {
    return history.filter((item) => {
      const q = searchQuery.toLowerCase().trim();
      const matchCategory = selectedCategory === 'all' || item.data.category === selectedCategory;

      if (!matchCategory) return false;
      if (!q) return true;

      const searchableText = [
        item.summary.productName,
        item.summary.title,
        item.summary.customerOrMeter,
        item.summary.tokenListrik,
        item.summary.totalBayar,
        item.summary.date,
        item.data.meterNumber,
        item.data.idpel,
        item.data.customerName,
        item.data.destinationNumber,
        item.data.serialNumber,
      ]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();

      return searchableText.includes(q);
    });
  }, [history, searchQuery, selectedCategory]);

  if (!isOpen) return null;

  const getCategoryIcon = (category: ProductCategory) => {
    switch (category) {
      case 'token_listrik':
        return <Zap className="w-4 h-4 text-amber-600" />;
      case 'tagihan_listrik':
        return <Zap className="w-4 h-4 text-blue-600" />;
      case 'pulsa':
        return <Phone className="w-4 h-4 text-indigo-600" />;
      case 'tagihan_wifi':
        return <Wifi className="w-4 h-4 text-teal-600" />;
      case 'topup_ewallet':
        return <Wallet className="w-4 h-4 text-purple-600" />;
      default:
        return <FileText className="w-4 h-4 text-slate-600" />;
    }
  };

  const getCategoryBadgeClass = (category: ProductCategory) => {
    switch (category) {
      case 'token_listrik':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'tagihan_listrik':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'pulsa':
        return 'bg-indigo-100 text-indigo-800 border-indigo-200';
      case 'tagihan_wifi':
        return 'bg-teal-100 text-teal-800 border-teal-200';
      case 'topup_ewallet':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  const getCategoryLabel = (category: ProductCategory) => {
    switch (category) {
      case 'token_listrik':
        return 'Token Listrik PLN';
      case 'tagihan_listrik':
        return 'Tagihan Listrik PLN';
      case 'pulsa':
        return 'Pulsa / Paket Data';
      case 'tagihan_wifi':
        return 'Tagihan WiFi / Telkom';
      case 'topup_ewallet':
        return 'Top Up E-Wallet';
      default:
        return 'Struk Kasir';
    }
  };

  const formatTimestamp = (ts: number) => {
    try {
      const d = new Date(ts);
      return d.toLocaleDateString('id-ID', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return '';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="w-full max-w-2xl bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-emerald-100 text-emerald-700 border border-emerald-200">
              <History className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900">Riwayat Edit Struk</h3>
                <span className="px-2 py-0.5 text-[11px] font-bold rounded-full bg-slate-200 text-slate-700">
                  {history.length} struk tersimpan
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Pilih struk terdahulu untuk langsung diedit ulang atau dicetak kembali
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter & Search Bar */}
        <div className="px-6 py-3 border-b border-slate-100 bg-white space-y-2.5">
          {/* Search box */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari nama pelanggan, nomor meter, token, atau tanggal..."
              className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:bg-white focus:outline-hidden focus:border-emerald-500 transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs"
              >
                ✕
              </button>
            )}
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-3 py-1 rounded-lg font-medium whitespace-nowrap transition-colors ${
                selectedCategory === 'all'
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Semua ({history.length})
            </button>
            <button
              onClick={() => setSelectedCategory('token_listrik')}
              className={`px-3 py-1 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-1 ${
                selectedCategory === 'token_listrik'
                  ? 'bg-amber-600 text-white'
                  : 'bg-amber-50 text-amber-700 hover:bg-amber-100 border border-amber-200/50'
              }`}
            >
              <Zap className="w-3 h-3" /> Token Listrik
            </button>
            <button
              onClick={() => setSelectedCategory('pulsa')}
              className={`px-3 py-1 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-1 ${
                selectedCategory === 'pulsa'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100 border border-indigo-200/50'
              }`}
            >
              <Phone className="w-3 h-3" /> Pulsa
            </button>
            <button
              onClick={() => setSelectedCategory('tagihan_wifi')}
              className={`px-3 py-1 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-1 ${
                selectedCategory === 'tagihan_wifi'
                  ? 'bg-teal-600 text-white'
                  : 'bg-teal-50 text-teal-700 hover:bg-teal-100 border border-teal-200/50'
              }`}
            >
              <Wifi className="w-3 h-3" /> WiFi
            </button>
            <button
              onClick={() => setSelectedCategory('tagihan_listrik')}
              className={`px-3 py-1 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-1 ${
                selectedCategory === 'tagihan_listrik'
                  ? 'bg-blue-600 text-white'
                  : 'bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200/50'
              }`}
            >
              <Zap className="w-3 h-3" /> Tagihan PLN
            </button>
            <button
              onClick={() => setSelectedCategory('topup_ewallet')}
              className={`px-3 py-1 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-1 ${
                selectedCategory === 'topup_ewallet'
                  ? 'bg-purple-600 text-white'
                  : 'bg-purple-50 text-purple-700 hover:bg-purple-100 border border-purple-200/50'
              }`}
            >
              <Wallet className="w-3 h-3" /> E-Wallet
            </button>
          </div>
        </div>

        {/* History List */}
        <div className="p-6 overflow-y-auto flex-1 space-y-3 bg-slate-50/50">
          {filteredHistory.length === 0 ? (
            <div className="py-12 px-4 text-center flex flex-col items-center justify-center">
              <div className="p-4 rounded-full bg-slate-100 text-slate-400 mb-3">
                <History className="w-8 h-8 stroke-1" />
              </div>
              <p className="text-sm font-bold text-slate-800">
                {searchQuery ? 'Tidak ada riwayat yang cocok dengan pencarian' : 'Belum Ada Riwayat Struk Tersimpan'}
              </p>
              <p className="text-xs text-slate-500 max-w-sm mt-1">
                {searchQuery
                  ? 'Coba gunakan kata kunci lain seperti nama pelanggan, nomor meter, atau tanggal.'
                  : 'Setiap struk yang Anda edit, cetak Bluetooth, atau ekspor ke PDF/PNG akan otomatis disimpan di sini agar bisa diedit ulang kapan saja.'}
              </p>
            </div>
          ) : (
            filteredHistory.map((item) => (
              <div
                key={item.id}
                className="p-4 rounded-xl bg-white border border-slate-200 hover:border-emerald-500 hover:shadow-md transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 group"
              >
                {/* Info block */}
                <div className="space-y-1.5 flex-1 min-w-0">
                  {/* Tags row */}
                  <div className="flex flex-wrap items-center gap-2">
                    <span
                      className={`px-2 py-0.5 rounded-md text-[11px] font-semibold border flex items-center gap-1 ${getCategoryBadgeClass(
                        item.data.category
                      )}`}
                    >
                      {getCategoryIcon(item.data.category)}
                      <span>{getCategoryLabel(item.data.category)}</span>
                    </span>

                    <span className="text-[11px] text-slate-400 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {formatTimestamp(item.timestamp)}
                    </span>

                    <span className="text-[10px] px-1.5 py-0.5 rounded-sm bg-slate-100 text-slate-600 font-mono">
                      {item.data.paperPreset} • {item.data.layoutStyle.replace(/_/g, ' ')}
                    </span>
                  </div>

                  {/* Title & Product */}
                  <div className="flex items-baseline gap-2">
                    <h4 className="text-sm font-bold text-slate-900 truncate">
                      {item.summary.productName}
                    </h4>
                    {item.summary.customerOrMeter && (
                      <span className="text-xs font-medium text-slate-600 truncate">
                        • {item.summary.customerOrMeter}
                      </span>
                    )}
                  </div>

                  {/* Token Listrik or Key identifiers */}
                  {item.summary.tokenListrik && (
                    <div className="text-xs font-mono font-bold text-amber-700 bg-amber-50/80 px-2 py-1 rounded-md border border-amber-200/60 inline-flex items-center gap-1.5">
                      <Zap className="w-3 h-3 text-amber-600" />
                      <span>Token: {item.summary.tokenListrik}</span>
                    </div>
                  )}

                  {/* Date/Time from receipt if different */}
                  <div className="text-[11px] text-slate-500 flex items-center gap-3">
                    {item.data.transactionDate && (
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-slate-400" />
                        Tgl Struk: {item.data.transactionDate} {item.data.transactionTime}
                      </span>
                    )}
                    {item.data.storeHeader?.storeName && (
                      <span className="truncate">Toko: {item.data.storeHeader.storeName}</span>
                    )}
                  </div>
                </div>

                {/* Total & Action Buttons */}
                <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                  <div className="text-left sm:text-right">
                    <span className="block text-[10px] font-medium text-slate-400 uppercase tracking-wider">
                      Total Bayar
                    </span>
                    <span className="text-base font-extrabold text-emerald-600">
                      {item.summary.totalBayar}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {/* Delete button */}
                    <button
                      type="button"
                      onClick={() => onDeleteReceipt(item.id)}
                      className="p-2 rounded-xl text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                      title="Hapus dari riwayat"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>

                    {/* Edit Ulang button */}
                    <button
                      type="button"
                      onClick={() => {
                        onSelectReceipt(item.data);
                        onClose();
                      }}
                      className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-sm active:scale-95"
                      title="Muat struk ini ke formulir untuk diedit ulang"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Edit Ulang</span>
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs">
          {history.length > 0 ? (
            confirmClearAll ? (
              <div className="flex items-center gap-2">
                <span className="text-red-600 font-semibold flex items-center gap-1 text-[11px]">
                  <AlertTriangle className="w-3.5 h-3.5" /> Yakin hapus semua?
                </span>
                <button
                  type="button"
                  onClick={() => {
                    onClearAllHistory();
                    setConfirmClearAll(false);
                  }}
                  className="px-2.5 py-1 rounded-lg bg-red-600 text-white font-bold text-[11px] hover:bg-red-700"
                >
                  Ya, Hapus Semua
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmClearAll(false)}
                  className="px-2 py-1 rounded-lg bg-slate-200 text-slate-700 text-[11px]"
                >
                  Batal
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmClearAll(true)}
                className="text-slate-400 hover:text-red-600 transition-colors flex items-center gap-1 font-medium"
              >
                <Trash2 className="w-3.5 h-3.5" /> Hapus Semua Riwayat
              </button>
            )
          ) : (
            <span className="text-slate-400">Riwayat tersimpan otomatis di perangkat</span>
          )}

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold transition-colors"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
