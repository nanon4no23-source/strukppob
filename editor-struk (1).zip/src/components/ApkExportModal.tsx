import React, { useState } from 'react';
import { 
  X, 
  Download, 
  Copy, 
  Check, 
  Smartphone, 
  Github, 
  FileCode2, 
  Sparkles, 
  CheckCircle2, 
  Package, 
  ExternalLink,
  ShieldCheck,
  ChevronRight,
  Loader2
} from 'lucide-react';
import { downloadProjectZip } from '../utils/downloadZip';

interface ApkExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GITHUB_WORKFLOW_YAML = `name: Build Android APK (Editor Struk)

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build-apk:
    name: Build Android APK
    runs-on: ubuntu-latest

    steps:
      - name: Checkout Repository
        uses: actions/checkout@v4

      - name: Locate & Prepare Project Files
        run: |
          echo "Memeriksa direktori berkas proyek..."
          ls -la

          # Jika pengguna mengunggah berkas zip langsung ke GitHub, ekstrak otomatis
          ZIP_FILE=$(find . -maxdepth 2 -name "*.zip" | head -n 1)
          if [ -n "$ZIP_FILE" ]; then
            echo "Ditemukan berkas ZIP: $ZIP_FILE. Mengekstrak otomatis..."
            unzip -o "$ZIP_FILE"
          fi

          # Cari letak package.json
          PKG_PATH=$(find . -maxdepth 3 -name "package.json" -not -path "*/node_modules/*" | head -n 1)
          if [ -z "$PKG_PATH" ]; then
            echo "::error::File package.json tidak ditemukan! Pastikan file ZIP atau file proyek ada di repo ini."
            exit 1
          fi
          PROJECT_DIR=$(dirname "$PKG_PATH")
          echo "Proyek terdeteksi di direktori: $PROJECT_DIR"
          if [ "$PROJECT_DIR" != "." ]; then
            echo "Memindahkan berkas dari $PROJECT_DIR ke direktori utama..."
            shopt -s dotglob
            cp -r "$PROJECT_DIR"/* .
            shopt -u dotglob
          fi

          echo "Daftar berkas setelah disiapkan:"
          ls -la

      - name: Set up Node.js
        uses: actions/setup-node@v4
        with:
          node-version: 20

      - name: Set up Java JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Install Project Dependencies
        run: |
          npm install --legacy-peer-deps

      - name: Build Web Application
        run: |
          npx vite build

      - name: Setup Capacitor 6 Android
        run: |
          npm install --save-dev --legacy-peer-deps @capacitor/core@^6.1.0 @capacitor/cli@^6.1.0 @capacitor/android@^6.1.0
          npx cap init "Editor Struk" "com.editorstruk.app" --web-dir dist || true
          rm -rf android
          npx cap add android
          npx cap sync android

      - name: Apply Custom App Icons & Branding
        run: |
          echo "Mengaplikasikan logo kustom aplikasi ke Android..."
          chmod +x scripts/generate_android_icons.sh
          ./scripts/generate_android_icons.sh

      - name: Install Android Bluetooth Printer Native Bridge
        run: |
          echo "Memasang Java Bridge Printer Bluetooth..."
          chmod +x scripts/setup_android_bluetooth_bridge.sh
          ./scripts/setup_android_bluetooth_bridge.sh

      - name: Configure Android Version 1.1, SDK, Permissions & Cleartext
        run: |
          echo "sdk.dir=$ANDROID_HOME" > android/local.properties

          node scripts/bump_android_version.cjs

          MANIFEST="android/app/src/main/AndroidManifest.xml"
          if [ -f "$MANIFEST" ]; then
            sed -i '/<manifest/a \\    <uses-permission android:name="android.permission.INTERNET" />\\n    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />\\n    <uses-permission android:name="android.permission.BLUETOOTH" />\\n    <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" />\\n    <uses-permission android:name="android.permission.BLUETOOTH_SCAN" android:usesPermissionFlags="neverForLocation" />\\n    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />\\n    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />\\n    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />' "$MANIFEST"
            sed -i 's/<application/<application android:usesCleartextTraffic="true"/g' "$MANIFEST"
          fi

      - name: Accept Android SDK Licenses
        run: |
          yes | $ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager --licenses || true

      - name: Grant Execute Permission for Gradlew
        run: |
          chmod +x ./android/gradlew

      - name: Build Debug APK
        env:
          GRADLE_OPTS: "-Dorg.gradle.jvmargs=-Xmx2048m -XX:MaxMetaspaceSize=512m -Dorg.gradle.daemon=false"
        run: |
          cd android
          ./gradlew assembleDebug --no-daemon

      - name: Prepare APK Output
        run: |
          mkdir -p output-apk
          APK_FOUND=$(find android/app/build/outputs/apk/debug -name "*.apk" | head -n 1)
          if [ -n "$APK_FOUND" ]; then
            cp "$APK_FOUND" output-apk/Editor-Struk-v1.1.apk
            echo "APK siap di: output-apk/Editor-Struk-v1.1.apk"
          else
            echo "::error::File APK tidak ditemukan di direktori output Gradle!"
            exit 1
          fi

      - name: Upload APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: Editor-Struk-v1.1-APK
          path: output-apk/Editor-Struk-v1.1.apk
          retention-days: 30
`;

export const ApkExportModal: React.FC<ApkExportModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'download' | 'workflow' | 'guide'>('download');
  const [copied, setCopied] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadStatus, setDownloadStatus] = useState<string>('');

  if (!isOpen) return null;

  const handleCopyYaml = () => {
    navigator.clipboard.writeText(GITHUB_WORKFLOW_YAML);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownloadZip = async () => {
    try {
      setIsDownloading(true);
      await downloadProjectZip((msg) => setDownloadStatus(msg));
      setTimeout(() => {
        setIsDownloading(false);
        setDownloadStatus('');
      }, 3000);
    } catch (e) {
      console.error(e);
      setIsDownloading(false);
      setDownloadStatus('Gagal mengunduh');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto no-print">
      <div className="w-full max-w-2xl bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-white">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-red-50 text-red-600 border border-red-200 shadow-2xs">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900">Download ZIP & Workflow APK GitHub</h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                  Siap Bangun APK
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Unduh paket source code lengkap dan salin GitHub Actions YAML untuk generate APK otomatis
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-6 pt-2 gap-2 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('download')}
            className={`pb-2.5 px-3 border-b-2 transition-all flex items-center gap-1.5 ${
              activeTab === 'download'
                ? 'border-red-600 text-red-700 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            Unduh File ZIP Proyek
          </button>

          <button
            onClick={() => setActiveTab('workflow')}
            className={`pb-2.5 px-3 border-b-2 transition-all flex items-center gap-1.5 ${
              activeTab === 'workflow'
                ? 'border-red-600 text-red-700 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <FileCode2 className="w-3.5 h-3.5" />
            Workflow GitHub Actions (.yml)
          </button>

          <button
            onClick={() => setActiveTab('guide')}
            className={`pb-2.5 px-3 border-b-2 transition-all flex items-center gap-1.5 ${
              activeTab === 'guide'
                ? 'border-red-600 text-red-700 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Github className="w-3.5 h-3.5" />
            Cara Buat APK di GitHub
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 overflow-y-auto flex-1 text-sm">
          
          {/* TAB 1: DOWNLOAD ZIP */}
          {activeTab === 'download' && (
            <div className="space-y-4">
              {/* Primary Download Card */}
              <div className="p-5 rounded-2xl bg-gradient-to-br from-red-50 via-rose-50 to-orange-50 border border-red-200/80 shadow-xs">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-3.5">
                    <div className="w-12 h-12 rounded-2xl bg-red-600 text-white flex items-center justify-center shadow-md shadow-red-600/20 shrink-0">
                      <Package className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="text-base font-bold text-slate-900">editor-struk.zip</h4>
                      <p className="text-xs text-slate-600 mt-0.5">
                        Berisi seluruh source code React, Vite, Tailwind, Ikon APK (512x512), dan folder <code className="bg-red-100 text-red-800 px-1 py-0.5 rounded font-mono">.github/workflows/build-apk.yml</code>.
                      </p>
                      <div className="flex items-center gap-2 mt-2">
                        <span className="px-2 py-0.5 rounded-md bg-white border border-red-200 text-[11px] font-semibold text-slate-700">
                          Ukuran: ~1.4 MB
                        </span>
                        <span className="px-2 py-0.5 rounded-md bg-emerald-100 border border-emerald-200 text-[11px] font-semibold text-emerald-800 flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" /> Siap Ekstrak & Build
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 shrink-0 w-full sm:w-auto">
                    <button
                      type="button"
                      onClick={handleDownloadZip}
                      disabled={isDownloading}
                      className="px-5 py-3 rounded-xl bg-red-600 hover:bg-red-500 disabled:bg-red-400 text-white font-bold text-xs shadow-md shadow-red-600/25 flex items-center justify-center gap-2 transition-all active:scale-95 shrink-0"
                    >
                      {isDownloading ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>{downloadStatus || 'Menyiapkan ZIP...'}</span>
                        </>
                      ) : (
                        <>
                          <Download className="w-4 h-4" />
                          <span>Unduh ZIP Sekarang</span>
                        </>
                      )}
                    </button>
                    <a
                      href="/api/download-zip"
                      download="editor-struk.zip"
                      className="px-3 py-3 rounded-xl bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 text-center text-xs font-semibold shadow-2xs transition-colors"
                      title="Link langsung alternatif"
                    >
                      Direct Link
                    </a>
                  </div>
                </div>
              </div>

              {/* Icon Download Secondary Card */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl overflow-hidden border border-slate-300 shrink-0 bg-white">
                    <img src="/app-icon.png" alt="Ikon Editor Struk" className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-slate-900">Ikon Resmi Editor Struk (app-icon.png)</h5>
                    <p className="text-[11px] text-slate-500">Logo launcher aplikasi Android resolusi 512x512 PNG</p>
                  </div>
                </div>

                <a
                  href="/app-icon.png"
                  download="app-icon-editor-struk.png"
                  className="px-3 py-1.5 rounded-lg bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 text-xs font-semibold shadow-2xs transition-colors flex items-center gap-1"
                >
                  <Download className="w-3.5 h-3.5" />
                  Unduh Ikon
                </a>
              </div>

              {/* What's Inside Checklist */}
              <div className="p-4 rounded-xl bg-white border border-slate-200">
                <h5 className="text-xs font-bold text-slate-800 mb-2 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  Kelengkapan Berkas dalam File ZIP:
                </h5>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-xs text-slate-600">
                  <li className="flex items-center gap-2">
                    <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span><code className="font-semibold text-slate-800">.github/workflows/build-apk.yml</code></span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span><code className="font-semibold text-slate-800">capacitor.config.json</code></span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span><code className="font-semibold text-slate-800">public/app-icon.png</code> (512x512)</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span><code className="font-semibold text-slate-800">public/manifest.json</code></span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>Semua komponen React, TypeScript, & Preset Struk</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>Driver Bluetooth Thermal Printer (ESC/POS 58mm/80mm)</span>
                  </li>
                </ul>
              </div>
            </div>
          )}

          {/* TAB 2: WORKFLOW YAML */}
          {activeTab === 'workflow' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <FileCode2 className="w-4 h-4 text-red-600" />
                    Path File: <code className="text-red-700 bg-red-50 px-1.5 py-0.5 rounded font-mono">.github/workflows/build-apk.yml</code>
                  </h4>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Otomatis menjalankan build Android APK di cloud GitHub Actions gratis tanpa install Android Studio di PC.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleCopyYaml}
                  className="px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-500 text-white text-xs font-bold shadow-xs flex items-center gap-1.5 transition-all active:scale-95 shrink-0"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-white" />
                      Tersalin!
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      Salin Kode YAML
                    </>
                  )}
                </button>
              </div>

              {/* Code display */}
              <div className="relative rounded-xl bg-slate-900 text-slate-100 p-4 font-mono text-[11px] overflow-x-auto max-h-[380px]">
                <pre className="text-slate-200">{GITHUB_WORKFLOW_YAML}</pre>
              </div>
            </div>
          )}

          {/* TAB 3: STEP BY STEP GUIDE */}
          {activeTab === 'guide' && (
            <div className="space-y-3.5 text-xs text-slate-700">
              <div className="p-4 rounded-xl bg-blue-50/80 border border-blue-200 text-blue-950 space-y-1">
                <h5 className="font-bold flex items-center gap-1.5 text-sm text-blue-900">
                  <Sparkles className="w-4 h-4 text-blue-600" />
                  Cara Cepat Menghasilkan APK via GitHub (Gratis & Otomatis)
                </h5>
                <p className="text-blue-800 text-xs">
                  Anda tidak perlu install Android Studio atau SDK di laptop. GitHub Actions akan mengompilasi APK untuk Anda di cloud.
                </p>
              </div>

              <div className="space-y-3">
                {/* Step 1 */}
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-red-600 text-white font-bold flex items-center justify-center shrink-0 text-xs mt-0.5">
                    1
                  </div>
                  <div>
                    <h6 className="font-bold text-slate-900">Ekstrak ZIP & Upload ke GitHub Repository Baru</h6>
                    <p className="text-slate-600 mt-1 leading-relaxed">
                      Unduh <code className="bg-slate-200 px-1 py-0.5 rounded text-slate-800">editor-struk.zip</code>, ekstrak isinya di komputer Anda, lalu buat repository baru di GitHub (misalnya <code className="bg-slate-200 px-1 py-0.5 rounded text-slate-800">editor-struk</code>) dan upload/push semua file ke branch <b>main</b>.
                    </p>
                  </div>
                </div>

                {/* Step 2 */}
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-red-600 text-white font-bold flex items-center justify-center shrink-0 text-xs mt-0.5">
                    2
                  </div>
                  <div>
                    <h6 className="font-bold text-slate-900">Periksa File Workflow di Folder .github/workflows/</h6>
                    <p className="text-slate-600 mt-1 leading-relaxed">
                      Pastikan file <code className="bg-slate-200 px-1 py-0.5 rounded text-slate-800">.github/workflows/build-apk.yml</code> sudah ter-upload (file ini sudah otomatis disertakan di dalam ZIP).
                    </p>
                  </div>
                </div>

                {/* Step 3 */}
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-red-600 text-white font-bold flex items-center justify-center shrink-0 text-xs mt-0.5">
                    3
                  </div>
                  <div>
                    <h6 className="font-bold text-slate-900">Buka Tab "Actions" & Unduh File APK</h6>
                    <p className="text-slate-600 mt-1 leading-relaxed">
                      Di halaman repository GitHub Anda, klik tab <b>Actions</b> di atas. Anda akan melihat workflow <b>"Build Android APK (Editor Struk)"</b> berjalan otomatis.
                      <br />
                      Tunggu sekitar 2–3 menit hingga centang hijau muncul. Klik proses tersebut, lalu di bagian bawah pada judul <b>Artifacts</b>, klik <b>Editor-Struk-APK</b> untuk mengunduh file APK siap pasang ke HP Anda!
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold border border-slate-300 shadow-2xs transition-colors"
          >
            Tutup
          </button>

          <button
            type="button"
            onClick={handleDownloadZip}
            disabled={isDownloading}
            className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 disabled:bg-red-400 text-white text-xs font-bold shadow-xs flex items-center gap-1.5 transition-all active:scale-95"
          >
            {isDownloading ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>{downloadStatus || 'Menyiapkan...'}</span>
              </>
            ) : (
              <>
                <Download className="w-3.5 h-3.5" />
                <span>Unduh editor-struk.zip (~1.4 MB)</span>
              </>
            )}
          </button>
        </div>

      </div>
    </div>
  );
};
