import { useState, useRef, useEffect } from 'react';
import { 
  Upload, 
  Store, 
  Bluetooth, 
  Printer, 
  Download, 
  Image as ImageIcon, 
  RotateCcw, 
  Eye, 
  Edit3, 
  ZoomIn, 
  ZoomOut, 
  CheckCircle,
  FileText,
  History,
  BookmarkPlus,
  Palette,
  Check,
  Package
} from 'lucide-react';
import { ReceiptData, StoreHeader, ReceiptHistoryItem } from './types';
import { PRESETS, DEFAULT_STORE_HEADER } from './utils/presets';
import { loadHistory, saveToHistory, deleteHistoryItem, clearAllHistory } from './utils/history';
import { ReceiptPreview } from './components/ReceiptPreview';
import { ReceiptEditorForm } from './components/ReceiptEditorForm';
import { HeaderSettingsModal } from './components/HeaderSettingsModal';
import { PhotoUploadModal } from './components/PhotoUploadModal';
import { BluetoothModal } from './components/BluetoothModal';
import { ReceiptHistoryModal } from './components/ReceiptHistoryModal';
import { ApkExportModal } from './components/ApkExportModal';
import { bluetoothPrinterService } from './utils/bluetoothPrinter';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

export type BgTheme = 'red_vibrant' | 'red_maroon' | 'red_ruby' | 'red_soft' | 'slate';

interface ThemeConfig {
  name: string;
  badge: string;
  dotColor: string;
  containerClass: string;
  deskClass: string;
  headerBorder: string;
}

export const BG_THEMES: Record<BgTheme, ThemeConfig> = {
  red_vibrant: {
    name: 'Merah Terang',
    badge: 'Merah',
    dotColor: '#dc2626',
    containerClass: 'bg-gradient-to-br from-red-600 via-red-700 to-rose-900',
    deskClass: 'bg-black/35 border border-white/20 shadow-2xl backdrop-blur-xs',
    headerBorder: 'border-red-200/50',
  },
  red_maroon: {
    name: 'Merah Marun (Crimson)',
    badge: 'Marun',
    dotColor: '#881337',
    containerClass: 'bg-gradient-to-br from-rose-950 via-red-950 to-neutral-950',
    deskClass: 'bg-black/45 border border-white/15 shadow-2xl backdrop-blur-xs',
    headerBorder: 'border-rose-900/50',
  },
  red_ruby: {
    name: 'Merah Ruby Solid',
    badge: 'Ruby',
    dotColor: '#991b1b',
    containerClass: 'bg-[#991b1b]',
    deskClass: 'bg-black/35 border border-white/20 shadow-2xl backdrop-blur-xs',
    headerBorder: 'border-red-800/50',
  },
  red_soft: {
    name: 'Merah Lembut (Pastel)',
    badge: 'Soft',
    dotColor: '#f87171',
    containerClass: 'bg-gradient-to-br from-red-50 via-rose-50 to-orange-50',
    deskClass: 'bg-red-100/70 border border-red-200/80 shadow-inner',
    headerBorder: 'border-red-200',
  },
  slate: {
    name: 'Abu-abu (Netral Asli)',
    badge: 'Netral',
    dotColor: '#94a3b8',
    containerClass: 'bg-slate-100',
    deskClass: 'bg-slate-200/80 border border-slate-300/80 shadow-inner',
    headerBorder: 'border-slate-200',
  },
};

const SAVED_HEADER_KEY = 'struk_ppob_saved_store_header';

export default function App() {
  const [receiptData, setReceiptData] = useState<ReceiptData>(PRESETS.token_listrik_bukalapak);
  const [isInlineEditable, setIsInlineEditable] = useState(false);
  const [scale, setScale] = useState(1);
  const [activeTab, setActiveTab] = useState<'editor' | 'preview'>('editor');
  
  // Modals
  const [isHeaderModalOpen, setIsHeaderModalOpen] = useState(false);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [isBluetoothModalOpen, setIsBluetoothModalOpen] = useState(false);
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);
  
  // History State
  const [history, setHistory] = useState<ReceiptHistoryItem[]>(() => loadHistory());

  // Notification Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isExporting, setIsExporting] = useState(false);

  // Background Theme State (Default: red_vibrant as requested!)
  const [bgTheme, setBgTheme] = useState<BgTheme>(() => {
    try {
      const saved = localStorage.getItem('struk_app_bg_theme');
      if (saved && saved in BG_THEMES) return saved as BgTheme;
    } catch {}
    return 'red_vibrant';
  });
  const [isThemeMenuOpen, setIsThemeMenuOpen] = useState(false);
  const themeMenuRef = useRef<HTMLDivElement>(null);

  const previewRef = useRef<HTMLDivElement>(null);

  // Close theme menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (themeMenuRef.current && !themeMenuRef.current.contains(e.target as Node)) {
        setIsThemeMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelectBgTheme = (themeKey: BgTheme) => {
    setBgTheme(themeKey);
    try {
      localStorage.setItem('struk_app_bg_theme', themeKey);
    } catch {}
    setIsThemeMenuOpen(false);
    showToast(`Background diubah ke: ${BG_THEMES[themeKey].name}`);
  };

  // Load saved store header on first mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem(SAVED_HEADER_KEY);
      if (saved) {
        const parsedHeader: StoreHeader = JSON.parse(saved);
        setReceiptData((prev) => ({
          ...prev,
          storeHeader: parsedHeader,
        }));
      }
    } catch (e) {
      console.error('Failed to load saved header:', e);
    }

    // Global image paste handler
    const handleGlobalPaste = (e: ClipboardEvent) => {
      const activeElement = document.activeElement;
      if (activeElement && (activeElement.tagName === 'INPUT' || activeElement.tagName === 'TEXTAREA')) {
        return;
      }
      const items = e.clipboardData?.items;
      if (!items) return;
      for (let i = 0; i < items.length; i++) {
        if (items[i].type.startsWith('image/')) {
          setIsUploadModalOpen(true);
          break;
        }
      }
    };
    window.addEventListener('paste', handleGlobalPaste);
    return () => window.removeEventListener('paste', handleGlobalPaste);
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  // Save current receipt to history
  const handleSaveToHistory = (silentMsg?: string) => {
    const updated = saveToHistory(receiptData);
    setHistory(updated);
    showToast(silentMsg || 'Struk tersimpan di riwayat! Siap diedit ulang kapan saja.');
  };

  // Load receipt from history to edit again
  const handleSelectFromHistory = (selectedData: ReceiptData) => {
    setReceiptData(selectedData);
    showToast(`Struk ${selectedData.productName} dimuat untuk diedit ulang!`);
  };

  // Delete item from history
  const handleDeleteFromHistory = (id: string) => {
    const updated = deleteHistoryItem(id);
    setHistory(updated);
    showToast('Item riwayat berhasil dihapus');
  };

  // Clear all history
  const handleClearAllHistory = () => {
    clearAllHistory();
    setHistory([]);
    showToast('Seluruh riwayat struk telah dibersihkan');
  };

  // Preset selector
  const handleSelectPreset = (presetKey: string) => {
    const preset = PRESETS[presetKey];
    if (!preset) return;

    // Retain currently saved store header if exists
    let headerToKeep = receiptData.storeHeader;
    try {
      const saved = localStorage.getItem(SAVED_HEADER_KEY);
      if (saved) {
        headerToKeep = JSON.parse(saved);
      }
    } catch {
      // fallback
    }

    setReceiptData({
      ...preset,
      storeHeader: headerToKeep || preset.storeHeader,
    });
    showToast(`Preset ${preset.productName} dimuat`);
  };

  // Header update from modal
  const handleSaveHeader = (newHeader: StoreHeader) => {
    setReceiptData((prev) => ({
      ...prev,
      storeHeader: newHeader,
    }));
    showToast('Header toko berhasil diperbarui & disimpan');
  };

  // Extracted data from Photo OCR
  const handleApplyExtractedData = (extracted: Partial<ReceiptData>, presetKeyHint?: string) => {
    // 1. Identify category & preset
    const isTokenListrik =
      extracted.category === 'token_listrik' ||
      Boolean(extracted.tokenListrik && extracted.tokenListrik.trim().length > 0) ||
      /token|stroom|prabayar/i.test(extracted.productName || '') ||
      /token|stroom|prabayar/i.test(extracted.receiptTitle || '');

    const isWifi =
      extracted.category === 'tagihan_wifi' ||
      /wifi|indihome|telkom/i.test(extracted.productName || '') ||
      /telkom/i.test(extracted.receiptTitle || '');

    const isTagihanListrik =
      extracted.category === 'tagihan_listrik' ||
      (!isTokenListrik && (/tagihan listrik|pln pasca/i.test(extracted.productName || '') || Boolean(extracted.standMeter)));

    const isEwallet =
      extracted.category === 'topup_ewallet' ||
      /dana|gopay|ovo|shopee|wallet/i.test(extracted.productName || '');

    const isPulsa =
      extracted.category === 'pulsa' ||
      /pulsa|kuota|data|telkomsel|indosat|xl|tri|smartfren/i.test(extracted.productName || '');

    // 2. Select matching base preset template
    let targetPresetKey = presetKeyHint;
    if (!targetPresetKey || !PRESETS[targetPresetKey]) {
      if (isTokenListrik) {
        targetPresetKey =
          extracted.layoutStyle === 'thermal_minimarket' || extracted.layoutStyle === 'thermal_classic'
            ? 'token_listrik_thermal'
            : 'token_listrik_bukalapak';
      } else if (isWifi) {
        targetPresetKey = 'tagihan_wifi_indihome';
      } else if (isTagihanListrik) {
        targetPresetKey = 'tagihan_listrik_bukalapak';
      } else if (isEwallet) {
        targetPresetKey = 'topup_ewallet_dana';
      } else if (isPulsa) {
        targetPresetKey = /data|kuota|freedom/i.test(extracted.productName || '')
          ? 'paket_data_indosat'
          : 'pulsa_telkomsel';
      } else {
        targetPresetKey = 'token_listrik_bukalapak';
      }
    }

    const basePreset = PRESETS[targetPresetKey] || PRESETS.token_listrik_bukalapak;

    // Retain currently saved store header if exists, or use store header found in the photo
    let storeHeaderToUse = basePreset.storeHeader;
    try {
      const saved = localStorage.getItem(SAVED_HEADER_KEY);
      if (saved) {
        storeHeaderToUse = JSON.parse(saved);
      }
    } catch {}

    if (extracted.storeHeader?.storeName && extracted.storeHeader.storeName.trim() !== '') {
      storeHeaderToUse = {
        ...storeHeaderToUse,
        storeName: extracted.storeHeader.storeName,
        storeAddress: extracted.storeHeader.storeAddress || storeHeaderToUse.storeAddress,
        storeNpwp: extracted.storeHeader.storeNpwp || storeHeaderToUse.storeNpwp,
        storeContact: extracted.storeHeader.storeContact || storeHeaderToUse.storeContact,
        headerNote: extracted.storeHeader.headerNote || storeHeaderToUse.headerNote,
      };
    }

    // Cleanly construct new receipt state
    const newReceiptData: ReceiptData = {
      ...basePreset,
      ...extracted,
      storeHeader: storeHeaderToUse,
      category: isTokenListrik ? 'token_listrik' : (extracted.category || basePreset.category),
    };

    // If token listrik, ensure no phone number remnant is shown and all token fields are cleanly populated
    if (isTokenListrik) {
      delete (newReceiptData as any).destinationNumber;
      if (!newReceiptData.tokenListrik && extracted.tokenListrik) {
        newReceiptData.tokenListrik = extracted.tokenListrik;
      }
      if (extracted.meterNumber) newReceiptData.meterNumber = extracted.meterNumber;
      if (extracted.idpel) newReceiptData.idpel = extracted.idpel;
      if (extracted.tarifDaya) newReceiptData.tarifDaya = extracted.tarifDaya;
      if (extracted.kwh) newReceiptData.kwh = extracted.kwh;
    }

    setReceiptData(newReceiptData);

    // Auto save extracted receipt to history so user can revisit anytime
    const updatedHistory = saveToHistory(newReceiptData);
    setHistory(updatedHistory);

    const categoryLabel = isTokenListrik 
      ? 'Token Listrik PLN' 
      : isWifi 
      ? 'Tagihan WiFi / IndiHome' 
      : isTagihanListrik 
      ? 'Tagihan PLN Pascabayar' 
      : isEwallet 
      ? 'Top Up E-Wallet' 
      : 'Pulsa / Paket Data';

    showToast(`⚡ Foto berhasil dianalisis! Form disalin otomatis ke preset ${categoryLabel} & disimpan ke riwayat`);
  };

  // Update single field (for inline editing)
  const handleUpdateField = (field: keyof ReceiptData, value: any) => {
    setReceiptData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  // Export as high-res PNG
  const handleExportPNG = async () => {
    if (!previewRef.current) return;
    setIsExporting(true);
    try {
      const canvas = await html2canvas(previewRef.current, {
        scale: 3,
        useCORS: true,
        backgroundColor: '#ffffff',
        logging: false,
      });
      const dataUrl = canvas.toDataURL('image/png');
      const link = document.createElement('a');
      const filename = `Struk-${receiptData.productName.replace(/[^a-zA-Z0-9]/g, '_')}-${Date.now()}.png`;
      link.download = filename;
      link.href = dataUrl;
      link.click();
      
      // Auto save to history
      handleSaveToHistory('Gambar struk (PNG) disimpan & dicatat di riwayat!');
    } catch (err) {
      console.error('Export PNG failed:', err);
      showToast('Gagal menyimpan gambar');
    } finally {
      setIsExporting(false);
    }
  };

  // Export as PDF
  const handleExportPDF = async () => {
    if (!previewRef.current) return;
    setIsExporting(true);
    try {
      const canvas = await html2canvas(previewRef.current, {
        scale: 3,
        useCORS: true,
        backgroundColor: '#ffffff',
        logging: false,
      });
      const imgData = canvas.toDataURL('image/png');
      const imgWidthMm = receiptData.paperPreset === '80mm' ? 80 : 58;
      const imgHeightMm = (canvas.height * imgWidthMm) / canvas.width;

      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: [imgWidthMm, imgHeightMm + 4],
      });

      pdf.addImage(imgData, 'PNG', 0, 2, imgWidthMm, imgHeightMm);
      const filename = `Struk-${receiptData.productName.replace(/[^a-zA-Z0-9]/g, '_')}.pdf`;
      pdf.save(filename);

      // Auto save to history
      handleSaveToHistory('Struk PDF berhasil diunduh & dicatat di riwayat!');
    } catch (err) {
      console.error('Export PDF failed:', err);
      showToast('Gagal membuat PDF');
    } finally {
      setIsExporting(false);
    }
  };

  // Direct browser print dialog
  const handleBrowserPrint = () => {
    handleSaveToHistory('Struk dikirim ke cetak & dicatat di riwayat');
    window.print();
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 flex flex-col font-sans">
      {/* 1. TOP NAVIGATION HEADER (LIGHT THEME) */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 px-4 sm:px-6 py-3 shadow-xs no-print">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          {/* Logo & Name */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl overflow-hidden shadow-xs border border-emerald-500/30 flex items-center justify-center bg-emerald-600">
              <img 
                src="/app-icon.png" 
                alt="Editor Struk Logo" 
                className="w-full h-full object-cover" 
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-bold text-slate-900 tracking-tight">Editor Struk</h1>
                <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                  Thermal & Digital
                </span>
              </div>
              <p className="text-xs text-slate-500 hidden sm:block">
                Editor & Cetak Struk PPOB, Token PLN, Pulsa, & Bluetooth HP
              </p>
            </div>
          </div>

          {/* Action Tools */}
          <div className="flex items-center flex-wrap gap-2">
            {/* Scan / Upload Foto Button */}
            <button
              onClick={() => setIsUploadModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition-all shadow-xs active:scale-95"
              title="Unggah foto atau screenshot untuk diduplikasi persis"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Upload Foto</span>
            </button>

            {/* Riwayat Edit Struk (NEW!) */}
            <button
              onClick={() => setIsHistoryModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold border border-slate-300 shadow-xs transition-all active:scale-95"
              title="Buka daftar riwayat struk untuk diedit ulang"
            >
              <History className="w-3.5 h-3.5 text-indigo-600" />
              <span>Riwayat</span>
              {history.length > 0 && (
                <span className="px-1.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800 text-[10px] font-bold">
                  {history.length}
                </span>
              )}
            </button>

            {/* Header Toko Setting */}
            <button
              onClick={() => setIsHeaderModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold border border-slate-300 shadow-xs transition-all active:scale-95"
              title="Edit & simpan nama toko, alamat, dan kontak"
            >
              <Store className="w-3.5 h-3.5 text-emerald-600" />
              <span className="hidden md:inline">Header Toko</span>
            </button>

            {/* Printer Bluetooth */}
            <button
              onClick={() => setIsBluetoothModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border shadow-xs transition-all active:scale-95 bg-white hover:bg-slate-50 text-slate-700 border-slate-300"
              title="Penyandingan Printer Bluetooth HP & Mode APK"
            >
              <Bluetooth className="w-3.5 h-3.5 text-blue-600" />
              <span className="hidden md:inline">
                Printer HP (APK)
              </span>
            </button>

            {/* Download ZIP & Buat APK Button (NEW!) */}
            <button
              onClick={() => setIsApkModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold border shadow-xs transition-all active:scale-95 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white border-red-700"
              title="Unduh file ZIP proyek dan salin workflow GitHub Actions untuk build APK"
            >
              <Package className="w-3.5 h-3.5" />
              <span>Unduh ZIP & APK</span>
            </button>

            {/* Print & Export Buttons */}
            <div className="flex items-center gap-1 border-l border-slate-200 pl-2">
              <button
                onClick={handleBrowserPrint}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 text-xs font-semibold transition-colors shadow-xs"
                title="Cetak via dialog browser / Printer USB"
              >
                <Printer className="w-3.5 h-3.5 text-amber-600" />
                <span className="hidden sm:inline">Print</span>
              </button>

              <button
                onClick={handleExportPDF}
                disabled={isExporting}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition-colors shadow-xs disabled:opacity-50"
                title="Simpan sebagai file PDF"
              >
                <Download className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">PDF</span>
              </button>

              <button
                onClick={handleExportPNG}
                disabled={isExporting}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold transition-colors shadow-xs disabled:opacity-50"
                title="Simpan sebagai gambar PNG (siap kirim WA)"
              >
                <ImageIcon className="w-3.5 h-3.5 text-cyan-300" />
                <span className="hidden sm:inline">Gambar</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Tab Switcher */}
      <div className="lg:hidden flex border-b border-slate-200 bg-white shadow-xs no-print">
        <button
          onClick={() => setActiveTab('editor')}
          className={`flex-1 py-2.5 text-xs font-bold text-center border-b-2 transition-colors ${
            activeTab === 'editor'
              ? 'border-emerald-600 text-emerald-700 bg-emerald-50/50'
              : 'border-transparent text-slate-500'
          }`}
        >
          Form Editor
        </button>
        <button
          onClick={() => setActiveTab('preview')}
          className={`flex-1 py-2.5 text-xs font-bold text-center border-b-2 transition-colors ${
            activeTab === 'preview'
              ? 'border-emerald-600 text-emerald-700 bg-emerald-50/50'
              : 'border-transparent text-slate-500'
          }`}
        >
          Lihat Struk (Preview)
        </button>
      </div>

      {/* 2. MAIN WORKSPACE (LIGHT THEME) */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* LEFT COLUMN: FORM CONTROLS & GENERATOR (7 Cols) */}
        <section
          className={`lg:col-span-7 space-y-6 no-print ${
            activeTab === 'editor' ? 'block' : 'hidden lg:block'
          }`}
        >
          <ReceiptEditorForm
            data={receiptData}
            onChange={setReceiptData}
            onOpenHeaderModal={() => setIsHeaderModalOpen(true)}
            onSelectPreset={handleSelectPreset}
          />
        </section>

        {/* RIGHT COLUMN: INTERACTIVE RECEIPT PREVIEW (5 Cols) */}
        <section
          className={`lg:col-span-5 flex flex-col items-center ${
            activeTab === 'preview' ? 'block' : 'hidden lg:flex'
          }`}
        >
          {/* Sticky Container on Desktop */}
          <div className="sticky top-20 w-full flex flex-col items-center space-y-4">
            {/* Preview Toolbar */}
            <div className="w-full flex items-center justify-between px-4 py-2.5 rounded-2xl bg-white border border-slate-200 shadow-xs no-print text-xs text-slate-600">
              <div className="flex items-center gap-2">
                <span className="flex items-center gap-1 font-bold text-slate-800">
                  <Eye className="w-3.5 h-3.5 text-emerald-600" />
                  Pratinjau Hasil
                </span>
                <span className="text-[11px] text-slate-400">
                  ({receiptData.layoutStyle === 'digital_mitra' ? 'Digital Bukalapak' : `Kertas ${receiptData.paperPreset}`})
                </span>
              </div>

              <div className="flex items-center gap-2">
                {/* Inline edit toggle */}
                <button
                  type="button"
                  onClick={() => setIsInlineEditable(!isInlineEditable)}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition-colors text-xs font-semibold ${
                    isInlineEditable
                      ? 'bg-amber-100 text-amber-800 border border-amber-300'
                      : 'hover:bg-slate-100 text-slate-600'
                  }`}
                  title="Klik langsung teks di struk untuk mengedit"
                >
                  <Edit3 className="w-3 h-3" />
                  <span>{isInlineEditable ? 'Edit Aktif' : 'Edit di Struk'}</span>
                </button>

                {/* Zoom controls */}
                <div className="flex items-center gap-1 border-l border-slate-200 pl-2">
                  <button
                    onClick={() => setScale((s) => Math.max(0.7, +(s - 0.1).toFixed(1)))}
                    className="p-1 hover:bg-slate-100 rounded text-slate-600 transition-colors"
                    title="Perkecil"
                  >
                    <ZoomOut className="w-3.5 h-3.5" />
                  </button>
                  <span className="text-[10px] w-8 text-center font-mono font-bold text-slate-700">
                    {Math.round(scale * 100)}%
                  </span>
                  <button
                    onClick={() => setScale((s) => Math.min(1.3, +(s + 0.1).toFixed(1)))}
                    className="p-1 hover:bg-slate-100 rounded text-slate-600 transition-colors"
                    title="Perbesar"
                  >
                    <ZoomIn className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setScale(1)}
                    className="p-1 hover:bg-slate-100 rounded text-slate-600 transition-colors"
                    title="Reset Skala"
                  >
                    <RotateCcw className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>

            {/* Receipt Preview Canvas / Desk Box with realistic shadow on light canvas */}
            <div className="w-full flex justify-center py-6 px-4 overflow-x-auto rounded-2xl bg-slate-200/80 border border-slate-300/80 shadow-inner">
              <ReceiptPreview
                ref={previewRef}
                data={receiptData}
                isInlineEditable={isInlineEditable}
                onUpdateField={handleUpdateField}
                scale={scale}
              />
            </div>

            {/* Quick Action Footer below Receipt */}
            <div className="w-full space-y-2 no-print">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <button
                  type="button"
                  onClick={() => handleSaveToHistory()}
                  className="py-2.5 px-3 rounded-xl bg-white hover:bg-indigo-50 text-indigo-700 border border-indigo-200 text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs transition-all active:scale-95"
                  title="Simpan perubahan struk ke riwayat untuk diedit ulang nanti"
                >
                  <BookmarkPlus className="w-4 h-4 text-indigo-600" />
                  <span>Simpan Riwayat</span>
                </button>

                <button
                  onClick={() => setIsBluetoothModalOpen(true)}
                  className="py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs transition-all active:scale-95"
                >
                  <Bluetooth className="w-4 h-4" />
                  <span>Cetak BT</span>
                </button>

                <button
                  onClick={handleExportPDF}
                  disabled={isExporting}
                  className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs transition-all disabled:opacity-50 active:scale-95"
                >
                  <Download className="w-4 h-4" />
                  <span>Unduh PDF</span>
                </button>

                <button
                  onClick={handleExportPNG}
                  disabled={isExporting}
                  className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs transition-all disabled:opacity-50 active:scale-95"
                >
                  <ImageIcon className="w-4 h-4 text-cyan-300" />
                  <span>Simpan Foto</span>
                </button>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* 3. MODALS */}
      <HeaderSettingsModal
        isOpen={isHeaderModalOpen}
        onClose={() => setIsHeaderModalOpen(false)}
        currentHeader={receiptData.storeHeader || DEFAULT_STORE_HEADER}
        onSaveHeader={handleSaveHeader}
      />

      <PhotoUploadModal
        isOpen={isUploadModalOpen}
        onClose={() => setIsUploadModalOpen(false)}
        onApplyExtractedData={handleApplyExtractedData}
      />

      <BluetoothModal
        isOpen={isBluetoothModalOpen}
        onClose={() => setIsBluetoothModalOpen(false)}
        receiptData={receiptData}
      />

      <ReceiptHistoryModal
        isOpen={isHistoryModalOpen}
        onClose={() => setIsHistoryModalOpen(false)}
        history={history}
        onSelectReceipt={handleSelectFromHistory}
        onDeleteReceipt={handleDeleteFromHistory}
        onClearAllHistory={handleClearAllHistory}
      />

      <ApkExportModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />

      {/* 4. FLOATING TOAST NOTIFICATION */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2 px-4 py-3 rounded-xl bg-slate-900 text-white text-xs font-semibold shadow-2xl border border-slate-700 animate-in slide-in-from-bottom-3 duration-200">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
