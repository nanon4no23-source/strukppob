export type LayoutStyle = 'digital_mitra' | 'thermal_classic' | 'thermal_minimarket';
export type PaperPreset = '58mm' | '80mm' | 'digital' | 'a5';
export type ProductCategory = 
  | 'token_listrik' 
  | 'tagihan_listrik' 
  | 'pulsa' 
  | 'tagihan_wifi' 
  | 'topup_ewallet' 
  | 'retail';

export interface StoreHeader {
  storeName: string;
  storeAddress: string;
  storeNpwp: string;
  storeContact: string;
  headerNote?: string;
}

export interface CustomRow {
  id: string;
  label: string;
  value: string;
}

export interface ReceiptData {
  id: string;
  layoutStyle: LayoutStyle;
  paperPreset: PaperPreset;
  category: ProductCategory;
  storeHeader: StoreHeader;
  receiptTitle: string;
  productName: string;
  transactionDate: string;
  transactionTime: string;
  
  // Specific fields
  customerName?: string;
  meterNumber?: string;
  idpel?: string;
  tarifDaya?: string;
  destinationNumber?: string;
  serialNumber?: string;
  referenceNumber?: string;
  transactionId?: string;
  tokenListrik?: string;
  kwh?: string;
  periode?: string;
  standMeter?: string;
  
  // Financials
  tagihan?: string;
  adminFee?: string;
  discount?: string;
  totalBayar: string;
  paymentMethod?: string;
  
  // Notes & Footer
  infoNote?: string;
  footerNote: string;
  
  // Dynamic additional fields
  customRows?: CustomRow[];
}

export interface BluetoothDeviceInfo {
  name: string;
  id: string;
  connected: boolean;
}

export interface ReceiptHistoryItem {
  id: string;
  timestamp: number;
  data: ReceiptData;
  summary: {
    title: string;
    productName: string;
    totalBayar: string;
    category: ProductCategory;
    date: string;
    time: string;
    customerOrMeter?: string;
    tokenListrik?: string;
    layoutStyle: LayoutStyle;
    paperPreset: PaperPreset;
  };
}
