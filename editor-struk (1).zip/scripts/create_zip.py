import os
import zipfile

def make_project_zip():
    output_zip = 'public/editor-struk.zip'
    exclude_dirs = {'node_modules', '.git', 'dist', '__pycache__', '.vite'}
    exclude_files = {'editor-struk.zip', 'editor-struk-source.zip'}

    os.makedirs('public', exist_ok=True)

    with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk('.'):
            dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith('.vite')]
            for file in files:
                if file in exclude_files or file.endswith('.pyc'):
                    continue
                full_path = os.path.join(root, file)
                arc_name = os.path.relpath(full_path, '.')
                if arc_name.startswith('public/editor-struk'):
                    continue
                zipf.write(full_path, arc_name)

    size_kb = os.path.getsize(output_zip) / 1024
    print(f"Project ZIP created at {output_zip} ({size_kb:.1f} KB)")

if __name__ == '__main__':
    make_project_zip()
