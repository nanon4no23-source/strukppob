package com.editorstruk.app;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;

import com.getcapacitor.BridgeActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends BridgeActivity {

    private static final String TAG = "EditorStrukPrinter";
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Minta izin Bluetooth pada runtime jika Android 12 ke atas
        checkAndRequestBluetoothPermissions();

        // Daftarkan JavascriptInterface ke WebView bawaan Capacitor
        try {
            if (this.bridge != null && this.bridge.getWebView() != null) {
                this.bridge.getWebView().addJavascriptInterface(new PrinterBridge(this), "AndroidPrinter");
                Log.d(TAG, "AndroidPrinter JavascriptInterface registered successfully!");
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to register JavascriptInterface: " + e.getMessage());
        }
    }

    private void checkAndRequestBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            List<String> permissionsNeeded = new ArrayList<>();
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(Manifest.permission.BLUETOOTH_CONNECT);
            }
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(Manifest.permission.BLUETOOTH_SCAN);
            }
            if (!permissionsNeeded.isEmpty()) {
                ActivityCompat.requestPermissions(this, permissionsNeeded.toArray(new String[0]), 101);
            }
        }
    }

    public class PrinterBridge {
        private final Context context;

        public PrinterBridge(Context context) {
            this.context = context;
        }

        @JavascriptInterface
        public boolean isApkMode() {
            return true;
        }

        @JavascriptInterface
        public boolean isBluetoothEnabled() {
            try {
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                return adapter != null && adapter.isEnabled();
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public String getBondedDevices() {
            JSONArray list = new JSONArray();
            try {
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter == null) {
                    return list.toString();
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    if (ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                        checkAndRequestBluetoothPermissions();
                        return list.toString();
                    }
                }

                Set<BluetoothDevice> pairedDevices = adapter.getBondedDevices();
                if (pairedDevices != null) {
                    for (BluetoothDevice device : pairedDevices) {
                        JSONObject obj = new JSONObject();
                        String name = device.getName();
                        String address = device.getAddress();
                        obj.put("name", (name != null && !name.isEmpty()) ? name : "Printer Bluetooth");
                        obj.put("address", address != null ? address : "");
                        list.put(obj);
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "Error getting bonded devices: " + e.getMessage());
            }
            return list.toString();
        }

        @JavascriptInterface
        public String printEscPos(String macAddress, String base64Data) {
            BluetoothSocket socket = null;
            OutputStream out = null;
            try {
                if (macAddress == null || macAddress.trim().isEmpty()) {
                    return "{\"success\":false,\"error\":\"Alamat MAC printer belum dipilih\"}";
                }

                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter == null || !adapter.isEnabled()) {
                    return "{\"success\":false,\"error\":\"Bluetooth HP belum aktif. Silakan aktifkan Bluetooth Anda.\"}";
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    if (ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                        return "{\"success\":false,\"error\":\"Izin Bluetooth Connect belum diberikan di HP\"}";
                    }
                }

                byte[] data = Base64.decode(base64Data, Base64.DEFAULT);
                BluetoothDevice device = adapter.getRemoteDevice(macAddress.trim());

                adapter.cancelDiscovery();

                // Coba koneksi RFCOMM SPP
                try {
                    socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                    socket.connect();
                } catch (Exception e1) {
                    Log.w(TAG, "Standard RFCOMM failed, attempting insecure fallback: " + e1.getMessage());
                    try {
                        socket = device.createInsecureRfcommSocketToServiceRecord(SPP_UUID);
                        socket.connect();
                    } catch (Exception e2) {
                        // Fallback via reflection method
                        try {
                            java.lang.reflect.Method m = device.getClass().getMethod("createRfcommSocket", int.class);
                            socket = (BluetoothSocket) m.invoke(device, 1);
                            socket.connect();
                        } catch (Exception e3) {
                            return "{\"success\":false,\"error\":\"Gagal menghubungkan ke printer: " + e2.getMessage() + "\"}";
                        }
                    }
                }

                if (socket != null && socket.isConnected()) {
                    out = socket.getOutputStream();
                    out.write(data);
                    out.flush();
                    try {
                        Thread.sleep(400); // Tunggu sampai buffer tuntas diproses printer
                    } catch (InterruptedException ignored) {}

                    return "{\"success\":true,\"message\":\"Berhasil mencetak ke " + device.getName() + "\"}";
                } else {
                    return "{\"success\":false,\"error\":\"Printer tidak dapat terhubung. Pastikan printer menyala.\"}";
                }

            } catch (Exception e) {
                Log.e(TAG, "Print error: " + e.getMessage());
                return "{\"success\":false,\"error\":\"Error cetak: " + e.getMessage() + "\"}";
            } finally {
                try {
                    if (out != null) out.close();
                } catch (Exception ignored) {}
                try {
                    if (socket != null) socket.close();
                } catch (Exception ignored) {}
            }
        }

        @JavascriptInterface
        public String printImage(String macAddress, String base64Image) {
            try {
                String cleanBase64 = base64Image;
                if (cleanBase64.contains(",")) {
                    cleanBase64 = cleanBase64.substring(cleanBase64.indexOf(",") + 1);
                }
                byte[] decoded = Base64.decode(cleanBase64, Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(decoded, 0, decoded.length);
                if (bitmap == null) {
                    return "{\"success\":false,\"error\":\"Format gambar tidak valid\"}";
                }

                // Ubah bitmap ke perintah ESC/POS Raster bit image (GS v 0)
                byte[] rasterBytes = convertBitmapToEscPos(bitmap);
                return printEscPos(macAddress, Base64.encodeToString(rasterBytes, Base64.NO_WRAP));

            } catch (Exception e) {
                return "{\"success\":false,\"error\":\"Gagal konversi grafis: " + e.getMessage() + "\"}";
            }
        }

        private byte[] convertBitmapToEscPos(Bitmap bitmap) {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            
            // Inisialisasi printer
            baos.write(0x1B);
            baos.write(0x40);

            // Alignment center
            baos.write(0x1B);
            baos.write(0x61);
            baos.write(0x01);

            int width = bitmap.getWidth();
            int height = bitmap.getHeight();
            int widthBytes = (width + 7) / 8;

            // GS v 0 m xL xH yL yH
            baos.write(0x1D);
            baos.write(0x76);
            baos.write(0x30);
            baos.write(0x00); // mode normal
            baos.write(widthBytes % 256);
            baos.write(widthBytes / 256);
            baos.write(height % 256);
            baos.write(height / 256);

            for (int y = 0; y < height; y++) {
                for (int x = 0; x < widthBytes; x++) {
                    byte b = 0;
                    for (int bit = 0; bit < 8; bit++) {
                        int pixelX = x * 8 + bit;
                        if (pixelX < width) {
                            int pixel = bitmap.getPixel(pixelX, y);
                            int r = Color.red(pixel);
                            int g = Color.green(pixel);
                            int bColor = Color.blue(pixel);
                            int luminance = (int) (0.299 * r + 0.587 * g + 0.114 * bColor);
                            if (luminance < 160) {
                                b |= (1 << (7 - bit));
                            }
                        }
                    }
                    baos.write(b);
                }
            }

            // Feed lines & cut
            baos.write(0x0A);
            baos.write(0x0A);
            baos.write(0x0A);
            baos.write(0x1D);
            baos.write(0x56);
            baos.write(0x41);
            baos.write(0x00);

            return baos.toByteArray();
        }
    }
}
