#!/usr/bin/env bash
set -e

DEST_DIR="android/app/src/main/java/com/editorstruk/app"
SOURCE_FILE="scripts/android_bridge/MainActivity.java"

if [ -f "$SOURCE_FILE" ]; then
  mkdir -p "$DEST_DIR"
  cp "$SOURCE_FILE" "$DEST_DIR/MainActivity.java"
  echo "Berhasil memasang Android Bluetooth Printer Bridge ke $DEST_DIR/MainActivity.java"
else
  echo "Error: $SOURCE_FILE tidak ditemukan!"
  exit 1
fi
