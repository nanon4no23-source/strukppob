import os
import sys
from PIL import Image

def generate_icons(source_path="public/app-icon.png", android_res="android/app/src/main/res"):
    if not os.path.exists(source_path):
        print(f"Error: Sumber icon {source_path} tidak ditemukan!")
        return False

    img = Image.open(source_path).convert("RGBA")
    print(f"Menggunakan icon sumber: {source_path} ({img.size[0]}x{img.size[1]})")

    # Ukuran standar Android launcher icons
    icon_sizes = {
        "mipmap-mdpi": 48,
        "mipmap-hdpi": 72,
        "mipmap-xhdpi": 96,
        "mipmap-xxhdpi": 144,
        "mipmap-xxxhdpi": 192,
    }

    for folder, size in icon_sizes.items():
        target_dir = os.path.join(android_res, folder)
        os.makedirs(target_dir, exist_ok=True)
        
        resized = img.resize((size, size), Image.Resampling.LANCZOS)
        
        # Simpan ic_launcher.png & ic_launcher_round.png
        launcher_path = os.path.join(target_dir, "ic_launcher.png")
        round_path = os.path.join(target_dir, "ic_launcher_round.png")
        resized.save(launcher_path, "PNG")
        resized.save(round_path, "PNG")
        print(f"Generated: {launcher_path} ({size}x{size})")

    # Ganti juga foreground untuk adaptive icon jika ada folder drawable
    drawable_dir = os.path.join(android_res, "mipmap-xxhdpi")
    foreground_path = os.path.join(android_res, "drawable", "ic_launcher_foreground.png")
    os.makedirs(os.path.dirname(foreground_path), exist_ok=True)
    fg_resized = img.resize((432, 432), Image.Resampling.LANCZOS)
    fg_resized.save(foreground_path, "PNG")

    print("Semua icon Android berhasil diperbarui!")
    return True

if __name__ == "__main__":
    src = sys.argv[1] if len(sys.argv) > 1 else "public/app-icon.png"
    dest = sys.argv[2] if len(sys.argv) > 2 else "android/app/src/main/res"
    generate_icons(src, dest)
