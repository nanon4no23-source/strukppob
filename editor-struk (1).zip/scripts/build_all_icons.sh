#!/usr/bin/env bash
set -e

SOURCE_IMG="public/app-icon.png"

if [ ! -f "$SOURCE_IMG" ]; then
  echo "Error: $SOURCE_IMG tidak ditemukan!"
  exit 1
fi

echo "=== 1. Membuat Aset Ikon PWA Standar Web ==="
# Konversi ke true PNG
convert "$SOURCE_IMG" -resize 512x512 png32:public/app-icon.png
convert "$SOURCE_IMG" -resize 192x192 png32:public/icon-192.png
convert "$SOURCE_IMG" -resize 512x512 png32:public/icon-512.png
convert "$SOURCE_IMG" -resize 180x180 png32:public/apple-touch-icon.png
convert "$SOURCE_IMG" -resize 64x64 png32:public/favicon.png

# Buat versi maskable untuk PWA (dengan padding 15% agar tidak terpotong di launcher Android)
convert "$SOURCE_IMG" -resize 410x410 -gravity center -background "#03C773" -extent 512x512 png32:public/icon-maskable-512.png

echo "Aset PWA selesai dibuat di public/!"

echo "=== 2. Membuat Aset Ikon Lengkap Android (Mipmap & Adaptive) ==="
RES_DIR="resources/android/res"
mkdir -p "$RES_DIR/mipmap-mdpi"
mkdir -p "$RES_DIR/mipmap-hdpi"
mkdir -p "$RES_DIR/mipmap-xhdpi"
mkdir -p "$RES_DIR/mipmap-xxhdpi"
mkdir -p "$RES_DIR/mipmap-xxxhdpi"
mkdir -p "$RES_DIR/mipmap-anydpi-v26"
mkdir -p "$RES_DIR/drawable"
mkdir -p "$RES_DIR/values"

# Ukuran standar launcher Android (ic_launcher.png & ic_launcher_round.png):
# mdpi: 48x48, foreground: 108x108 (safe zone 72x72)
convert "$SOURCE_IMG" -resize 48x48 png32:"$RES_DIR/mipmap-mdpi/ic_launcher.png"
convert "$SOURCE_IMG" -resize 48x48 png32:"$RES_DIR/mipmap-mdpi/ic_launcher_round.png"
convert "$SOURCE_IMG" -resize 80x80 -gravity center -background transparent -extent 108x108 png32:"$RES_DIR/mipmap-mdpi/ic_launcher_foreground.png"

# hdpi: 72x72, foreground: 162x162
convert "$SOURCE_IMG" -resize 72x72 png32:"$RES_DIR/mipmap-hdpi/ic_launcher.png"
convert "$SOURCE_IMG" -resize 72x72 png32:"$RES_DIR/mipmap-hdpi/ic_launcher_round.png"
convert "$SOURCE_IMG" -resize 120x120 -gravity center -background transparent -extent 162x162 png32:"$RES_DIR/mipmap-hdpi/ic_launcher_foreground.png"

# xhdpi: 96x96, foreground: 216x216
convert "$SOURCE_IMG" -resize 96x96 png32:"$RES_DIR/mipmap-xhdpi/ic_launcher.png"
convert "$SOURCE_IMG" -resize 96x96 png32:"$RES_DIR/mipmap-xhdpi/ic_launcher_round.png"
convert "$SOURCE_IMG" -resize 160x160 -gravity center -background transparent -extent 216x216 png32:"$RES_DIR/mipmap-xhdpi/ic_launcher_foreground.png"

# xxhdpi: 144x144, foreground: 324x324
convert "$SOURCE_IMG" -resize 144x144 png32:"$RES_DIR/mipmap-xxhdpi/ic_launcher.png"
convert "$SOURCE_IMG" -resize 144x144 png32:"$RES_DIR/mipmap-xxhdpi/ic_launcher_round.png"
convert "$SOURCE_IMG" -resize 240x240 -gravity center -background transparent -extent 324x324 png32:"$RES_DIR/mipmap-xxhdpi/ic_launcher_foreground.png"

# xxxhdpi: 192x192, foreground: 432x432
convert "$SOURCE_IMG" -resize 192x192 png32:"$RES_DIR/mipmap-xxxhdpi/ic_launcher.png"
convert "$SOURCE_IMG" -resize 192x192 png32:"$RES_DIR/mipmap-xxxhdpi/ic_launcher_round.png"
convert "$SOURCE_IMG" -resize 320x320 -gravity center -background transparent -extent 432x432 png32:"$RES_DIR/mipmap-xxxhdpi/ic_launcher_foreground.png"

# Salin juga ke drawable sebagai fallback
cp "$RES_DIR/mipmap-xxxhdpi/ic_launcher_foreground.png" "$RES_DIR/drawable/ic_launcher_foreground.png"

# File adaptive icon XML untuk Android 8.0+ (API 26+)
cat << 'EOF' > "$RES_DIR/mipmap-anydpi-v26/ic_launcher.xml"
<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
EOF

cat << 'EOF' > "$RES_DIR/mipmap-anydpi-v26/ic_launcher_round.xml"
<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
EOF

cat << 'EOF' > "$RES_DIR/values/ic_launcher_background.xml"
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_background">#03C773</color>
</resources>
EOF

cat << 'EOF' > "$RES_DIR/drawable/ic_launcher_background.xml"
<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <path
        android:fillColor="#03C773"
        android:pathData="M0,0h108v108h-108z" />
</vector>
EOF

echo "Seluruh aset ikon Android & PWA berhasil di-generate secara sempurna!"
