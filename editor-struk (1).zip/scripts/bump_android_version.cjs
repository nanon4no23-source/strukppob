const fs = require('fs');
const path = require('path');

const buildGradlePath = path.join(process.cwd(), 'android', 'app', 'build.gradle');

console.log('Menyesuaikan versi Android ke v1.1 (versionCode 2)...');

if (fs.existsSync(buildGradlePath)) {
  let content = fs.readFileSync(buildGradlePath, 'utf8');

  // Ganti versionCode menjadi 2
  content = content.replace(/versionCode\s+\d+/g, 'versionCode 2');
  
  // Ganti versionName menjadi "1.1"
  content = content.replace(/versionName\s+["'][^"']+["']/g, 'versionName "1.1"');

  fs.writeFileSync(buildGradlePath, content, 'utf8');
  console.log('Berhasil memperbarui android/app/build.gradle!');

  // Tampilkan baris defaultConfig untuk verifikasi
  const lines = content.split('\n');
  const preview = lines.filter(l => l.includes('versionCode') || l.includes('versionName')).map(l => l.trim());
  console.log('Hasil verifikasi build.gradle:', preview.join(' | '));
} else {
  console.error('File android/app/build.gradle tidak ditemukan!');
  process.exit(1);
}
