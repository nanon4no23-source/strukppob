#!/usr/bin/env bash
set -e

SOURCE_RES="${SOURCE_RES:-resources/android/res}"
TARGET_RES="${TARGET_RES:-android/app/src/main/res}"

echo "Memperbarui icon aplikasi Android..."

# 1. HAPUS folder drawable-v24 dan file foreground vector bawaan Capacitor!
# Capacitor membuat default vector di drawable-v24/ic_launcher_foreground.xml
# yang menyebabkan HP Android selalu menampilkan icon bawaan Capacitor / Github.
rm -rf "$TARGET_RES/drawable-v24"
rm -f "$TARGET_RES/drawable/ic_launcher_foreground.xml"

# 2. Salin seluruh aset ikon (mipmap, adaptive-anydpi-v26, drawable, values)
if [ -d "$SOURCE_RES" ]; then
  mkdir -p "$TARGET_RES"
  cp -rf "$SOURCE_RES"/* "$TARGET_RES"/
  echo "Berhasil menyalin seluruh aset ikon Android lengkap dari $SOURCE_RES!"
fi

# 3. Pastikan mipmap-anydpi-v26 mengarah ke foreground kustom kita
mkdir -p "$TARGET_RES/mipmap-anydpi-v26"
cat << 'EOF' > "$TARGET_RES/mipmap-anydpi-v26/ic_launcher.xml"
<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
EOF

cat << 'EOF' > "$TARGET_RES/mipmap-anydpi-v26/ic_launcher_round.xml"
<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
EOF

# 4. Pastikan file adaptive background xml ada
mkdir -p "$TARGET_RES/values"
cat << 'EOF' > "$TARGET_RES/values/ic_launcher_background.xml"
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_background">#03C773</color>
</resources>
EOF

mkdir -p "$TARGET_RES/drawable"
cat << 'EOF' > "$TARGET_RES/drawable/ic_launcher_background.xml"
<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <path
        android:fillColor="#03C773"
        android:pathData="M0,0h108v108h-108z" />
</vector>
EOF

echo "Ikon Android (ic_launcher, round, foreground, & background) berhasil diperbarui tanpa sisa bawaan Capacitor!"
