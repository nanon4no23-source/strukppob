#!/usr/bin/env bash
set -e

SOURCE_RES="resources/android/res"
TARGET_RES="android/app/src/main/res"

echo "Memperbarui icon aplikasi Android..."

# 1. Salin dari pre-generated resources jika tersedia (paling cepat & 100% lengkap)
if [ -d "$SOURCE_RES" ]; then
  mkdir -p "$TARGET_RES"
  cp -rf "$SOURCE_RES"/* "$TARGET_RES"/
  echo "Berhasil menyalin seluruh aset ikon Android lengkap dari $SOURCE_RES!"
fi

# 2. Pastikan file adaptive background xml ada
mkdir -p "$TARGET_RES/values"
cat << 'EOF' > "$TARGET_RES/values/ic_launcher_background.xml"
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_background">#059669</color>
</resources>
EOF

mkdir -p "$TARGET_RES/drawable"
cat << 'EOF' > "$TARGET_RES/drawable/ic_launcher_background.xml"
<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <path
        android:fillColor="#059669"
        android:pathData="M0,0h108v108h-108z" />
</vector>
EOF

echo "Ikon Android (ic_launcher, round, foreground, & background) berhasil diperbarui!"
