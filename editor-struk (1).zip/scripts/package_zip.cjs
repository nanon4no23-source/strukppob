const fs = require('fs');
const path = require('path');
const JSZip = require('jszip');

async function createProjectZip() {
  const zip = new JSZip();
  const rootDir = process.cwd();

  const ignoreDirs = ['node_modules', '.git', 'dist', '.next', 'output-apk', 'android'];
  const ignoreFiles = ['public/editor-struk.zip'];

  function addDirToZip(currentDir, relativePath = '') {
    const items = fs.readdirSync(currentDir);

    for (const item of items) {
      const fullPath = path.join(currentDir, item);
      const relItemPath = relativePath ? `${relativePath}/${item}` : item;

      if (ignoreDirs.includes(item) || ignoreFiles.includes(relItemPath)) {
        continue;
      }

      const stat = fs.statSync(fullPath);
      if (stat.isDirectory()) {
        addDirToZip(fullPath, relItemPath);
      } else {
        const fileContent = fs.readFileSync(fullPath);
        zip.file(relItemPath, fileContent);
      }
    }
  }

  console.log('Mengemas seluruh file proyek ke editor-struk.zip...');
  addDirToZip(rootDir);

  const zipBuffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 }
  });

  const publicDest = path.join(rootDir, 'public', 'editor-struk.zip');
  fs.writeFileSync(publicDest, zipBuffer);
  console.log(`Berhasil membuat ${publicDest} (${(zipBuffer.length / 1024 / 1024).toFixed(2)} MB)`);
}

createProjectZip().catch(console.error);
